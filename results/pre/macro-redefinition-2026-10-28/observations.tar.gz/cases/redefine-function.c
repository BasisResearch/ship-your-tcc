#define DECL(n) extern int n(void);
#define DECL(n) extern int n(void);
DECL(chosen)
