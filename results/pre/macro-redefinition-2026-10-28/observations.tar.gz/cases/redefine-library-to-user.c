#include "/runtime/libc/include/redefine.h"
#define DECL extern int chosen(void);
DECL
