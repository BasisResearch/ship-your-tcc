#define DECL extern int chosen(void);
