#define DECL extern int chosen(void);
#include "/runtime/libc/include/redefine.h"
DECL
