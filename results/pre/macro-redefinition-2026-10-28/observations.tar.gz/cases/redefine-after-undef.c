#include "/runtime/libc/include/redefine.h"
#undef DECL
#define DECL extern int chosen(void);
DECL
