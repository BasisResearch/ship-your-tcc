import hashlib,json,subprocess,sys,tarfile
from pathlib import Path
root=Path.cwd();out=root/'build/macro-redefinition-review';sys.path.insert(0,str(root/'scripts'))
from gen_raw_frontend_cases import generate
cases=out/'cases';listing=generate(cases)
prior=json.loads((out/'prior-binaries.json').read_text());old=out/'csem_raw-before'
with tarfile.open(out/'prior-binaries.tar.gz','r:gz') as t:old.write_bytes(t.extractfile('csem_raw').read())
assert hashlib.sha256(old.read_bytes()).hexdigest()==prior['csem_raw'];old.chmod(0o755)
rows=[]
for name in ['redefine-library-to-user','redefine-user-to-library','redefine-repeat-header','redefine-function','redefine-after-undef']:
 row={'case':name}
 for tag,exe in [('before',old),('after',root/'.lake/build/bin/csem_raw')]:
  cmd=[str(exe),'--fslist',str(listing),'--library','/runtime/libc/include/redefine.h',str(cases/(name+'.c'))]
  p=subprocess.run(cmd,capture_output=True,timeout=30);assert p.returncode==0,p.stderr
  stem=out/(name+'.'+tag)
  stem.with_suffix(stem.suffix+'.json').write_bytes(p.stdout);stem.with_suffix(stem.suffix+'.stderr').write_bytes(p.stderr)
  data=json.loads(p.stdout);row[tag]={'command':cmd,'binary_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'library_membership':[x['actualLibrary'] for x in data['libraryOrigins']],'definition_sites':[x['identitySite'] for x in data['libraryOrigins']]}
 rows.append(row)
(out/'observations.json').write_text(json.dumps(rows,indent=2)+'\n')
print([(x['case'],x['before']['library_membership'],x['after']['library_membership']) for x in rows])
