#define LIBZERO 0
