import hashlib,json,pathlib,subprocess,fcntl,tarfile
root=pathlib.Path.cwd();out=root/'build/macro-redefinition-review'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=[root/p for p in subprocess.check_output(['git','ls-files','Spec','Tcc','csem','lean','scripts','lakefile.toml','lake-manifest.json','lean-toolchain','vendor/CSEM_REV'],text=True).splitlines() if (root/p).is_file()]
pins={str(p.relative_to(root)):sha(p) for p in paths}
(out/'build-inputs.json').write_text(json.dumps(pins,indent=2)+'\n')
binaries=[root/'.lake/build/bin'/n for n in ['csem_raw','pre_spec','tcc_pre_tokens','tcc_ghost']]
prior=json.loads((out/'prior-binaries.json').read_text())
with tarfile.open(out/'prior-binaries.tar.gz','r:gz') as t:
 for n,h in prior.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
with (root/'build/lake.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 assert all(sha(root/p)==h for p,h in pins.items())
 available=int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))//1024**2
 assert available>=25
 cmd=['systemd-run','--user','--scope','-p','MemoryMax=12G','lake','build','csem_raw','pre_spec','tcc_pre_tokens','tcc_ghost','CSemPre','Tcc.Model.PreAudit']
 with (out/'build.log').open('w') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 assert all(sha(root/q)==h for q,h in pins.items())
 (out/'build-result.json').write_text(json.dumps(dict(exit=p.returncode,command=cmd,source_hashes_verified=True,binary_sha256={q.name:sha(q) for q in binaries}),indent=2)+'\n')
print('build exit',p.returncode,flush=True)
