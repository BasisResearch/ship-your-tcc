import json,hashlib,subprocess,os
from pathlib import Path
root=Path.cwd();out=root/'build/macro-redefinition-review'
pins=json.loads((out/'build-inputs.json').read_text())
def verify():assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in pins.items())
verify()
with (out/'full-gate.log').open('w') as f:p=subprocess.run(['scripts/check.sh','--csem'],stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'SYT_LAKE_LOCK':str(root/'build/lake.lock')})
verify();(out/'full-gate-result.json').write_text(json.dumps(dict(exit=p.returncode,source_hashes_verified=True,pinned_inputs=len(pins)))+'\n');print('full gate',p.returncode,flush=True)
