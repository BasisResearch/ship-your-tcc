#ifn\
def H
#define H
extern int retained;
#endif
