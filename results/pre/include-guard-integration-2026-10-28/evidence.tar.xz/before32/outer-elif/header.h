#ifndef H
#define H
extern int retained;
#elif 0
extern int alternate;
#endif
