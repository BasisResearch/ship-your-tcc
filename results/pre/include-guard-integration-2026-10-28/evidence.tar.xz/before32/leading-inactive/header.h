#if 0
extern int ignored;
#endif
#ifndef H
#define H
extern int retained;
#endif
