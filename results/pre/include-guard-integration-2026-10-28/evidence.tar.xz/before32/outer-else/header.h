#ifndef H
#define H
extern int retained;
#else
extern int alternate;
#endif
