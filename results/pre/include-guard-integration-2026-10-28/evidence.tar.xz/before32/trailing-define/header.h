#ifndef H
#define H
extern int retained;
#endif
#define AFTER 1
