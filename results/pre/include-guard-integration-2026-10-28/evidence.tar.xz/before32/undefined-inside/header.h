#ifndef H
#define H
extern int retained;
#undef H
#endif
