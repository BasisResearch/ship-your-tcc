#ifndef H
#define H
#line 80 "virtual.h"
extern int retained;
#endif
