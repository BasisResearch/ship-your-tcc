#ifndef H
#define H
#if 1
extern int retained;
#else
extern int alternate;
#endif
#endif
