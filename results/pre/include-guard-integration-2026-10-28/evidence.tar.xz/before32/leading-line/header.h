#line 80 "virtual.h"
#ifndef H
#define H
extern int retained;
#endif
