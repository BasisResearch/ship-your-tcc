#ifndef H
#define H
extern int retained;
#endif
extern int after;
