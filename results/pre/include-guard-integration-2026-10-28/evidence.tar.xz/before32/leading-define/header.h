#define BEFORE 1
#ifndef H
#define H
extern int retained;
#endif
