#if !defined(H)
#define H
extern int retained;
#endif
