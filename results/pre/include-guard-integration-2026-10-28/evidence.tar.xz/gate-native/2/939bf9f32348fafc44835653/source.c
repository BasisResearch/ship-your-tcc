typedef const int Number;
int calls,effects;
int call(void){calls++;return 3;}
int main(void){
 int n=2;
 int a=n++ ?: ++effects;
 int b=0 ?: call();
 int c=__builtin_choose_expr(0,++effects,7);
 typeof(n++) d=4;
 typeof(Number) q=5;
 typeof(int (*)(void)) fp=call;
 int v=__builtin_choose_expr(1,(call() ?: 8),++effects);
 int w=_Generic(n,int:__builtin_choose_expr(1,n ?: 9,++effects),default:call());
 int arr[n++];typeof(arr) arr2;
 int m=2;typeof(int[m++]) va;
 return a!=2 || b!=3 || c!=7 || d!=4 || q!=5 || v!=3 || w!=3 ||
   n!=4 || calls!=2 || effects || sizeof(arr2)!=12 || m!=3 || sizeof(va)!=8 || fp!=call;
}
