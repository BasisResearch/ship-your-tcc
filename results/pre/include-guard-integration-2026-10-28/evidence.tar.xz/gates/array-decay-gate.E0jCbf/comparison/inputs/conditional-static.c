typedef int A[2] __attribute__((aligned(32))); typedef A B;
int main(void){static B a={3,7};return _Alignof(__typeof__(1?a:a))!=8 || _Alignof(__typeof__(0?a:0))!=8 || _Alignof(__typeof__(1?0:a))!=8 || _Alignof(__typeof__(1?a:(int*)0))!=8;}
