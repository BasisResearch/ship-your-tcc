typedef int *P __attribute__((aligned(16))); P p; int main(void){return _Alignof(__typeof__(p+0))!=16 || _Alignof(__typeof__(*(&p)))!=16 || _Alignof(__typeof__(&p))!=8;}
