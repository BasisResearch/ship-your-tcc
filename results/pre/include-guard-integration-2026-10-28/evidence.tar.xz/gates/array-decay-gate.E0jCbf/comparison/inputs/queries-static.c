typedef int A[2] __attribute__((aligned(32))); typedef A B;
int main(void){static B a={3,7};return _Alignof(__typeof__(a))!=32 || __alignof__(a)!=32 || sizeof(a)!=8 || sizeof(a+0)!=8 || sizeof(*a)!=4;}
