typedef int A[2] __attribute__((aligned(32))); typedef A B;
int x[sizeof(A[2])]; int main(void){return 0;}
