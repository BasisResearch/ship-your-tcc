typedef int A[2] __attribute__((aligned(32))); typedef A B;
int main(void){B a={3,7};return _Alignof(__typeof__(&a))!=8 || _Alignof(__typeof__(*(&a)))!=32 || _Alignof(__typeof__(*((&a)+0)))!=32 || sizeof(*(&a))!=8;}
