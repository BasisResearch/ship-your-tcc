typedef int A[2] __attribute__((aligned(32))); typedef A B;
int f(A a[2]); int main(void){return 0;}
