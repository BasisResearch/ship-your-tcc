typedef int A[2] __attribute__((aligned(32))); typedef A B;
int main(void){const B a={3,7};return !_Generic(a+0,const int*:1,default:0) || _Alignof(__typeof__(a+0))!=8 || _Alignof(__typeof__(a))!=32 || __alignof__(a)!=32;}
