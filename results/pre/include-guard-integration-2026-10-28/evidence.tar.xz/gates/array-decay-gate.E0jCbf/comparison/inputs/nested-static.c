typedef int A[2] __attribute__((aligned(32))); typedef A B;
int main(void){static B a={3,7}; A *p=&a; A **q=&p;return _Alignof(__typeof__(**q))!=32 || _Alignof(__typeof__(**q+0))!=8 || _Alignof(__typeof__(*q))!=8;}
