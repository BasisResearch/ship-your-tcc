int f(int n){typedef int A[n] __attribute__((aligned(32))); A a;return _Alignof(__typeof__(a+0))!=8 || _Alignof(__typeof__(a))!=32 || sizeof(a)!=n*4;} int main(void){return f(3);}
