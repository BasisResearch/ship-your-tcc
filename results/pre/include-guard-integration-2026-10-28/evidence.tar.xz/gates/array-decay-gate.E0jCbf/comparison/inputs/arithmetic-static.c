typedef int A[2] __attribute__((aligned(32))); typedef A B;
int main(void){static B a={3,7};return _Alignof(__typeof__(a+0))!=8 || _Alignof(__typeof__(0+a))!=8 || _Alignof(__typeof__(a-0))!=8 || (a+1)-a!=1;}
