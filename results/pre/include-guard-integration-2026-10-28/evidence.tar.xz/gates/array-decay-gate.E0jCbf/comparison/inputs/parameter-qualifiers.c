typedef int A[2] __attribute__((aligned(32))); typedef A B;
int f(const B a){return !_Generic(a,const int*:1,default:0) || _Alignof(__typeof__(a))!=8 || a[1]!=7;} int main(void){const B a={3,7};return f(a);}
