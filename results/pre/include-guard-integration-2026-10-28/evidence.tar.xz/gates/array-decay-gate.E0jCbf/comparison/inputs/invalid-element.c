typedef int E __attribute__((aligned(32))); E a[2]; int main(void){return 0;}
