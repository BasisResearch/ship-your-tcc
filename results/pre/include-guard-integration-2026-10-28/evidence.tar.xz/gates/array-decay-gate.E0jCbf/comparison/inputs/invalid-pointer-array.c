typedef int A[2] __attribute__((aligned(32))); typedef A B;
A (*p)[2]; int main(void){return 0;}
