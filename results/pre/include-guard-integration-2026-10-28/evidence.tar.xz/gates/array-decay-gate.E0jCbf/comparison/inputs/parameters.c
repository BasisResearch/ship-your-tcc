typedef int A[2] __attribute__((aligned(32))); typedef A B;
int f(A a){return _Alignof(__typeof__(a))!=8 || _Alignof(__typeof__(a+0))!=8 || a[1]!=7;} int g(B a){return f(a);} int main(void){A a={3,7};return g(a);}
