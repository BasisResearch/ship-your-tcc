typedef int A[2] __attribute__((aligned(32))); typedef A B;
int main(void){static B a={3,7};return _Alignof(__typeof__(*(1?&a:&a)))!=32 || _Alignof(__typeof__(1?&a:&a))!=8;}
