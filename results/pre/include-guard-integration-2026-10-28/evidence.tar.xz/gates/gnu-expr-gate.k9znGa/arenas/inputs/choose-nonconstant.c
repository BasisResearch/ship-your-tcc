int f(int n){return __builtin_choose_expr(n,1,2);}

int main(void){return 0;}
