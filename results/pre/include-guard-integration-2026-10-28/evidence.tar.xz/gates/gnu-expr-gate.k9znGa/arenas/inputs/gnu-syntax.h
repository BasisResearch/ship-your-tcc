#define GNU_PICK(c,a,b) __builtin_choose_expr(c,a,b)
#define GNU_FALLBACK(a,b) ((a) ? : (b))
typedef const int HeaderNumber;
