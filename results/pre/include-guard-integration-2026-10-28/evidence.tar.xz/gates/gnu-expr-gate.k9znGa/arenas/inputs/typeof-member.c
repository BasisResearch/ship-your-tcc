struct S{int n;};typeof(((struct S *)0)->n) x;

int main(void){return 0;}
