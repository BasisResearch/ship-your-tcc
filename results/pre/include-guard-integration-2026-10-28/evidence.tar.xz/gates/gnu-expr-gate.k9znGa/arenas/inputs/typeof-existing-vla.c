int f(int n){int a[n++];typeof(a) b;return sizeof(b)+n;}

int main(void){return 0;}
