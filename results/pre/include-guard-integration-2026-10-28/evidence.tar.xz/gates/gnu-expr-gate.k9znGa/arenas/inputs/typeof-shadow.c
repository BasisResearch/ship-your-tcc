typedef int T;int f(void){int T=3;typeof(T) y=4;return y;}

int main(void){return 0;}
