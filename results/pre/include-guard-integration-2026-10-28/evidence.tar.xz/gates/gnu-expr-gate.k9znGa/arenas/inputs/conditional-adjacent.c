int f(int x){return x ?: 3;}

int main(void){return 0;}
