int x;__typeof(x) a;__typeof__(x) b;typeof(x) c;

int main(void){return 0;}
