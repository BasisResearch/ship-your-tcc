int f(int n){typeof(int[n++]) a;return sizeof(a)+n;}

int main(void){return 0;}
