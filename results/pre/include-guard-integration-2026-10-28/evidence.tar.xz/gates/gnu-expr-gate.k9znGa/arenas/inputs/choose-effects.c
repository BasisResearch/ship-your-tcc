int f(void){int n=0;int x=__builtin_choose_expr(0,++n,7);return n+x;}

int main(void){return 0;}
