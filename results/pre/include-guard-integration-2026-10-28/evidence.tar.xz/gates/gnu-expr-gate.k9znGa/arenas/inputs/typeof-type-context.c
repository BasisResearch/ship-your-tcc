typedef typeof(int) N;struct S{typeof(N) n;};

int main(void){return 0;}
