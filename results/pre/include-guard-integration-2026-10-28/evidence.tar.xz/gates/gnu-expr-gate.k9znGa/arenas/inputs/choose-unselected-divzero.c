int x=__builtin_choose_expr(1,7,1/0);

int main(void){return 0;}
