int g(void);int f(void){return __builtin_choose_expr(0,g(),3);}

int main(void){return 0;}
int g(void){return 0;}
