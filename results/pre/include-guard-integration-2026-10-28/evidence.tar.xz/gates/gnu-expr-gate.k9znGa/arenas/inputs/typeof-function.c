int f(int);typeof(f) g;typeof(&f) p;

int main(void){return 0;}
