int g(void);typeof(g()) x;

int main(void){return 0;}
int g(void){return 0;}
