int x; typeof(x) y;

int main(void){return 0;}
