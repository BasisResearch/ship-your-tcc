typeof(int (*)(const int *,long)) f;

int main(void){return 0;}
