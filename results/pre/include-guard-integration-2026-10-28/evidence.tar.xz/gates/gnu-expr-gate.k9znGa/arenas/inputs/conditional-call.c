int g(void);int f(void){return g() ?: 9;}

int main(void){return 0;}
int g(void){return 0;}
