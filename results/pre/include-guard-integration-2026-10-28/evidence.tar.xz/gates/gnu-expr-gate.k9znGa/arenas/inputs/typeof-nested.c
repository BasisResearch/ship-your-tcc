int x;typeof(typeof(x)) y;

int main(void){return 0;}
