int x=__builtin_choose_expr(1,3,(void *)0);

int main(void){return 0;}
