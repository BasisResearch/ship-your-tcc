const int n=1;typeof(++n) x;

int main(void){return 0;}
