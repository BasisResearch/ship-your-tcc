int x;typeof(x ?: 3) y;

int main(void){return 0;}
