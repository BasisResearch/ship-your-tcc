#define CAT(a,b) a##b
#define TYPE(x) CAT(__type,of__)(x)
#line 71 "gnu-origin.c"
TYPE(0X1UL ?: 010UL) x=__builtin_choose_expr(1,0x2UL,03UL);

int main(void){return 0;}
