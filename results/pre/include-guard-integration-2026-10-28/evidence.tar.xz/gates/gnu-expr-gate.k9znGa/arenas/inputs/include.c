#include "gnu-syntax.h"
typeof(HeaderNumber) n;int f(int x){return GNU_PICK(1,GNU_FALLBACK(x,7),3);}

int main(void){return 0;}
