typedef int A[3];typeof(A) a;typeof(a) b;typeof(&a) p;

int main(void){return 0;}
