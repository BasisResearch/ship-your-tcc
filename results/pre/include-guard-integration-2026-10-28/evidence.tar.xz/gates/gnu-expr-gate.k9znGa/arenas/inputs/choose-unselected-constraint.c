int x=__builtin_choose_expr(1,2,*(int)3);

int main(void){return 0;}
