typedef int T; typeof(T) x; typeof(T *) p;

int main(void){return 0;}
