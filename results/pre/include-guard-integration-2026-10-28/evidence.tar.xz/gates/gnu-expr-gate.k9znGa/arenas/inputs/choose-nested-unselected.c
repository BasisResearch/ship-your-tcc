int x=__builtin_choose_expr(1,2,__builtin_choose_expr(0,3,4));

int main(void){return 0;}
