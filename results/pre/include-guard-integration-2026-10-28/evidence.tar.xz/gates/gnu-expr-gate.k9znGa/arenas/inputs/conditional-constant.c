int a[(0 ?: 3)];int x=1 ?: 2;

int main(void){return 0;}
