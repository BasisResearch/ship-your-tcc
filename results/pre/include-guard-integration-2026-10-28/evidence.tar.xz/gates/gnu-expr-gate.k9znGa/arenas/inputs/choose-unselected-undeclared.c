int x=__builtin_choose_expr(1,2,missing);

int main(void){return 0;}
