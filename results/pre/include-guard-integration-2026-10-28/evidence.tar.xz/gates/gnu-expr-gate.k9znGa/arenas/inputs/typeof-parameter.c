int f(typeof(const int *) p,typeof(int [3]) a);

int main(void){return 0;}
