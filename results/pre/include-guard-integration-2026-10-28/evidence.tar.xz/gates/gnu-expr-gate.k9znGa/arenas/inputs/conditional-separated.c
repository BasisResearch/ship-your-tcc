int f(int x){return x ? /* retained boundary */ : 3;}

int main(void){return 0;}
