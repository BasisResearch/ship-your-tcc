char *p=__builtin_choose_expr(0,"a" "b","c\x41" "1");

int main(void){return 0;}
