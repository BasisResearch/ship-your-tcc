int f(int x,int y){return x ? y ?: 3 : x ?: 5;}

int main(void){return 0;}
