int f(void){int n=1;return (n++ ?: ++n)+n;}

int main(void){return 0;}
