typeof(const volatile unsigned long *) p;

int main(void){return 0;}
