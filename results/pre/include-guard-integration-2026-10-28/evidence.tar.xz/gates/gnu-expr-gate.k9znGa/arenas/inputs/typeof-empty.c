typeof() x;

int main(void){return 0;}
