int f(int x,int y){return x ?: y ?: 7;}

int main(void){return 0;}
