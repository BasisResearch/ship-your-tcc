int x,y;typeof((x,y)) z;

int main(void){return 0;}
