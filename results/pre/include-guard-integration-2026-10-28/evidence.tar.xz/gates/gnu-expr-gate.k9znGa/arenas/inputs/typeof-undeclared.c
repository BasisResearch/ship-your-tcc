typeof(missing) x;

int main(void){return 0;}
