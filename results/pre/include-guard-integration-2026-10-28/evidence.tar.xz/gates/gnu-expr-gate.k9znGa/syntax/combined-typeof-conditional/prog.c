int x;typeof(x ?: 3) y;
