int x=__builtin_choose_expr(0,2,3);
