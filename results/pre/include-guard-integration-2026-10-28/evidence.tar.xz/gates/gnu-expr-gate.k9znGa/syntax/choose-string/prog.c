char *p=__builtin_choose_expr(0,"a" "b","c\x41" "1");
