int g(void);int f(void){return g() ?: 9;}
