int x=__builtin_choose_expr((1,0),2,3);
