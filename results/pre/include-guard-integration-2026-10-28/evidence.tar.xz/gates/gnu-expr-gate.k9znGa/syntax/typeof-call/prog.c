int g(void);typeof(g()) x;
