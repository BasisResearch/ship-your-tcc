int x;__typeof(x) a;__typeof__(x) b;typeof(x) c;
