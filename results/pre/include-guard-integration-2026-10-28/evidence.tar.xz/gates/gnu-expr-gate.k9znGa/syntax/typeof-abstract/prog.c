typeof(int (*)(const int *,long)) f;
