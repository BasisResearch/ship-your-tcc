int f(int x){return sizeof(typeof(x))+((typeof(x))3);}
