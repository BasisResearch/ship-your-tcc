int x=__builtin_choose_expr(1,3,(void *)0);
