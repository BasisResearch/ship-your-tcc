#define PICK(c,a,b) __builtin_choose_expr(c,a,b)
#define FALLBACK(a,b) ((a) ?: (b))
#define TYPE(x) __typeof__(x)
int f(int n){TYPE(PICK(1,n,0)) x=FALLBACK(PICK(0,1,n),7);return x;}

