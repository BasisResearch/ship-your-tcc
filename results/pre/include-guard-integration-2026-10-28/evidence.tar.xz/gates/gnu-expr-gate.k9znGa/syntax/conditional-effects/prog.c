int f(void){int n=1;return (n++ ?: ++n)+n;}
