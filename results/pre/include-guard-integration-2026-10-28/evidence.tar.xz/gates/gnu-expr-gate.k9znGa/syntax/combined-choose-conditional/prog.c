int f(int x){return __builtin_choose_expr(1,x ?: 2,3 ?: 4);}
