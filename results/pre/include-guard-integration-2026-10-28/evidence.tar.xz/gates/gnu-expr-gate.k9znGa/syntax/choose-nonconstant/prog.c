int f(int n){return __builtin_choose_expr(n,1,2);}
