struct S{int n;};int f(int x){struct S s;return x ?: s;}
