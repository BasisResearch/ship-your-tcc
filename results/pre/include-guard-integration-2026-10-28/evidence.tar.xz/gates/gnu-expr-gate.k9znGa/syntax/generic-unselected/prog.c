int f(int x){return _Generic(x,int:1,default:__builtin_choose_expr(1,x ?: 2,(typeof(x))3));}
