int f(int x){return x ? /* retained boundary */ : 3;}
