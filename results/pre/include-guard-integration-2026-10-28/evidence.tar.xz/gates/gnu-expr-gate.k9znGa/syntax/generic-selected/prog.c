int f(int x){return _Generic(x,int:__builtin_choose_expr(1,x ?: 2,3),default:4);}
