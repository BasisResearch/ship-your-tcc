typeof(__builtin_choose_expr(1,2,(long)3)) x;
