int g(void);int f(void){return __builtin_choose_expr(0,g(),3);}
