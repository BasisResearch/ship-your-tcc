_Static_assert(sizeof(typeof(__builtin_choose_expr(1,1,2)))==4,"gnu");
