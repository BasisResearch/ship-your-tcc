int x=__builtin_choose_expr(1,2,missing);
