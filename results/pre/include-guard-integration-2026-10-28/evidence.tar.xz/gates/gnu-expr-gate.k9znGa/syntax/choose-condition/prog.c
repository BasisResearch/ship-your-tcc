int x=__builtin_choose_expr(sizeof(long)==8,0X2UL,010);
