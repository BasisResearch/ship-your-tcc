int x=__builtin_choose_expr(1,7,1/0);
