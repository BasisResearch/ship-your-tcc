int f(void){int a=0,b=0;__builtin_choose_expr(1,a,b)=3;return a+b;}
