_Static_assert(1,"before\0after");
int main(void){return 0;}
