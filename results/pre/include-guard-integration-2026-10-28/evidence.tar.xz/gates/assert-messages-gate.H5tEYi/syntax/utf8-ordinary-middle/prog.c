_Static_assert(1,u8"before" " middle" u8" after");
int main(void){return 0;}
