_Static_assert(1,u"before" " middle" u" after");
int main(void){return 0;}
