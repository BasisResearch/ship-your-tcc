_Static_assert(1,"before" L" middle");
int main(void){return 0;}
