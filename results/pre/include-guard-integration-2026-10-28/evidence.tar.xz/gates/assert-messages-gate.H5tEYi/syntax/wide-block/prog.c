int main(void){_Static_assert(1,L"before middle after"); return 0;}
