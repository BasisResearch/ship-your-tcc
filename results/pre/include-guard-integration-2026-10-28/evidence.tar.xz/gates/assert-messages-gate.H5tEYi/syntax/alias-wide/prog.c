int x; extern int y __attribute__((alias(L"x")));
int main(void){return 0;}
