_Static_assert(1,L"before" " after");
int main(void){return 0;}
