_Static_assert(1,"before" U" middle");
int main(void){return 0;}
