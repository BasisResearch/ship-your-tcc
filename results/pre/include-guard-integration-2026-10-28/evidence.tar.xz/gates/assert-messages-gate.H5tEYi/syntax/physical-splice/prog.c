??=define MSG L"tri??/
graph"
_Static_assert(1,MSG " end");
int main(void){return 0;}
