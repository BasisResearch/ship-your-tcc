_Static_assert(1,u"" "");
int main(void){return 0;}
