_Static_assert(1,u"a" u8"b");
int main(void){return 0;}
