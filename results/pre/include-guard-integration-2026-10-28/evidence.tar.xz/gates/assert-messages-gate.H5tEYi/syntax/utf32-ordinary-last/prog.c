_Static_assert(1,U"before" " after");
int main(void){return 0;}
