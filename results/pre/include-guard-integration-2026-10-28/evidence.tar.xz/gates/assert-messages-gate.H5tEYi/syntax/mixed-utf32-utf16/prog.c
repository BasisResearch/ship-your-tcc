_Static_assert(1,U"a" u"b");
int main(void){return 0;}
