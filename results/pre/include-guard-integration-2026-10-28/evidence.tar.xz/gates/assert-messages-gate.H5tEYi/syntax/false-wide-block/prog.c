int main(void){_Static_assert(0,L"before middle after"); return 0;}
