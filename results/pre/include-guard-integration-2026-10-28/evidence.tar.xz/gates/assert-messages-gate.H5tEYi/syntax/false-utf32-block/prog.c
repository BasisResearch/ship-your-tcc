int main(void){_Static_assert(0,U"before middle after"); return 0;}
