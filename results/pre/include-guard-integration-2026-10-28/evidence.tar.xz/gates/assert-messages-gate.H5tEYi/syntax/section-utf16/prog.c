int x __attribute__((section(u"x")));
int main(void){return 0;}
