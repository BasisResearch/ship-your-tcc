_Static_assert(1,u"before" " after");
int main(void){return 0;}
