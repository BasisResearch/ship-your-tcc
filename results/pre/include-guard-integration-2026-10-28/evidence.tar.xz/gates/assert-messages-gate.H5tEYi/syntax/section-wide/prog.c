int x __attribute__((section(L"x")));
int main(void){return 0;}
