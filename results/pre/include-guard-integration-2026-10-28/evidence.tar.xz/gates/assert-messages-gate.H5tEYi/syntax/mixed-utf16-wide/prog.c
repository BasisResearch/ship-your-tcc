_Static_assert(1,u"a" L"b");
int main(void){return 0;}
