_Static_assert(1,u8"a" L"b");
int main(void){return 0;}
