_Static_assert(1,u8"a" U"b");
int main(void){return 0;}
