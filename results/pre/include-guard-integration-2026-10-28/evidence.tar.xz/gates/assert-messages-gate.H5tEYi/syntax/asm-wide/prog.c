int x __asm__(L"x");
int main(void){return 0;}
