struct S {_Static_assert(0,L"before middle after"); int n;};
int main(void){return 0;}
