_Static_assert(1,U"a" L"b");
int main(void){return 0;}
