_Static_assert(1,L"" "");
int main(void){return 0;}
