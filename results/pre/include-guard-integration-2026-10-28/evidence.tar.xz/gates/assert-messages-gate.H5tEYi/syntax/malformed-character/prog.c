_Static_assert(1,L'x');
int main(void){return 0;}
