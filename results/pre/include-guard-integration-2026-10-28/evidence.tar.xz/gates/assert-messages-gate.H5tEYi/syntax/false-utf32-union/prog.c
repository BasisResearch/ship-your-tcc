union U {_Static_assert(0,U"before middle after"); int n;};
int main(void){return 0;}
