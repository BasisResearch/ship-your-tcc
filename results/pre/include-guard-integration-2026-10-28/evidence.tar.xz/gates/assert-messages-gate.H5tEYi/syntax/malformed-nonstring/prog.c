_Static_assert(1,2);
int main(void){return 0;}
