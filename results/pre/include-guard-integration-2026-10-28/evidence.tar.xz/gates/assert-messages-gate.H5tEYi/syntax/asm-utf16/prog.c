int x __asm__(u"x");
int main(void){return 0;}
