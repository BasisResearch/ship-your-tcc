int main(void){_Static_assert(0,u"before middle after"); return 0;}
