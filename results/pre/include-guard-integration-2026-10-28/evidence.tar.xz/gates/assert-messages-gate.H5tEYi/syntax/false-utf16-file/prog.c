_Static_assert(0,u"before middle after");
int main(void){return 0;}
