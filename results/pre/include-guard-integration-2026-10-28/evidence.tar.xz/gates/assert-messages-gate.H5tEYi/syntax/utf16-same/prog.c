_Static_assert(1,u"raw\x41" u"1" u"\101");
int main(void){return 0;}
