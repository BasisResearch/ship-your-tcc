struct S {union U {struct T {_Static_assert(1,U"before middle after"); int n;} t;} u;};
int main(void){return 0;}
