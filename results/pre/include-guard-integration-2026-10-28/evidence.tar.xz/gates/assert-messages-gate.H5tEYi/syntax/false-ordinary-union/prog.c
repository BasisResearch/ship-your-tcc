union U {_Static_assert(0,"before middle after"); int n;};
int main(void){return 0;}
