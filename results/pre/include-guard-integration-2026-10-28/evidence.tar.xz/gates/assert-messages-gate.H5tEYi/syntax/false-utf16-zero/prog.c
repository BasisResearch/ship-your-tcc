_Static_assert(0,u"before\0after");
int main(void){return 0;}
