_Static_assert(0,u"before\u00e9after");
int main(void){return 0;}
