_Static_assert(1,L"before\0after");
int main(void){return 0;}
