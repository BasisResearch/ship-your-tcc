_Static_assert(1,"before" " middle" " after");
int main(void){return 0;}
