_Static_assert(1,"before" u8" middle");
int main(void){return 0;}
