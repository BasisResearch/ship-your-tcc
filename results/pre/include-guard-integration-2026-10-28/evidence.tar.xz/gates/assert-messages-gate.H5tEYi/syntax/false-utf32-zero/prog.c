_Static_assert(0,U"before\0after");
int main(void){return 0;}
