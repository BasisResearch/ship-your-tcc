_Static_assert(1,"before" " middle");
int main(void){return 0;}
