#include "messages.h"
_Static_assert(1,MSG);
int main(void){return 0;}
