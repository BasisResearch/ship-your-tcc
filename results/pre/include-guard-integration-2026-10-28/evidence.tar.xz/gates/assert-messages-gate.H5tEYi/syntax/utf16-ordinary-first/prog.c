_Static_assert(1,"before" u" middle");
int main(void){return 0;}
