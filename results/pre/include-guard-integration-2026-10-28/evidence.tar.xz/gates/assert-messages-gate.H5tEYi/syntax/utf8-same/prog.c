_Static_assert(1,u8"raw\x41" u8"1" u8"\101");
int main(void){return 0;}
