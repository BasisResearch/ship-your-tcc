int main(void){_Static_assert(0,u8"before middle after"); return 0;}
