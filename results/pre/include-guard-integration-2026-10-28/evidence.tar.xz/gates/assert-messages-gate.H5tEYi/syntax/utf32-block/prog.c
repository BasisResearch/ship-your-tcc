int main(void){_Static_assert(1,U"before middle after"); return 0;}
