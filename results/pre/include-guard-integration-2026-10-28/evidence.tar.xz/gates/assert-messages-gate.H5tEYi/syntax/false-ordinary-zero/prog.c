_Static_assert(0,"before\0after");
int main(void){return 0;}
