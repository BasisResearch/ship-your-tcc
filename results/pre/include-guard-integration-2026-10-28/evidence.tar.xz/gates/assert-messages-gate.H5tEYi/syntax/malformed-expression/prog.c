_Static_assert(1,L"x"+1);
int main(void){return 0;}
