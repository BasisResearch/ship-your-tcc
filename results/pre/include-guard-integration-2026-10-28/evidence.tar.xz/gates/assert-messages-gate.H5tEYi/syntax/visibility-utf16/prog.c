int x __attribute__((visibility(u"default")));
int main(void){return 0;}
