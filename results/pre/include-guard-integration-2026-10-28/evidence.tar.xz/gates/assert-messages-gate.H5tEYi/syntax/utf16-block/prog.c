int main(void){_Static_assert(1,u"before middle after"); return 0;}
