_Static_assert(1,u8"" "");
int main(void){return 0;}
