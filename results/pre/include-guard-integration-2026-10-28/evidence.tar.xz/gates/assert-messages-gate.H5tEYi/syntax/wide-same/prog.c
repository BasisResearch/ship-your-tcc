_Static_assert(1,L"raw\x41" L"1" L"\101");
int main(void){return 0;}
