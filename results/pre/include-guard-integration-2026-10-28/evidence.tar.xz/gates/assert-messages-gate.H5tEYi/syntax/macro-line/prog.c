#define CHECK(e,m) _Static_assert((e),m)
#define MSG U"macro" " spelling"
#line 80 "messages.c"
CHECK(1,MSG);
int main(void){CHECK(1,u"block");return 0;}
