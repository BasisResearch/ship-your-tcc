int main(void){_Static_assert(1,"before middle after"); return 0;}
