_Static_assert(1,L"before middle after");
int main(void){return 0;}
