_Static_assert(1,u"before middle after");
int main(void){return 0;}
