_Static_assert(1,L"a" u8"b");
int main(void){return 0;}
