_Static_assert(1,u8"before\0after");
int main(void){return 0;}
