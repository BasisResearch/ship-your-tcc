_Static_assert(1,L"a" u"b");
int main(void){return 0;}
