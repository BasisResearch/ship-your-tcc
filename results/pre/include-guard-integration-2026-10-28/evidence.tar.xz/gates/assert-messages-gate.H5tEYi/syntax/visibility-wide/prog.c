int x __attribute__((visibility(L"default")));
int main(void){return 0;}
