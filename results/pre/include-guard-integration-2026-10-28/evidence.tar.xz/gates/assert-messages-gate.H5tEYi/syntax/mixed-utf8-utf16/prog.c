_Static_assert(1,u8"a" u"b");
int main(void){return 0;}
