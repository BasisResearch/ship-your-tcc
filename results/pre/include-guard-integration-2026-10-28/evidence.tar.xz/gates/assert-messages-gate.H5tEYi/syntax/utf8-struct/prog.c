struct S {_Static_assert(1,u8"before middle after"); int n;};
int main(void){return 0;}
