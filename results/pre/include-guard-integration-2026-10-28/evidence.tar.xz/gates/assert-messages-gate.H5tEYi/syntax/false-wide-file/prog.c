_Static_assert(0,L"before middle after");
int main(void){return 0;}
