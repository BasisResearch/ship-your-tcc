_Static_assert(0,U"before middle after");
int main(void){return 0;}
