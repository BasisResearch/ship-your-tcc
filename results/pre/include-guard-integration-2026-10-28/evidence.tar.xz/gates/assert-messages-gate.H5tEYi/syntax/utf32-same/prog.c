_Static_assert(1,U"raw\x41" U"1" U"\101");
int main(void){return 0;}
