_Static_assert(0,L"before\u00e9after");
int main(void){return 0;}
