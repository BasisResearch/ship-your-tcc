struct S {_Static_assert(1,U"before middle after"); int n;};
int main(void){return 0;}
