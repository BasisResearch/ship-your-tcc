int x; extern int y __attribute__((alias(u"x")));
int main(void){return 0;}
