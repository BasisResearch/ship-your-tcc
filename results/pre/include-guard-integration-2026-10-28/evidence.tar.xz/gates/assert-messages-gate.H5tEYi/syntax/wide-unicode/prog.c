_Static_assert(1,L"before\u00e9\U0001f600after");
int main(void){return 0;}
