_Static_assert(1,U"before" " middle" U" after");
int main(void){return 0;}
