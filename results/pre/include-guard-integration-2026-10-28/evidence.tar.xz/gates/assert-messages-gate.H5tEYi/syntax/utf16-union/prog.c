union U {_Static_assert(1,u"before middle after"); int n;};
int main(void){return 0;}
