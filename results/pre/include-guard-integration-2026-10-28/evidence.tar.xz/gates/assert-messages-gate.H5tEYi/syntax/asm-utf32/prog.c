int x __asm__(U"x");
int main(void){return 0;}
