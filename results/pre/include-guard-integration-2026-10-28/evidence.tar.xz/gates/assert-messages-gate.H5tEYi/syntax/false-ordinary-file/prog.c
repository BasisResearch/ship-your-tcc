_Static_assert(0,"before middle after");
int main(void){return 0;}
