_Static_assert(1,u"before\0after");
int main(void){return 0;}
