union U {_Static_assert(0,u8"before middle after"); int n;};
int main(void){return 0;}
