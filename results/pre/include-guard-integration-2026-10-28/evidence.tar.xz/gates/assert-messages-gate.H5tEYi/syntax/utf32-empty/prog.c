_Static_assert(1,U"" "");
int main(void){return 0;}
