_Static_assert(1,u8"before" " after");
int main(void){return 0;}
