_Static_assert(1,u8"before middle after");
int main(void){return 0;}
