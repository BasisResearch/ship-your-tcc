int x; extern int y __attribute__((alias(U"x")));
int main(void){return 0;}
