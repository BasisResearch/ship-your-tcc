int main(void){_Static_assert(1,u8"before middle after"); return 0;}
