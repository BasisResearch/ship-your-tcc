_Static_assert(1,"before" " after");
int main(void){return 0;}
