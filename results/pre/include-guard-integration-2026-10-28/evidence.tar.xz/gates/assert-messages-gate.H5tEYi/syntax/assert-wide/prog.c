_Static_assert(1,L"wide"); int x;
