_Static_assert(1,L"before" " middle" L" after");
int main(void){return 0;}
