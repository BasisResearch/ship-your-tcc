_Static_assert(1,u"a" U"b");
int main(void){return 0;}
