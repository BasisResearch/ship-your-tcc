_Static_assert(1,U"a" u8"b");
int main(void){return 0;}
