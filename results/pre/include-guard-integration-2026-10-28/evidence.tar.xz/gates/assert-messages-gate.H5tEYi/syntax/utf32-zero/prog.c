_Static_assert(1,U"before\0after");
int main(void){return 0;}
