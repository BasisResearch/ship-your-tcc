int x __attribute__((section(U"x")));
int main(void){return 0;}
