_Static_assert(1,L"a" U"b");
int main(void){return 0;}
