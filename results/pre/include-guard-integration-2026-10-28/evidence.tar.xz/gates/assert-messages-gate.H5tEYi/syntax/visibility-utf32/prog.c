int x __attribute__((visibility(U"default")));
int main(void){return 0;}
