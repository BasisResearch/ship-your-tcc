_Static_assert(1,U"before middle after");
int main(void){return 0;}
