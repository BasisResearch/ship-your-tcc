from pathlib import Path
import sys,subprocess,hashlib,json,time
r=Path.cwd();phase=sys.argv[1];assert phase in ['before','after'];w=r if phase=='before' else r/'.claude/worktrees/sol-c11-line'
paths=(r/'build/guard-pre-corpus-files.txt').read_text().splitlines();assert len(paths)==846
out=w/'build'/f'guard-pre-corpus-{phase}';out.mkdir(exist_ok=False)
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source={p:H(w/p) for p in paths};tools={p:H(w/p) for p in ['.lake/build/bin/pre_spec','build/cross/riscv64-tcc','scripts/pre_diff.py','Spec/Pre/Tcc/Cfg.lean','c/build/fs.list']}
cmd=['python3','scripts/pre_diff.py','--jobs','4','--diagnostic','--out',str(out/'comparison.tsv'),*paths];start=time.time()
with (out/'run.log').open('w') as f:v=subprocess.run(cmd,cwd=w,stdout=f,stderr=subprocess.STDOUT)
assert all(H(w/p)==h for p,h in source.items()) and all(H(w/p)==h for p,h in tools.items())
(out/'receipt.json').write_text(json.dumps(dict(phase=phase,command=cmd,exit=v.returncode,seconds=time.time()-start,sources=source,tools=tools,source_hashes_verified=True,comparison_sha256=H(out/'comparison.tsv') if (out/'comparison.tsv').exists() else None),indent=2)+'\n');print(phase,v.returncode,flush=True)
