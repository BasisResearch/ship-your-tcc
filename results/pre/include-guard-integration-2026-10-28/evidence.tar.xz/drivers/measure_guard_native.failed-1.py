from pathlib import Path
import hashlib,json,subprocess,sys,time,re,lzma,shutil
r=Path.cwd();w=r/'.claude/worktrees/sol-c11-line';rid='guard-openings-full-1';q=json.loads((w/'build'/f'worker-build.{rid}.request').read_text())
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def verify():
 for p,h in q['sha256'].items():assert H(w/p)==h,p
def memory():
 while int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))//1024**2<25:time.sleep(5);verify()
for _ in range(1440):
 p=w/'build'/f'worker-build-{rid}.log'
 if p.exists() and '== (8) CSem gates' in p.read_text():break
 time.sleep(5)
else:raise TimeoutError('full model build not reached')
verify();memory();out=w/'build/guard-openings-native';out.mkdir(exist_ok=False)
cases=['no-final-newline','recursive-guard','leading-trigraph-guard'];inputs=[w/'build/guard-openings-focused-2'/name/'main.c' for name in cases]
source_pins={str(p):H(p) for src in inputs for p in [src,src.with_name('header.h')]};model_hash=H(w/'.lake/build/bin/tcc_model');capture=w/'build/unevaluated-native-tool/capture_cut'
cmd=['python3','scripts/model_diff.py','--no-report','--require-success','3','--json-out',str(out/'arenas.json'),'--sail-capture',str(capture),'-j','1',*map(str,inputs)]
with (out/'arenas.log').open('w') as f:v=subprocess.run(cmd,cwd=w,stdout=f,stderr=subprocess.STDOUT,timeout=7200)
(out/'arenas-command.json').write_text(json.dumps(dict(command=cmd,exit=v.returncode),indent=2)+'\n');assert v.returncode==0
subprocess.run(['python3','scripts/freeze_sail_arenas.py','--report',str(out/'arenas.json'),'--out',str(out/'capture')],cwd=w,check=True)
report=json.loads((out/'arenas.json').read_text());rows=[row for rs in report['results'].values() for row in rs];assert len(rows)==3 and all(x['result']=='same' for x in rows)
cache=w/'build/model_diff/cache';cuts={H(p):p for p in cache.glob('*.sail/cut.json')}
tc=next((Path.home()/'toolchains').glob('xpack-riscv-none-elf-gcc-15.2.0-*/bin'));emu=Path.home()/'Documents/code/ship-your-lua/riscv-lean/lean_emulator/.lake/build/bin/lean_riscv_emulator';results=[]
for row in rows:
 source=w/row['name'];name=source.parent.name;target=out/name;target.mkdir();e=row['sail'];cut=cuts[e['capture_manifest_sha256']];original=Path(str(cut.parent).removesuffix('.sail')+'.elf');assert H(original)==e['elf_sha256'];elf=target/'prog.elf';shutil.copyfile(original,elf)
 for p in [source,source.with_name('header.h')]:assert p.read_bytes() in elf.read_bytes();shutil.copyfile(p,target/p.name)
 nm=subprocess.check_output([str(tc/'riscv-none-elf-nm'),str(elf)],text=True);symbols={x.split()[2]:int(x.split()[0],16) for x in nm.splitlines() if len(x.split())==3}
 dis=subprocess.check_output([str(tc/'riscv-none-elf-objdump'),'-d','--disassemble=_exit',str(elf)],text=True);exitpc=int(next(x.split()[0].rstrip(':') for x in dis.splitlines() if len(x.split())>2 and x.split()[2]=='sd'),16)
 pcs=[symbols['tcc_baremetal_run'],symbols['tcc_baremetal_enter'],exitpc];(target/'pcs').write_text(''.join(hex(x)+'\n' for x in pcs));memory()
 cmd=['systemd-run','--user','--scope','-p','MemoryMax=12G',str(emu),str(elf),'--trace-pcs',str(target/'pcs'),'--max-steps','100000000']
 with (target/'raw').open('wb') as so,(target/'trace').open('wb') as se:done=subprocess.run(cmd,cwd=w,stdout=so,stderr=se,timeout=3600)
 with (target/'stdout').open('wb') as f:subprocess.run(['python3','-I','scripts/sail_console.py',str(target/'raw')],cwd=w,stdout=f,check=True)
 trace=(target/'trace').read_text();assert 'TRACE-FUEL-OUT' not in trace;steps={int(xs[2],16):int(xs[1]) for line in trace.splitlines() if line.startswith('T\t') for xs in [line.split('\t')]};assert all(p in steps for p in pcs)
 assert done.returncode==0 and (target/'stdout').read_bytes()==b'' and H(elf)==e['elf_sha256']
 with lzma.open(target/'prog.elf.xz','wb',preset=0) as f:f.write(elf.read_bytes())
 elf.unlink();rec=dict(case=name,source=str(source),elf_sha256=e['elf_sha256'],capture_manifest_sha256=e['capture_manifest_sha256'],command=cmd,exit=done.returncode,stdout_equal=True,compile_steps=steps[pcs[0]],program_steps=steps[pcs[2]]-steps[pcs[1]]+1,total_steps=steps[pcs[2]]+1,artifacts={p.name:H(p) for p in target.iterdir() if p.is_file()});(target/'receipt.json').write_text(json.dumps(rec,indent=2)+'\n');results.append(rec);print(name,rec['compile_steps'],rec['program_steps'],flush=True)
verify();assert H(w/'.lake/build/bin/tcc_model')==model_hash and all(H(p)==h for p,h in source_pins.items())
(out/'receipt.json').write_text(json.dumps(dict(request_id=rid,source_hashes_verified=True,model_binary_sha256=model_hash,emulator_sha256=H(emu),driver_sha256=H(__file__),source_pins=source_pins,rows=results),indent=2)+'\n');print('Three complete captures and same-ELF executions pass',flush=True)
