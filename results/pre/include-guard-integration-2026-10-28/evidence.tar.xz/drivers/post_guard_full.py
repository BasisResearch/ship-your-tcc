from pathlib import Path
import json,hashlib,subprocess,time
r=Path.cwd();w=r/'.claude/worktrees/sol-c11-line';rid='guard-openings-full-1';q=json.loads((w/'build'/f'worker-build.{rid}.request').read_text());H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for _ in range(2160):
 p=w/'build/worker-build.result'
 if p.exists():
  v=json.loads(p.read_text())
  if v.get('request_id')==rid:
   assert v['exit']==0 and v['source_hashes_verified'];(w/'build'/f'worker-build.{rid}.result').write_bytes(p.read_bytes());break
 time.sleep(5)
else:raise TimeoutError(rid)
assert all(H(w/p)==h for p,h in q['sha256'].items());out=w/'build/guard-openings-post';out.mkdir(exist_ok=False)
bins={n:H(w/'.lake/build/bin'/n) for n in ['tcc_model','tcc_ghost','csem_raw','pre_spec']}
commands=[('multitu',['python3','scripts/multitu_ghost_cmp.py','--build-id',rid,'--out',str(out/'multitu')]),('multitu-arenas',['python3','scripts/multitu_arenas.py','--build-id',rid,'--comparison',str(out/'multitu/comparison.json'),'--out',str(out/'multitu-arenas')])]
for name,opts in [('shared',[]),('component',['--raw']),('independent',['--independent-raw'])]:commands.append((name,['python3','scripts/ghost_cabs_cmp.py','--build-id',rid,'--out',str(out/name),*opts]))
commands.extend([('physical',['python3','scripts/ghost_origins_cmp.py','--build-id',rid,'--out',str(out/'physical')]),('onoff',['python3','scripts/physical_onoff_cmp.py','--build-id',rid,'--out',str(out/'onoff')])])
for name,cmd in commands:
 with (out/(name+'.log')).open('w') as f:v=subprocess.run(['systemd-run','--user','--scope','-p','MemoryMax=12G',*cmd],cwd=w,stdout=f,stderr=subprocess.STDOUT,timeout=7200)
 (out/(name+'.command.json')).write_text(json.dumps(dict(command=cmd,exit=v.returncode),indent=2)+'\n');assert v.returncode==0,(name,v.returncode);print('PASS',name,flush=True)
old=json.loads((w/'build/multitu-physical-integrated/multitu/comparison.json').read_text());new=json.loads((out/'multitu/comparison.json').read_text());source_rows=[]
for a,b in zip(old['rows'],new['rows']):
 assert a['case']==b['case']
 assert [(x['filename'],x['sha256']) for x in a['expected_units']]==[(x['filename'],x['sha256']) for x in b['expected_units']]
 def fs(row):
  cmd=row['runs'][1]['command'];return json.loads((Path(cmd[cmd.index('--ghost-out')+1]).parent/'files.json').read_text())
 assert fs(a)==fs(b),a['case']
 source_rows.append(dict(case=a['case'],same_units=True,same_virtual_files=True,before_exact=a['exact'],after_exact=b['exact']))
assert all(H(w/p)==h for p,h in q['sha256'].items()) and all(H(w/'.lake/build/bin'/n)==h for n,h in bins.items())
(out/'pins.json').write_text(json.dumps(dict(inputs=len(q['sha256']),binaries=bins,driver_sha256=H(Path(__file__)),original_fixture_comparison=source_rows),indent=2)+'\n');print('Guard integration independent postchecks complete',flush=True)
