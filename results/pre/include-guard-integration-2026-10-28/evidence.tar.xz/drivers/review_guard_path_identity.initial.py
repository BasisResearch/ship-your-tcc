from pathlib import Path
import json,hashlib,lzma,subprocess,sys
r=Path.cwd();w=r/'.claude/worktrees/sol-c11-line';sys.path.insert(0,str(w/'scripts'));from ghost_origins_cmp import compare
out=w/'build/guard-path-identity';out.mkdir(exist_ok=False);H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();guard='#ifndef H\n#define H\nextern int retained;\n#endif\n'
cases={
'dot-alias':(['header.h','./header.h','header.h','./header.h'],{'header.h':guard},''),
'parent-alias':(['header.h','dir/../header.h','header.h','dir/../header.h'],{'header.h':guard},''),
'different-basename':(['header.h','twin.h','header.h','twin.h'],{'header.h':guard,'twin.h':guard},''),
'same-basename-different-directory':(['a/header.h','b/header.h','a/header.h','b/header.h'],{'a/header.h':guard,'b/header.h':guard},''),
'predefined-alias':(['header.h','./header.h','header.h','./header.h'],{'header.h':guard},'#define H\n'),
'undefined-between-aliases':(['header.h','./header.h','header.h','./header.h'],{'header.h':guard},'')}
binary=w/'.lake/build/bin/tcc_ghost';host=w/'build/cross/riscv64-tcc';pins={str(p):H(p) for p in [binary,host,Path(__file__),w/'scripts/ghost_origins_cmp.py']};rows=[]
for name,(includes,headers,prefix) in cases.items():
 d=out/name;d.mkdir();(d/'dir').mkdir()
 for path,body in headers.items():p=d/path;p.parent.mkdir(exist_ok=True,parents=True);p.write_text(body)
 src=d/'main.c';src.write_text(prefix+''.join(('#undef H\n' if name=='undefined-between-aliases' and i==1 else '')+'#include "'+h+'"\n' for i,h in enumerate(includes))+'int main(void){return 0;}\n')
 files=d/'files.json';files.write_text(json.dumps([['/'+n,s] for n,s in headers.items()])+ '\n');obs={};runs={}
 for mode,cmd in [('host',[str(host),'-std=c11','-B'+str(host.parent),'-vv','-E',str(src)]),('raw-model',[str(binary),'raw-model',str(src),'--files',str(files)]),('origin-spec',[str(binary),'origin-spec',str(src),'--files',str(files)])]:
  v=subprocess.run(cmd,capture_output=True,timeout=90);(d/(mode+'.stderr')).write_bytes(v.stderr)
  with lzma.open(d/(mode+'.stdout.xz'),'wb',preset=0) as f:f.write(v.stdout)
  runs[mode]=dict(command=cmd,exit=v.returncode,stdout_sha256=hashlib.sha256(v.stdout).hexdigest());assert v.returncode==0,(name,mode,v.stderr)
  if mode!='host':obs[mode]=json.loads(v.stdout)
  else:runs[mode]['opens']=sum(line.startswith('-> ') and any(line.endswith('/'+n) for n in headers) for line in v.stdout.decode().splitlines())
 issue,diff,start=compare(obs['raw-model'],obs['origin-spec']);assert issue is None and diff is None,(name,issue,diff)
 model_opens=len([x for x in obs['raw-model']['sources'] if not x.get('generated')])-2;spec_opens=len(obs['origin-spec']['sources'])-2
 assert model_opens==spec_opens==runs['host']['opens']==2,(name,model_opens,spec_opens,runs['host']['opens'])
 rows.append(dict(case=name,source_sha256=H(src),files_sha256=H(files),runs=runs,opens=2,user_token_start=start,exact=True));print(name,'2 exact opened spellings',flush=True)
assert all(H(Path(p))==h for p,h in pins.items())
(out/'report.json').write_text(json.dumps(dict(scope='Supplemental post-freeze cases; not part of35-case maintained gate',pins=pins,rows=rows),indent=2)+'\n')
