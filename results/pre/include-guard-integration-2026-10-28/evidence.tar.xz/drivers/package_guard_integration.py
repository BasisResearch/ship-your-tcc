from pathlib import Path
import json,hashlib,tarfile,re,sys
r=Path.cwd();w=r/'.claude/worktrees/sol-c11-line';rid='guard-openings-full-1'
out=w/'results/pre/include-guard-integration-2026-10-28';out.mkdir(exist_ok=True)
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();files={}
def tree(path,prefix):
 assert path.exists(),path
 for p in path.rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts:files[prefix+'/'+str(p.relative_to(path))]=p
q=json.loads((w/'build'/f'worker-build.{rid}.request').read_text());v=json.loads((w/'build'/f'worker-build.{rid}.result').read_text())
assert v['exit']==0 and v['source_hashes_verified'] and len(q['sha256'])==4163
assert all(H(w/p)==h for p,h in q['sha256'].items())
post=w/'build/guard-openings-post';native=w/'build/guard-openings-native'
assert (post/'pins.json').exists() and (native/'receipt.json').exists()
for suffix in ['request','result']:files['gate/'+suffix+'.json']=w/'build'/f'worker-build.{rid}.{suffix}'
files['gate/log.txt']=w/'build'/f'worker-build-{rid}.log';log=files['gate/log.txt'].read_text();assert log.rstrip().endswith('check: OK')
files['runtime/image.syms']=w/'build/image.syms'
for d,prefix in [(post,'post'),(native,'new-native'),(w/'build/guard-openings-focused-1','focused-1'),(w/'build/guard-openings-focused-2','focused-2'),(r/'build/include-guard-opening-review/expanded-before','before32'),(r/'build/guard-pre-corpus-before','corpus-before'),(w/'build/guard-pre-corpus-after','corpus-after'),(w/'build/guard-path-identity','path-initial'),(w/'build/guard-path-identity-2','path-corrected')]:tree(d,prefix)
files['corpus-comparison.json']=r/'build/guard-pre-corpus-comparison.json';files['corpus-copied-inputs.json']=r/'build/guard-pre-corpus-copied-inputs.json'
for p in ['package_guard_integration.py','post_guard_full.py','measure_guard_native.py','measure_guard_native.failed-1.py','guard-native-service.log','guard-native-service-2.log','guard_pre_corpus.py','guard-pre-corpus-after-service.log','request_guard_build.py','guard-pre-corpus-files.txt','check_include_guard_openings.py','review_guard_path_identity.py','review_guard_path_identity.initial.py','guard-path-identity-review.log','guard-path-identity-review-2.log']:
 files['drivers/'+p]=r/'build'/p
# Reproduce each frozen epoch from its original archive, never from final bytes.
objects=w/'build/guard-source-objects';objects.mkdir(exist_ok=True)
requests=[]
for p in sorted((w/'build').glob('worker-build.guard-openings-*.request')):
 req=json.loads(p.read_text());name=req['request_id'];res=p.with_suffix('.result');assert res.exists(),res
 value=json.loads(res.read_text());assert value['request_id']==name and value['source_hashes_verified']
 requests.append(name)
 for f in [p,res,w/value['log']]:files['builds/'+f.name]=f
 with tarfile.open(w/'build'/f'sources.{name}.tar.xz') as t:
  index={m.name:m for m in t.getmembers()};assert len(index)==len(req['sha256'])
  for path,h in req['sha256'].items():
   b=t.extractfile(index[path]).read();assert hashlib.sha256(b).hexdigest()==h
   dest=objects/h
   if not dest.exists():dest.write_bytes(b)
   else:assert H(dest)==h
   files['sources/'+h]=dest
# Supplemental broad corpus inputs/siblings are explicitly separate from the gate.
supplemental={};sources=json.loads((r/'build/guard-pre-corpus-before/receipt.json').read_text())['sources']
for name,h in sources.items():assert H(r/name)==H(w/name)==h
for parent in sorted({(r/name).parent for name in sources}):
 for p in parent.glob('*'):
  if p.is_file():
   key=str(p.relative_to(r));h=H(p);supplemental[key]=h;files['sources/'+h]=p
roots=re.findall(r'^(?:unevaluated syntax artifacts|assertion message artifacts|GNU expression artifacts|array decay artifacts|include guard artifacts): (.+)$',log,re.M);assert len(roots)==5,roots
sys.path.insert(0,str(w/'scripts'));from freeze_sail_arenas import freeze
exports=w/'build/guard-gate-native-exports';exports.mkdir(exist_ok=True);index=[]
for root in roots:
 tree(w/root,'gates/'+Path(root).name)
 for report in (w/root).rglob('arenas.json'):
  if not json.loads(report.read_text()).get('sail_settings'):continue
  prefix=str(len(index));target=exports/prefix
  info=json.loads((target/'inventory.json').read_text()) if target.exists() else freeze(report,target)
  assert info['successes']==1 and info['report_sha256']==H(report)
  index.append(dict(prefix=prefix,report='gates/'+str(report.relative_to(w/Path(root).parent)),inventory=info))
assert len(index)==6;tree(exports,'gate-native')
(out/'native-index.json').write_text(json.dumps(index,indent=2)+'\n')
(out/'supplemental-inputs.json').write_text(json.dumps(supplemental,indent=2)+'\n')
runtime=[]
for name in ['c/build/fs.list','c/build/base.elf','c/build/crt0.o','c/build/htif.o','c/build/main.o','c/build/tcc.o']:
 files['runtime/'+name]=w/name
for line in (w/'c/build/fs.list').read_text().splitlines():
 if not line.strip():continue
 guest,host=line.split('=',1);p=Path(host);p=p if p.is_absolute() else w/p
 h=H(p);key='runtime-fs/'+h;files[key]=p;runtime.append(dict(guest=guest,host=host,sha256=h,object=key))
assert len(runtime)==153
assert H(w/'c/build/base.elf')==json.loads((native/'arenas.json').read_text())['pins']['c/build/base.elf']
references={p:H(w/p) for p in ['results/model/multitu-physical-integration-2026-10-28/pins.json','results/pre/include-guard-opening-review-2026-10-28/pins.json']}
manifest={name:H(p) for name,p in files.items()};archive=out/'evidence.tar.xz';assert not archive.exists()
with tarfile.open(archive,'w:xz',preset=3,dereference=True) as t:
 for name,p in sorted(files.items()):t.add(p,arcname=name,recursive=False)
assert all(H(w/p)==h for p,h in q['sha256'].items())
(out/'pins.json').write_text(json.dumps(dict(archive_sha256=H(archive),native_index_sha256=H(out/'native-index.json'),supplemental_sha256=H(out/'supplemental-inputs.json'),requests=requests,inputs=len(q['sha256']),runtime_fs=runtime,references=references,members=manifest),indent=2)+'\n')
print('Packaged',len(manifest),'members;5 source epochs,35 controls,846 corpus inputs,3 fresh native executions',flush=True)
