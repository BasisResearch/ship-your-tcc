from pathlib import Path
import json,hashlib,subprocess,tarfile,sys
r=Path.cwd();w=r/'.claude/worktrees/sol-c11-line';rid=sys.argv[1];targets=sys.argv[2:];assert rid.startswith('guard-openings-')
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=w).decode().split('\0')
selected={p for p in paths if p and (w/p).is_file() and not p.startswith(('results/','tasks/','docs/')) and not p.endswith('.md')}
base=json.loads((w/'build/worker-build.multitu-physical-integrated-1.request').read_text())
selected|={p for p in base['sha256'] if (w/p).is_file() and p.startswith('results/')}
pins={p:hashlib.sha256((w/p).read_bytes()).hexdigest() for p in sorted(selected)}
q=dict(request_id=rid,cwd=str(w),source_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),targets=targets,sha256=pins)
if not targets:q['kind']='full-gate-validation'
p=w/'build'/f'worker-build.{rid}.request';assert not p.exists();p.write_text(json.dumps(q,indent=2)+'\n')
with tarfile.open(w/'build'/f'sources.{rid}.tar.xz','w:xz',dereference=True) as t:
 for name in pins:t.add(w/name,arcname=name,recursive=False)
(w/'build/worker-build.request').write_bytes(p.read_bytes());print(rid,len(pins),flush=True)
