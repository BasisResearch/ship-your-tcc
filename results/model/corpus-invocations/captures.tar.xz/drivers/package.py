from pathlib import Path
import hashlib,json,tarfile,gzip,shutil,sys
root=Path(__file__).resolve().parents[1];w=root/'.claude/worktrees/sol-c11-line';out=w/'results/model/corpus-invocations';out.mkdir(exist_ok=True)
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(w/'scripts'))
import model_diff as m
from source_fixtures import load_invocation
files={}
for p in (w/'build/inline-bundle-review').rglob('*'):
 if p.is_file():files['observations/'+str(p.relative_to(w/'build/inline-bundle-review'))]=p
for p in w.glob('build/inline-bundle-*.log'):files['logs/'+p.name]=p
files['logs/full-gate.log']=w/'build/worker-build-invocation-integrated-1.log'
files['drivers/package.py']=Path(__file__)
for n in ['scripts/model_diff.py','scripts/source_fixtures.py','scripts/tests/test_corpus_invocations.py','c/invocations/tinycc-104-inline.json','vendor/tinycc/tests/tests2/Makefile','vendor/tinycc/tests/tests2/104_inline.c','vendor/tinycc/tests/tests2/104+_inline.c']:
 files['inputs/'+n]=w/n
q=json.loads((w/'build/worker-build.invocation-integrated-1.request').read_text());r=json.loads((w/'build/worker-build.invocation-integrated-1.result').read_text())
assert r['exit']==0 and r['source_hashes_verified'] and q['request_id']==r['request_id'];assert all(H(w/p)==h for p,h in q['sha256'].items())
for n,d in [('gate.request',q),('gate.result',r)]: (out/(n+'.json.gz')).write_bytes(gzip.compress(json.dumps(d,indent=2).encode(),mtime=0))
index=[]
for name in ['native','native-final']:
 d=json.loads((w/f'build/inline-bundle-review/{name}.json').read_text());assert d['totals']=={'n':1,'same':1}
 row=d['results']['invocations'][0];a=load_invocation(w/'c/invocations/tinycc-104-inline.json',w);p=Path(a['source']);extra=a['extra'];args=a['args']
 key=m.sha('independent-c11-handoff-v4',p.read_bytes(),repr(extra),repr(args),repr([]),d['runtime_key'],(w/'c/src/gen_embed.sh').read_bytes(),*[Path(h).read_bytes() for _,h in extra]);key=m.sha(key,'native-sail-full-arena-v1',json.dumps(d['sail_settings'],sort_keys=True))
 base=w/'build/model_diff/cache'/key
 for suffix in ['.arena','.console','.status','.sail.json','.sail.log']:files[f'{name}/reference{suffix}']=Path(str(base)+suffix)
 for p in Path(str(base)+'.sail').rglob('*'):
  if p.is_file():files[f'{name}/capture/'+str(p.relative_to(Path(str(base)+'.sail')))]=p
 model=w/'build/model_diff/work'/(m.sha('c/invocations/tinycc-104-inline.json','c')+'.arena');assert H(model)==row['sail']['model_arena_sha256'];files[f'{name}/model.arena']=model
 assert row['sail']['status']=='equal' and row['sail']['compared_bytes']==4194304
 index.append(dict(name=name,cache_key=key,model_sha256=H(model),steps=row['sail']['steps'],adopted=name=='native-final'))
(out/'native-index.json').write_text(json.dumps(index,indent=2)+'\n')
for n in ['native-final','standalone','historical-special-invocations','lead-review']:shutil.copyfile(w/f'build/inline-bundle-review/{n}.json',out/(n+'.json'))
manifest={n:H(p) for n,p in files.items()}
with tarfile.open(out/'captures.tar.xz','w:xz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(out/'captures.tar.xz') as t:assert {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t.getmembers() if m.isfile()}==manifest
(out/'pins.json').write_text(json.dumps(dict(archive_members=manifest,artifacts={p.name:H(p) for p in out.iterdir() if p.is_file() and p.name not in ['pins.json','verify.py']}),indent=2)+'\n')
print(len(manifest),'verified captures,',len(q['sha256']),'gate inputs')
