from pathlib import Path
import subprocess,json,time,concurrent.futures,shutil
root=Path.cwd();w=root/'.claude/worktrees/sol-c11-line';rid='unevaluated-integrated-1';out=w/'build/unevaluated-integrated';out.mkdir(exist_ok=True)
while True:
 p=w/'build/worker-build.result'
 if p.exists():
  d=json.loads(p.read_text())
  if d.get('request_id')==rid:
   assert d['exit']==0 and d['source_hashes_verified'],d
   shutil.copyfile(p,w/f'build/worker-build.{rid}.result');break
 time.sleep(5)
commands=[('focused',['python3','scripts/unevaluated_syntax_cmp.py','--build-id',rid,'--out',str(out/'focused')]),('physical',['python3','scripts/ghost_origins_cmp.py','--build-id',rid,'--out',str(out/'physical')]),
 ('shared',['python3','scripts/ghost_cabs_cmp.py','--build-id',rid,'--out',str(out/'shared')]),
 ('raw-component',['python3','scripts/ghost_cabs_cmp.py','--build-id',rid,'--raw','--out',str(out/'raw-component')]),
 ('independent',['python3','scripts/ghost_cabs_cmp.py','--build-id',rid,'--independent-raw','--out',str(out/'independent')]),
 ('onoff',['python3','scripts/physical_onoff_cmp.py','--build-id',rid,'--out',str(out/'onoff')]),
 ('authority',['python3','scripts/injected_origins_cmp.py','--build-id',rid,'--out',str(out/'authority')])]
def run(item):
 name,cmd=item
 with (out/(name+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=w,stdout=f,stderr=subprocess.STDOUT)
 print(name,r.returncode,flush=True);return name,r.returncode
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(run,commands))
(out/'comparison-exits.json').write_text(json.dumps(dict(results),indent=2)+'\n');assert all(code==0 for _,code in results)
