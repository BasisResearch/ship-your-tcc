# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
typedef
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
        struct
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
               {
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                 long
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                      a
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                       ,
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                        b
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                         ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                           }
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                             Wide
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                  __attribute__
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                               (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                 aligned
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                        (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                         16
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                           )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                            )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                             )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                              ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                                typedef
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                                        Wide
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                                             A
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                                              [
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                                               2
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                                                ]
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                                                 ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
    main
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
        (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
         void
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
             )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
              {
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
               return
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                      (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                       _Alignof
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                               (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                A
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                 )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                  !=
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                    16
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                       ||
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                          sizeof
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                 A
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                  )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                   !=
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                     32
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                        ||
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                           _Alignof
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                                   (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                                    Wide
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                                        )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                                         !=
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                                           16
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                                             )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                                              ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/aggregate-array/input.c"
                                                                               }

