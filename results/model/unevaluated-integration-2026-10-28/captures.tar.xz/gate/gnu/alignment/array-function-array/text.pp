# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-function-array/input.c"
int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-function-array/input.c"
    f
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-function-array/input.c"
     [
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-function-array/input.c"
      1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-function-array/input.c"
       ]
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-function-array/input.c"
        (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-function-array/input.c"
         void
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-function-array/input.c"
             )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-function-array/input.c"
              ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-function-array/input.c"
                int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-function-array/input.c"
                    main
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-function-array/input.c"
                        (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-function-array/input.c"
                         void
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-function-array/input.c"
                             )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-function-array/input.c"
                              {
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-function-array/input.c"
                               return
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-function-array/input.c"
                                      0
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-function-array/input.c"
                                       ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-function-array/input.c"
                                        }
