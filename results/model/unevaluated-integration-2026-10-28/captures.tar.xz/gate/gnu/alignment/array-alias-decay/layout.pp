# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
typedef
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
        int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
            A
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
             [
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
              2
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
               ]
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                 __attribute__
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                              (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                               (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                aligned
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                       (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                        32
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                          )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                           )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                            )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                             ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                               A
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                 a
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                  ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                    int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                        main
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                            (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                             void
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                 )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                  {
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                   return
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                          _Alignof
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                  (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                   __typeof__
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                             (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                              a
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                               )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                                )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                                 !=
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                                   32
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                                      ||
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                                         _Alignof
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                                                 (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                                                  __typeof__
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                                                            (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                                                             a
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                                                              +
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                                                               0
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                                                                )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                                                                 )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                                                                  !=
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                                                                    8
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                                                                      ||
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                                                                         __alignof__
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                                                                                    (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                                                                                     a
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                                                                                      )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                                                                                       !=
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                                                                                         32
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                                                                                           ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/gnu-attribute-gate.T9qOp8/alignment/array-alias-decay/input.c"
                                                                                                                                                            }

