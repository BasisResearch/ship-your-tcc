# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
typedef
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
        int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
            Up
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
               __attribute__
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                            (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                             (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                              aligned
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                     (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                      16
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                        )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                         )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                          )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                           ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
typedef
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
        int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
            Down
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                 __attribute__
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                              (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                               (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                aligned
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                       (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                        1
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                         )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                          )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                           )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                            ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
typedef
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
        Up
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
           Again
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
typedef
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
        Down
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
             Strong
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                    __attribute__
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                 (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                  (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                   aligned
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                          (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                           32
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                             )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                              )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                               )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                                ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                                  typedef
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                                          Strong
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                                                 S
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                                                  ;
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
int
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
    main
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
        (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
         void
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
             )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
              {
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
               return
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                      (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                       _Alignof
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                               (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                S
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                 )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                  !=
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                    32
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                       ||
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                          sizeof
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                                (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                                 S
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                                  )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                                   !=
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                                     4
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                                       ||
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                                          _Alignof
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                                                  (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                                                   Down
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                                                       )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                                                        !=
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                                                          1
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                                                           )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                                                            ;
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/stronger.c"
                                                                             }

