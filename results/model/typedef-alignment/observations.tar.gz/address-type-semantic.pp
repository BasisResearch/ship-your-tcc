# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
typedef
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
        int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
            Up
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
               __attribute__
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                            (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                             (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                              aligned
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                     (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                      16
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                        )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                         )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                          )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                           ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
typedef
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
        int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
            Down
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                 __attribute__
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                              (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                               (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                aligned
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                       (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                        1
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                         )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                          )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                           )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                            ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
typedef
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
        Up
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
           Again
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
Up
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
   x
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
    ;
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
int
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
    main
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
        (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
         void
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
             )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
              {
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
               return
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                      (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                       _Alignof
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                               (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                __typeof__
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                          (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                           &
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                            x
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                             )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                              )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                               !=
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                                 sizeof
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                                       (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                                        void
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                                            *
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                                             )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                                               ||
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                                                  _Alignof
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                                                          (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                                                           __typeof__
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                                                                     (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                                                                      (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                                                                       Up
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                                                                         )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                                                                          1
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                                                                           )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                                                                            )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                                                                             !=
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                                                                               4
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                                                                                )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                                                                                 ;
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/address-type.c"
                                                                                                  }

