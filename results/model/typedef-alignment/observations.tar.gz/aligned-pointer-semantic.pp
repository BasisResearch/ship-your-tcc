# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
typedef
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
        int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
            Up
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
               __attribute__
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                            (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                             (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                              aligned
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                     (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                      16
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                        )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                         )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                          )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                           ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
typedef
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
        int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
            Down
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                 __attribute__
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                              (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                               (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                aligned
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                       (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                        1
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                         )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                          )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                           )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                            ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
typedef
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
        Up
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
           Again
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
typedef
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
        Up
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
           *
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
            P
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
              __attribute__
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                           (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                            (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                             aligned
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                    (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                     32
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                       )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                        )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                         )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                          ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                            typedef
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                                    P
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                                      *
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                                       PP
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                                         ;
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
int
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
    main
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
        (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
         void
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
             )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
              {
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
               return
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                      (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                       _Alignof
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                               (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                P
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                 )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                  !=
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                    32
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                       ||
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                          _Alignof
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                                  (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                                   PP
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                                     )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                                      !=
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                                        sizeof
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                                              (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                                               void
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                                                   *
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                                                    )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                                                      ||
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                                                         sizeof
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                                                               (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                                                                P
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                                                                 )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                                                                  !=
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                                                                    sizeof
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                                                                          (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                                                                           void
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                                                                               *
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                                                                                )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                                                                                 )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                                                                                  ;
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/aligned-pointer.c"
                                                                                                   }

