from pathlib import Path
import re,json,hashlib
root=Path.cwd();src=root/'build/tcc-src'
files=['tccgen.c','riscv64-gen.c','tccelf.c','libtcc.c','tccrun.c','tccpp.c','riscv64-asm.c','tccasm.c']
rows=[]
for name in files:
 p=src/name
 for i,line in enumerate(p.read_text().splitlines(),1):
  if re.search(r'\b(?:CType|SValue|Sym)\b',line) and not line.lstrip().startswith(('*','/*','//')):
   if re.search(r'\b(?:CType|SValue|Sym)\b[^;]*;',line) and '(' not in line:
    rows.append(dict(file=name,line=i,declaration=line.strip()))
json.dump(dict(source_hashes={n:hashlib.sha256((src/n).read_bytes()).hexdigest() for n in files},declarations=rows),open(root/'build/typedef-final4/constructor-audit.json','w'),indent=2)
print('inventoried',len(rows),'declarations in',len(files),'C closure files')
# Fail if a fresh scratch constructor or the return lowering loses initialization.
s=(src/'tccgen.c').read_text()
for needle in ['SValue *p, *p1, sv = {0};','SValue ret = {0};','SValue store = {0};','SValue sv = {0};','vtop->query_aligned = 0;','s->type.aligned = type->aligned','type->aligned = 0;']:
 assert needle in s,needle
assert 'ret->aligned = 0;' in (src/'riscv64-gen.c').read_text()
# Backend labels are explicitly zeroed; its CType scratch has a dominating
# whole-value copy before the first type_size/load. Assembly SValues likewise
# copy complete operands; none constructs a query from a partial CType.
s=(src/'riscv64-gen.c').read_text();assert s.count('Sym label = {0};')==3
assert s.index('origtype = vtop->type;') < s.index('size = type_size(&vtop->type',s.index('CType origtype;'))
print('fresh-constructor and backend-label/return checks pass; source review still required')
