# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
typedef
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
        int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
            Up
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
               __attribute__
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                            (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                             (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                              aligned
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                     (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                      16
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                        )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                         )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                          )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                           ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
typedef
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
        int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
            Down
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                 __attribute__
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                              (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                               (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                aligned
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                       (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                        1
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                         )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                          )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                           )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                            ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
typedef
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
        Up
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
           Again
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
typedef
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
        __attribute__
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                     (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                      (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                       aligned
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                              (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                               2
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                 )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                  )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                    Up
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                       Weak
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                           ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                             typedef
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                                     __attribute__
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                                                  (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                                                   (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                                                    __aligned__
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                                                               (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                                                                32
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                                                                  )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                                                                   )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                                                                    )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                                                                      Down
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                                                                           Strong
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                                                                                 ;
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
int
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
    main
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
        (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
         void
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
             )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
              {
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
               return
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                      (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                       _Alignof
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                               (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                Weak
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                    )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                     !=
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                       2
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                         ||
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                            _Alignof
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                                    (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                                     Strong
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                                           )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                                            !=
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                                              32
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                                                )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                                                 ;
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/typedef-final4/semantic-inputs/prefix-attribute.c"
                                                                  }

