from pathlib import Path
import json,hashlib,subprocess,tarfile,shutil,sys,re
root=Path.cwd();out=root/'build/typedef-final4';dest=root/'results/model/typedef-alignment';dest.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
# Successful receipts certify all maintained build inputs, not just revision.
for rid in ['typedef-build-4','typedef-gate-3']:
 req=json.loads((root/f'build/worker-build.{rid}.request').read_text());res=json.loads((root/f'build/worker-build.{rid}.result').read_text());assert res['request_id']==rid and res['exit']==0 and res['source_hashes_verified']
 assert all(sha(root/p)==h for p,h in req['sha256'].items())
for label,expected in [('focused',33),('broad',1496),('semantic',28)]:
 v=json.loads((out/f'{label}-arenas.json').read_text());assert v['totals']['same']==expected
 assert all(sha(root/p)==h for p,h in v['pins'].items())
 assert all(x['result'] in ('same','same-refusal') for xs in v['results'].values() for x in xs)
assert (out/'backend.exit').read_text().strip()=='0'
assert 'pass=76 fail=0' in (out/'backend.log').read_text()
assert (out/'c11.log').read_text().splitlines()[-1]=='C11: 181 positive cases, 22 negative cases; all passed'
expected={'original':'4 16 16 32 | 4 1 1 5 | 16\n','address':'expression-address=0\n','function-typeof':'function-typeof=0\n'}
for n,s in expected.items():
 assert (out/f'full/{n}.stdout').read_text()==s and (out/f'full/{n}.exit').read_text().strip()=='0'
assert (out/'ctype-layout.exit').read_text().strip()=='0'
# All three materializations must be the exact same patched C source.
closure=['tcc.h','tccgen.c','riscv64-gen.c','tccelf.c','libtcc.c','tccrun.c','tccpp.c','tccasm.c','riscv64-asm.c']
for name in closure:
 vals=[sha(root/d/name) for d in ['build/tcc-src','c/build/tcc-src','build/typedef-native-src']];assert len(set(vals))==1,name
model=sorted((root/'Tcc/Model').glob('*.lean'))
source_paths=[root/'patches'/n for n in ['0001-tcc-rv64i-soft.patch','0002-tcc-baremetal-run.patch','0003-tcc-c11.patch','0004-tcc-binary128-literals.patch']]+model
source_paths += [root/'build/tcc-src'/n for n in closure]+[root/'c/build/tcc-src'/n for n in closure]
source_paths += [root/p for p in ['scripts/gen_typedef_alignment_fixtures.py','scripts/test_tcc_c11.py','scripts/typedef_build_request.py','scripts/model_diff.py','scripts/source_fixtures.py','scripts/run_tcc_sail.sh','scripts/test_tcc_patch.sh','scripts/run_xgcc_sail.sh','scripts/tcc_src.sh','c/src/tcc-config/config.h','c/Makefile','vendor/TINYCC_REV','build/typedef-edit/baseline.patch','build/typedef-baseline-source/tccgen.c','build/typedef-baseline-source/tcc.h']]
source_pins={str(p.relative_to(root)):sha(p) for p in source_paths}
(out/'source-pins.json').write_text(json.dumps(source_pins,indent=2)+'\n')
binary_paths=[root/p for p in ['.lake/build/bin/tcc_model','.lake/build/bin/tcc_pre_tokens','.lake/build/bin/pre_spec','.lake/build/bin/tcc_ghost','.lake/build/bin/csem_raw','build/cross/riscv64-tcc','build/cross/riscv64-libtcc1.a','build/typedef-native/tcc','build/typedef-baseline-host/tcc','c/build/base.elf','c/build/tcc.o','build/image.syms','build/typedef-final4/gnu-csem-raw']]
for n in expected:
 text=(out/f'full/{n}.stderr').read_text();work=Path(re.search(r'^work: (.+)$',text,re.M).group(1));target=out/'full'/n;target.mkdir(exist_ok=True)
 for name in ['prog.elf','embed.S','pcs','trace','raw','ld.log','make.log']:
  p=work/name
  if p.is_file():shutil.copyfile(p,target/name)
 binary_paths.append(target/'prog.elf')
 for name in ['pcs','trace','raw']:
  if (target/name).exists():assert 'TRACE-FUEL-OUT' not in (target/name).read_text(errors='replace')
(out/'binary-pins.json').write_text(json.dumps({str(p.relative_to(root)):sha(p) for p in binary_paths},indent=2)+'\n')
# The ordered embedded filesystem pins all compiler headers/runtime archives.
fs={}
for line in (root/'c/build/fs.list').read_text().splitlines():
 if line:
  virtual,host=line.split('=',1);fs[virtual]=dict(path=host,sha256=sha(host))
(out/'image-files.json').write_text(json.dumps(fs,indent=2)+'\n')
# Retain the focused independent arenas; do not invoke either engine here.
sys.path.insert(0,str(root/'scripts'));import model_diff as md
v=json.loads((out/'focused-arenas.json').read_text());index=[]
for xs in v['results'].values():
 for row in xs:
  if row['result']!='same':continue
  name=row['name'];prog=str(root/name);extra=[(virtual,str(host)) for virtual,host in md.fixture_entries(prog)];args=['-w'];libs=[]
  key=md.sha('independent-c11-handoff-v4',Path(prog).read_bytes(),repr(extra),repr(args),repr(libs),v['runtime_key'],(root/'c/src/gen_embed.sh').read_bytes(),*[Path(h).read_bytes() for _,h in extra])
  reference=root/'build/model_diff/cache'/f'{key}.arena';modeled=root/'build/model_diff/work'/f'{md.sha(name,"c")}.arena'
  assert reference.read_bytes()==modeled.read_bytes(),name
  target=out/'arenas'/Path(name).stem;target.mkdir(parents=True,exist_ok=True)
  shutil.copyfile(reference,target/'reference.arena');shutil.copyfile(modeled,target/'model.arena')
  index.append(dict(source=name,sha256=sha(reference),bytes=reference.stat().st_size))
(out/'arena-index.json').write_text(json.dumps(index,indent=2)+'\n')
# Failed observations and receipts stay separate from the final checks.
stage=out/'receipts';stage.mkdir(exist_ok=True)
for p in (root/'build').glob('worker-build*typedef*'):
 if p.is_file():shutil.copyfile(p,stage/p.name)
shutil.copyfile(root/'build/lead-note.txt',stage/'lead-note.txt')
for folder in ['typedef-baseline','typedef-attempt1-full']:
 p=root/'build'/folder
 if p.exists():shutil.copytree(p,out/'historical'/folder,dirs_exist_ok=True)
for name in ['typedef-c11-attempt1.log','typedef-expression-gcc.stdout','typedef-expression-tcc.stdout','typedef-expression-tcc2.stdout','typedef-attempt1-backend.tar.gz','typedef-lua-inventory.txt']:
 p=root/'build'/name
 if p.exists():
  target=out/'historical'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
# Full final compiler test artifacts and generated inputs are retained verbatim.
shutil.copytree(root/'build/test-tcc',out/'backend-artifacts',dirs_exist_ok=True)
shutil.copytree(root/'build/typedef-fixtures-final4',out/'fixtures',dirs_exist_ok=True)
shutil.copyfile(root/'build/test-c11/commands.json',out/'c11-commands.json')
shutil.copyfile(root/'build/typedef-final3/function-typeof.c',out/'historical/function-typeof.c')
for n in ['gcc','tcc']:shutil.copyfile(root/f'build/typedef-final3/function-typeof.{n}.stdout',out/f'historical/function-typeof.{n}.stdout')
# Keep the optional failed native capture diagnostics, including their exact cause.
for n in ['native-arenas.json','native-arenas.log','native-arenas.exit']:
 shutil.copyfile(root/'build/typedef-final4'/n,out/'historical'/n)
for p in (root/'build/model_diff/cache').glob('*.sail.log'):
 if 'Failed to connect to user scope bus' in p.read_text(errors='replace'):
  shutil.copyfile(p,out/'historical'/p.name)
archive=dest/'observations.tar.gz'
files=sorted(p for p in out.rglob('*') if p.is_file() and p.name not in ('gnu-csem-raw','sem.exe'))
with tarfile.open(archive,'w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(out)),recursive=False)
manifest=dict(base_revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),archive_sha256=sha(archive),members_sha256={str(p.relative_to(out)):sha(p) for p in files},build='typedef-build-4',gate='typedef-gate-3',counts=dict(native_positives=32,constraints=7,c11_positives=181,c11_negatives=22,backend_sail_pairs=76,focused_arenas=33,focused_refusals=7,broad_arenas=1496,broad_refusals=122,broad_attempts=1618,same_input_semantic_arenas=28,full_compiler_sail=3),primary_source_hashes={p:source_pins[p] for p in ['build/tcc-src/tcc.h','build/tcc-src/tccgen.c','build/tcc-src/riscv64-gen.c','Tcc/Model/Types.lean','Tcc/Model/Gen3.lean','Tcc/Model/Gen4.lean']})
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
# Verify the archive independently, without printing manifests.
with tarfile.open(archive) as tar:
 for n,h in manifest['members_sha256'].items():assert hashlib.sha256(tar.extractfile(n).read()).hexdigest()==h,n
print('verified archive',len(files),'files',archive.stat().st_size,'bytes; 3,195 frozen build inputs unchanged')
