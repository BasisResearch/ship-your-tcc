#include <stddef.h>
#include <stdio.h>
typedef int Up __attribute__((aligned(16)));
typedef int Down __attribute__((aligned(1)));
typedef Up Again;
int main(void){int bad=0;
 {typedef Down Up; typedef Up Local; bad|=_Alignof(Up)!=1 || _Alignof(Local)!=1;}
 bad|=_Alignof(Up)!=16;
 {typedef Up Down; bad|=_Alignof(Down)!=16;}
 {int Up=3; bad|=_Alignof(__typeof__(Up))!=4 || Up!=3;}
 bad|=_Alignof(Down)!=1; printf("scopes=%d\n",bad);return bad;}
