#include <stddef.h>
#include <stdio.h>
int arr[3] __attribute__((aligned(32)));
int main(void){int bad=(__alignof__(arr)!=32 || __alignof__(&arr)!=sizeof(void*) || sizeof(arr)!=12 || _Alignof(__typeof__(arr))!=4); printf("expression-array=%d\n",bad);return bad;}
