typedef int Bad __attribute__((aligned(3)));
int main(void){return 0;}
