typedef int Bad __attribute__((aligned(-2)));
int main(void){return 0;}
