typedef void V; typedef V Bad[2];
int main(void){return 0;}
