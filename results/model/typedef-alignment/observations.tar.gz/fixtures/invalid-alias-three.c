typedef int Up __attribute__((aligned(16)));
typedef int Down __attribute__((aligned(1)));
typedef Up Again;
typedef Up Bad __attribute__((aligned(3)));
int main(void){return 0;}
