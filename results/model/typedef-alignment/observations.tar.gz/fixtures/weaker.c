#include <stddef.h>
#include <stdio.h>
typedef int Up __attribute__((aligned(16)));
typedef int Down __attribute__((aligned(1)));
typedef Up Again;
typedef Again Weak __attribute__((aligned(2))); typedef Weak W;
int main(void){int bad=(_Alignof(W)!=2 || sizeof(W)!=4 || _Alignof(Up)!=16); printf("weaker=%d\n",bad);return bad;}
