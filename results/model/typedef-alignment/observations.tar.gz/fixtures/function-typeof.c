#include <stddef.h>
#include <stdio.h>
typedef int Up __attribute__((aligned(16)));
typedef int Down __attribute__((aligned(1)));
typedef Up Again;
typedef Up F(void); typedef __typeof__(F) TF; typedef F *FP;
int main(void){int bad=(_Alignof(F)!=_Alignof(int(void)) || _Alignof(TF)!=_Alignof(F) || _Alignof(__typeof__(F))!=_Alignof(F) || _Alignof(FP)!=sizeof(void*)); printf("function-typeof=%d\n",bad);return bad;}
