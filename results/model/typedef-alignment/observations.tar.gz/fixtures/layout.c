#include <stddef.h>
#include <stdio.h>
typedef int Up __attribute__((aligned(16)));
typedef int Down __attribute__((aligned(1)));
typedef Up Again;
struct U {char c; Up x;}; struct D {char c; Down x;};
int main(void){int bad=(offsetof(struct U,x)!=16 || sizeof(struct U)!=32 || _Alignof(struct U)!=16 || offsetof(struct D,x)!=1 || sizeof(struct D)!=5 || _Alignof(struct D)!=1 || sizeof(Up)!=4 || sizeof(Down)!=4); printf("layout=%d\n",bad);return bad;}
