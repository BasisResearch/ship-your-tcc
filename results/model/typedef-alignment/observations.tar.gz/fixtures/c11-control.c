#include <stddef.h>
#include <stdio.h>
typedef int Number; typedef const Number Const; struct S {char c; _Alignas(16) Number x;};
int main(void){int bad=(_Alignof(Number)!=4 || _Alignof(Const)!=4 || sizeof(Number)!=4 || offsetof(struct S,x)!=16 || sizeof(struct S)!=32); printf("c11-control=%d\n",bad);return bad;}
