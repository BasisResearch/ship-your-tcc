#include <stddef.h>
#include <stdio.h>
typedef int Up __attribute__((aligned(16)));
typedef int Down __attribute__((aligned(1)));
typedef Up Again;
typedef Again Third; typedef Third Fourth;
int main(void){int bad=(_Alignof(Fourth)!=16 || sizeof(Fourth)!=4); printf("chain=%d\n",bad);return bad;}
