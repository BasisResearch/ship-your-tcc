#include <stddef.h>
#include <stdio.h>
typedef int Up __attribute__((aligned(16)));
typedef int Down __attribute__((aligned(1)));
typedef Up Again;
struct P {char c; Up *p;}; struct Q {char c; Down *p;};
int main(void){int bad=(offsetof(struct P,p)!=sizeof(void*) || offsetof(struct Q,p)!=sizeof(void*) || sizeof(struct P)!=2*sizeof(void*)); printf("pointer-layout=%d\n",bad);return bad;}
