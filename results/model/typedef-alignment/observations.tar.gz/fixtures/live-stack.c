#include <stddef.h>
#include <stdio.h>
typedef int Up __attribute__((aligned(16)));
typedef int Down __attribute__((aligned(1)));
typedef Up Again;
Up global;
int main(void){int bad=__alignof__(global)!=16;
 bad|=_Alignof(int)!=4 || _Alignof(Down)!=1 || _Alignof(Again)!=16;
 bad|=_Alignof(int*)!=sizeof(void*) || sizeof(Up)!=4;
 printf("live-stack=%d\n",bad);return bad;}
