int f(void){typedef int Local; return sizeof(Local);} int n = _Alignof(Local);
int main(void){return 0;}
