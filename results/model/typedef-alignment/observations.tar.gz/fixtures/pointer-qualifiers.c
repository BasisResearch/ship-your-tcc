#include <stddef.h>
#include <stdio.h>
typedef int Up __attribute__((aligned(16)));
typedef int Down __attribute__((aligned(1)));
typedef Up Again;
typedef Up *const CP; typedef Down *volatile VP; typedef Up *restrict RP;
int main(void){int bad=(_Alignof(CP)!=sizeof(void*) || _Alignof(VP)!=sizeof(void*) || _Alignof(RP)!=sizeof(void*)); printf("pointer-qualifiers=%d\n",bad);return bad;}
