typedef int Up __attribute__((aligned(16)));
typedef int Down __attribute__((aligned(1)));
typedef Up Again;
typedef Up F(void); typedef F Bad[2];
int main(void){return 0;}
