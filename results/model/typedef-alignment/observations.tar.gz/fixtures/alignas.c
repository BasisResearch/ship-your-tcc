#include <stddef.h>
#include <stdio.h>
typedef int Up __attribute__((aligned(16)));
typedef int Down __attribute__((aligned(1)));
typedef Up Again;
struct A {char c; _Alignas(Up) int x;}; struct B {char c; _Alignas(Up*) int *p;};
int main(void){int bad=(offsetof(struct A,x)!=16 || _Alignof(struct A)!=16 || offsetof(struct B,p)!=sizeof(void*)); printf("alignas=%d\n",bad);return bad;}
