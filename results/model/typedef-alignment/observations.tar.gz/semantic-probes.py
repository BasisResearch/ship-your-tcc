from pathlib import Path
import json,subprocess,os,hashlib,shutil
root=Path.cwd();out=root/'build/typedef-final4';srcs=out/'semantic-inputs';srcs.mkdir(exist_ok=True)
w=Path('/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin');raw=w/'.lake/build/bin/csem_raw';saved=out/'gnu-csem-raw';shutil.copyfile(raw,saved);saved.chmod(0o755)
manifest=json.loads((root/'build/typedef-fixtures-final4/manifest.json').read_text());rows=[]
for f,expected in manifest['positives'].items():
 src=Path(f).read_text();name=Path(f).stem
 # New explicit header-free inputs: all GNU attributes and all test expressions
 # are retained. Offset/header and block-scoped-main inputs remain in the full
 # compiler suite; no refusal is counted as a success here.
 if 'offsetof' in src or name in ('scopes','live-stack'):continue
 decl,body=src.split('int main(void){',1)
 decl='\n'.join(x for x in decl.splitlines() if not x.startswith('#include'))+'\n'
 cond=body.split('int bad=(',1)[1].split('); printf(',1)[0]
 p=srcs/(name+'.c');p.write_text(decl+'int main(void){return ('+cond+');}\n')
 cmd=[str(saved),'--gnu','--checked','--semantic','--layout',str(out/(name+'-semantic.pp')),str(p)]
 r=subprocess.run(cmd,capture_output=True,env=dict(os.environ,LEAN_ABORT_ON_PANIC='1'),timeout=120)
 (out/(name+'-semantic.stdout')).write_bytes(r.stdout);(out/(name+'-semantic.stderr')).write_bytes(r.stderr)
 verdict=None
 if r.returncode==0:
  v=json.loads(r.stdout);verdict=v.get('semantics')
 comp=[]
 for n,c in [('gcc',['gcc','-std=c11']),('tcc',[str(root/'build/typedef-native/tcc'),'-B'+str(root/'build/typedef-native'),'-I'+str(root/'build/typedef-native-src/include')])]:
  cmd2=c+[str(p),'-o',str(out/'sem.exe')];q=subprocess.run(cmd2,capture_output=True);run=subprocess.run([str(out/'sem.exe')],capture_output=True) if q.returncode==0 else q
  comp.append(dict(name=n,command=cmd2,compile_exit=q.returncode,exit=run.returncode,stdout=run.stdout.decode(),stderr=q.stderr.decode()))
  assert q.returncode==0 and run.returncode==0,comp[-1]
 rows.append(dict(case=name,source=str(p.relative_to(root)),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),command=cmd,raw_exit=r.returncode,semantics=verdict,compiler=comp))
print('header-free same-input probes',len(rows),'defined zero',sum(x['semantics']==[dict(exit=0,status='defined',stdout='')] for x in rows))
for x in rows:
 if x['semantics']!=[dict(exit=0,status='defined',stdout='')]:print(x['case'],x['raw_exit'],x['semantics'])
(out/'semantic-probes.json').write_text(json.dumps(dict(binary_sha256=hashlib.sha256(saved.read_bytes()).hexdigest(),rows=rows),indent=2)+'\n')
