#include "tcc.h"
_Static_assert(sizeof(CType) == 24, "CType size");
_Static_assert(offsetof(CType, t) == 0, "CType tag offset");
_Static_assert(offsetof(CType, ref) == 8, "CType reference offset");
_Static_assert(offsetof(CType, aligned) == 16, "CType alignment offset");
_Static_assert(sizeof(SValue) == 64, "SValue size");
_Static_assert(offsetof(SValue, query_aligned) == 28, "SValue expression offset");
const unsigned long alignment_layout[] = {sizeof(CType), offsetof(CType, t), offsetof(CType,ref), offsetof(CType,aligned),sizeof(SValue),offsetof(SValue,query_aligned)};
