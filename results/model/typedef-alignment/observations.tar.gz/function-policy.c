#include <stdio.h>
typedef int Up __attribute__((aligned(16)));
typedef Up F(void);
int main(void){printf("%zu %zu %zu\n",_Alignof(F),_Alignof(__typeof__(F)),_Alignof(int(void)));return 0;}
