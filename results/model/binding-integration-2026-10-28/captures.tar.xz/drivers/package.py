from pathlib import Path
import hashlib,json,tarfile,gzip,shutil,sys,re
root=Path(__file__).resolve().parents[1];w=root/'.claude/worktrees/sol-c11-line';out=w/'results/model/binding-integration-2026-10-28';out.mkdir(exist_ok=True)
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(w/'scripts'))
import model_diff as m
from source_fixtures import fixture_entries,load_invocation
files={}
def tree(p,prefix):
 for f in p.rglob('*'):
  if f.is_file():files[prefix+'/'+str(f.relative_to(p))]=f
base=w/'build/binding-integrated';tree(base,'combined')
log=w/'build/worker-build-binding-integrated-1.log';files['gate/full.log']=log
for p in re.findall(r'^injected binding artifacts: (.+)$',log.read_text(),re.M):tree(w/p,'gate/bindings')
files['drivers/package.py']=Path(__file__)
for p in ['scripts/model_diff.py','scripts/ghost_cabs_cmp.py','scripts/ghost_origins_cmp.py','scripts/injected_origins_cmp.py','scripts/physical_onoff_cmp.py']:files['drivers/'+Path(p).name]=w/p
tree(root/'build/main-artifact-refresh-2026-10-28-physical','prior-main-refresh')
q=json.loads((w/'build/worker-build.binding-integrated-1.request').read_text());r=json.loads((w/'build/worker-build.binding-integrated-1.result').read_text());assert r['exit']==0 and r['source_hashes_verified'] and q['request_id']==r['request_id'];assert all(H(w/p)==h for p,h in q['sha256'].items())
for n,d in [('gate.request',q),('gate.result',r)]: (out/(n+'.json.gz')).write_bytes(gzip.compress(json.dumps(d,indent=2).encode(),mtime=0))
for n,p in [('authority','authority/comparison.json'),('physical','physical/comparison.json'),('shared','shared/comparison.json'),('raw-component','raw-component/comparison.json'),('independent','independent/comparison.json'),('erasure','onoff/erasure.json'),('arenas','arenas.json'),('native','native.json'),('invocation','invocation.json')]:shutil.copyfile(base/p,out/(n+'.json'))
index=[]
for kind,total in [('arenas',18),('native',1),('invocation',1)]:
 d=json.loads((base/(kind+'.json')).read_text());assert d['totals']=={'n':total,'same':total}
 for rows in d['results'].values():
  for row in rows:
   name=row['name'];p=(w/name).resolve();args=['-w'];extra=[(v,str(h)) for v,h in fixture_entries(p)]
   if kind=='invocation':
    a=load_invocation(p,w);p=Path(a['source']);args=a['args'];extra=a['extra']
   key=m.sha('independent-c11-handoff-v4',p.read_bytes(),repr(extra),repr(args),repr([]),d['runtime_key'],(w/'c/src/gen_embed.sh').read_bytes(),*[Path(h).read_bytes() for _,h in extra])
   if d.get('sail_settings'):key=m.sha(key,'native-sail-full-arena-v1',json.dumps(d['sail_settings'],sort_keys=True))
   ref=w/f'build/model_diff/cache/{key}.arena';model=w/f'build/model_diff/work/{m.sha(name,"c")}.arena';assert H(ref)==H(model)
   prefix=f'arenas/{kind}/{p.stem}'
   for n,path in [('reference.arena',ref),('model.arena',model),('source.c',p)]:files[prefix+'/'+n]=path
   for virtual,host in extra:files[prefix+'/inputs/'+virtual.lstrip('/')]=Path(host)
   if d.get('sail_settings'):
    tree(w/f'build/model_diff/cache/{key}.sail',prefix+'/capture')
    files[prefix+'/capture-result.json']=w/f'build/model_diff/cache/{key}.sail.json'
    files[prefix+'/capture.log']=w/f'build/model_diff/cache/{key}.sail.log'
    assert row['sail']['status']=='equal' and row['sail']['compared_bytes']==4194304
   index.append(dict(kind=kind,name=name,archive_prefix=prefix,cache_key=key,arena_sha256=H(model)))
(out/'arena-index.json').write_text(json.dumps(index,indent=2)+'\n')
manifest={n:H(p) for n,p in files.items()}
with tarfile.open(out/'captures.tar.xz','w:xz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(out/'captures.tar.xz') as t:assert {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t.getmembers() if m.isfile()}==manifest
(out/'pins.json').write_text(json.dumps(dict(archive_members=manifest,artifacts={p.name:H(p) for p in out.iterdir() if p.is_file() and p.name not in ['pins.json','verify.py']}),indent=2)+'\n')
print(len(manifest),'verified captures,',len(q['sha256']),'gate inputs')
