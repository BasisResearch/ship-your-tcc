#define V(x,...) x , ##__VA_ARGS__
int a[]={V(1),V(2,3)};

