#include "outer.h"
int n=OUT;

