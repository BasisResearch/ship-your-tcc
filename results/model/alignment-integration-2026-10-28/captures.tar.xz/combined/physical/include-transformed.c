??=include "outer.h"
%\
:include "outer.h"
int n=VALUE;

