#define NA\
ME(x) x+\
1
int n=NAME(2);

