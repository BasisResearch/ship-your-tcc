#line 90 "label.c"
int lo\
ngname=1; int n=__LINE__;

