#include "line.h"
int n=VALUE;

