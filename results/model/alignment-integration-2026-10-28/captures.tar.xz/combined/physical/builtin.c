#line 200 "virtual.c"
int n=__LINE__+__COUNTER__; char *s=__FILE__;

