#define D(x) ((x)+(x))
#define N 2
int x=D(N);

