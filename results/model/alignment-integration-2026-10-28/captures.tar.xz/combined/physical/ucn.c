#define ID(x) x
int \u00e9; int f(void){return ID(é);}
