#include "decl.h"
#include "decl.h"
int n=1;

