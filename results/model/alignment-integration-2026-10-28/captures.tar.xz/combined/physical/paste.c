#define C(a,b) a##b
int C(na,me)=2;

