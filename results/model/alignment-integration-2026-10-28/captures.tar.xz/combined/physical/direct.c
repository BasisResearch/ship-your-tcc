int x=1+2; int f(void){return x;}
