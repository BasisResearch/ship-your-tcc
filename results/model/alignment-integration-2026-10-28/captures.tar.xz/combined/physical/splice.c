int lo\
ngname=1;

