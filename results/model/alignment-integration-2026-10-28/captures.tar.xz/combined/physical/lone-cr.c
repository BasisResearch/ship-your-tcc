int x;int y;

