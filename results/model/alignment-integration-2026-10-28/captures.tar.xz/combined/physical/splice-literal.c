char *s="ab\
cd"; int c='a\
b';

