#define S(x) #x
char *s=S(word + token);

