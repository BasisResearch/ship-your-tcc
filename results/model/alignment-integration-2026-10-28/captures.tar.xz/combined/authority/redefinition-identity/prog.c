#include "library.h"
extern int SAME;
#define SAME same
extern int SAME;
int main(void){return 0;}
