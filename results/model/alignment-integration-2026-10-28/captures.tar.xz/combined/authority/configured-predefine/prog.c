int n=__SIZEOF_LONG__;
int main(void){return 0;}
