#include "empty.h"
#include "empty.h"
int main(void){return 0;}
