extern int mine(void) __asm__("strlen");
int main(void){return 0;}
