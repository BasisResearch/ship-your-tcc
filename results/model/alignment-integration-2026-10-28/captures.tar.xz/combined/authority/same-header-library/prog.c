#define __uint128__ user_uint128
#include <tccdefs.h>
int main(void){return 0;}
