#include "outer.h"
extern int HEADER_NAME;
#define USER_NAME user_macro
extern int USER_NAME;
#undef HEADER_NAME
#define HEADER_NAME redefined_macro
extern int HEADER_NAME;
extern int user_direct;
int main(void){return 0;}
