void *__builtin_memcpy(void *, const void *, unsigned long);
int main(void){return 0;}
