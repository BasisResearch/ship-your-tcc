#line 41 "<command line>"
extern int __builtin_forged(void) __asm__("memcpy");
int main(void){return 0;}
