extern int __builtin_user(void) __asm__("strlen");
int main(void){return 0;}
