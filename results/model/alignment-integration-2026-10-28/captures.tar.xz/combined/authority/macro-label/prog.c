#define ASM(x) __asm__(x)
extern int mine(void) ASM("strlen");
int main(void){return 0;}
