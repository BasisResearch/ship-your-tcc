int f(int x){int *p=&x; return -x + ~*p + !x + +x;}
