int a[3]; int f(int i){return a[i];}
