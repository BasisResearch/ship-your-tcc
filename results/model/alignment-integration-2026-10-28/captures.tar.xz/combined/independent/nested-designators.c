struct S {int a[2];}; struct S s={.a={[1]=3}};
