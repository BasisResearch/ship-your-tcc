int x __attribute__((aligned(16)));
