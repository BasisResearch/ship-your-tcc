int f(int x){if(x)goto out; x=1; out: return x;}
