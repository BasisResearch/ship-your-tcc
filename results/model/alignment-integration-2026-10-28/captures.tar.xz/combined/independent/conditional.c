int f(int x){return x ? 2+3 : 4*5;}
