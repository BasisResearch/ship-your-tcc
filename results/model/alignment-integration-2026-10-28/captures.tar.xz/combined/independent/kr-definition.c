int f(x) int x; {return x;}
