typedef int T; T f(T x){T y=x; {int T=2; y+=T;} return y;}
