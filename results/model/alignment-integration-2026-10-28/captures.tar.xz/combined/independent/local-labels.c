int f(void){__label__ out; goto out; out: return 1;}
