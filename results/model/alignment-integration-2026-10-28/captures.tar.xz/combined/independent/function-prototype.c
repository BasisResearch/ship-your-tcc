int f(int x, const char *s, ...);
