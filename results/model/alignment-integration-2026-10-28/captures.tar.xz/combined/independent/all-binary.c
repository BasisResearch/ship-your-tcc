int f(int a,int b){return ((a*b+a/b-a%b)<<2) >= (b>>1) && a!=b || (a&b)^(a|b);}
