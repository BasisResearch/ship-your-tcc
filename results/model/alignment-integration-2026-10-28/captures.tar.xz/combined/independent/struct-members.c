struct S {const int x; volatile long y;};
