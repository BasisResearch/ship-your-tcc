#pragma pack(1)
struct S {char a; int b;};

