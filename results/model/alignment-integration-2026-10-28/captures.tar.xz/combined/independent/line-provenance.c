#line 200 "virtual.c"
int x=3;

