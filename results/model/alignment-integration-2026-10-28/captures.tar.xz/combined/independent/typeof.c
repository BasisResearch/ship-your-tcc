int x; typeof(x) y;
