const volatile unsigned long *restrict p;
