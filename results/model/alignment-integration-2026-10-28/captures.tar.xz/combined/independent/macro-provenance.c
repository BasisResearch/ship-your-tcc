#define ADD(x) ((x)+1)
int f(int x){return ADD(x);}

