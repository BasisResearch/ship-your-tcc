_Static_assert(sizeof(int)==4,"int"); int x;
