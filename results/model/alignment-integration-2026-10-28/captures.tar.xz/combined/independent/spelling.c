unsigned long x=0XffUL; int y=010+0x10;
