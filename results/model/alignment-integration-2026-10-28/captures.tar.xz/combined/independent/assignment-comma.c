int f(int x){int y=1; return (x+=2,y*=3,x+y);}
