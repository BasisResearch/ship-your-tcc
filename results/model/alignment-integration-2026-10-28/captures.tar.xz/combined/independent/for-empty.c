int f(int x){for(;;){break;} return x;}
