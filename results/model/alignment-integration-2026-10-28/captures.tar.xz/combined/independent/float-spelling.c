double x=0x1.8p+2; float y=1.2500f;
