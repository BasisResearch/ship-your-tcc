int f(int x){while(x){if(x==3)break; x--; continue;} return x;}
