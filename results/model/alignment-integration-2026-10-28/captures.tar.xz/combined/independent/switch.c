int f(int x){switch(x){case 1:return 2; default:return 3;}}
