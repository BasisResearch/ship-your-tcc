extern unsigned long x; static const int y=3; int z;
