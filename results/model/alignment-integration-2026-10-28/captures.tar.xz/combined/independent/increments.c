int f(int x){x++; --x; return ++x+x--;}
