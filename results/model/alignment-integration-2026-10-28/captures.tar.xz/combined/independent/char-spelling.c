int x='\x41'; int y='\101';
