int f(void){int x=0; for(int i=0;i<3;i++)x+=i; return x;}
