int \u00e9; int f(void){return é;}
