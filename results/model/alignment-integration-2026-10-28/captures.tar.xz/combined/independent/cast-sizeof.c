int f(int x){return (unsigned int)x+sizeof(x)+sizeof(long);}
