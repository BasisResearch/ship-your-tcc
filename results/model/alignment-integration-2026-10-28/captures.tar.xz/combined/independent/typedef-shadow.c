typedef int T; int f(void){int T=3; return T;}
