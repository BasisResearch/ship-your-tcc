int g(int,int); int f(int x){return g(x+1,2*x);}
