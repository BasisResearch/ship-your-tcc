int f(int, const char *, int (*)(int));
