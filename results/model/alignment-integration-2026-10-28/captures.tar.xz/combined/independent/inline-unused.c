static inline int f(void){return 1;} int x;
