int (*p)[3]; int *a[2];
