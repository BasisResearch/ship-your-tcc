# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
typedef
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
        int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
            Up
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
               __attribute__
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                            (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                             (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                              aligned
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                     (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                      16
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                        )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                         )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                          )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                           ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
typedef
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
        int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
            Down
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                 __attribute__
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                              (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                               (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                aligned
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                       (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                        1
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                         )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                          )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                           )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                            ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
typedef
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
        Up
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
           Again
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
typedef
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
        Up
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
           *
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
            const
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                  CP
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                    ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                      typedef
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                              Down
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                   *
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                    volatile
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                             VP
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                               ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                 typedef
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                         Up
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                            *
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                             restrict
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                                      RP
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                                        ;
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
int
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
    main
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
        (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
         void
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
             )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
              {
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
               return
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                      (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                       _Alignof
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                               (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                CP
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                  )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                   !=
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                     sizeof
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                           (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                            void
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                *
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                 )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                   ||
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                      _Alignof
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                              (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                               VP
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                                 )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                                  !=
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                                    sizeof
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                                          (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                                           void
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                                               *
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                                                )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                                                  ||
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                                                     _Alignof
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                                                             (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                                                              RP
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                                                                )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                                                                 !=
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                                                                   sizeof
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                                                                         (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                                                                          void
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                                                                              *
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                                                                               )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                                                                                )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                                                                                 ;
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/pointer-qualifiers/input.c"
                                                                                                                  }
