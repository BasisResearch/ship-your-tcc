# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
typedef
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
        int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
            Up
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
               __attribute__
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                            (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                             (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                              aligned
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                                     (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                                      16
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                                        )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                                         )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                                          )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                                           ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                                             Up
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                                                x
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                                                 ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                                                   Up
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                                                      f
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                                                       (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                                                        void
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                                                            )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                                                             {
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                                                              return
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                                                                     0
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                                                                      ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                                                                       }
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
    main
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
        (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
         void
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
             )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
              {
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
               return
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                      _Alignof
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                              (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                               __typeof__
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                                         (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                                          !
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                                           x
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                                            )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                                             )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                                              !=
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                                                4
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                                                 ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/transport-logical-not/input.c"
                                                  }

