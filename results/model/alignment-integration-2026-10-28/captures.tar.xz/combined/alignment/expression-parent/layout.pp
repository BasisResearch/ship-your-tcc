# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
struct
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
       S
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
         {
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
          char
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
               c
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                  int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                      i
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                       ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                        }
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                         ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                           struct
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                  S
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                    obj
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                        __attribute__
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                     (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                      (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                       aligned
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                              (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                               32
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                 )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                  )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                   )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                    ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
    main
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
        (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
         void
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
             )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
              {
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
               return
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                      (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                       __alignof__
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                  (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                   obj
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                      )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                       !=
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                         32
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                            ||
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                               __alignof__
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                          (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                           obj
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                              .
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                               c
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                 !=
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                   1
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                     ||
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                        __alignof__
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                                   (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                                    obj
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                                       .
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                                        i
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                                         )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                                          !=
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                                            4
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                                              ||
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                                                 __alignof__
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                                                            (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                                                             &
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                                                              obj
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                                                                 .
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                                                                  c
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                                                                   )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                                                                    !=
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                                                                      sizeof
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                                                                            (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                                                                             void
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                                                                                 *
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                                                                                  )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                                                                                   )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                                                                                    ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/alignment-integrated/alignment/expression-parent/input.c"
                                                                                                                                     }

