int main(void){int a=3;int x=({int y=a+2;y*2;});int z=a?:5;
switch(z){case 1 ... 4:x-=10;break;default:x=7;}return x;}
