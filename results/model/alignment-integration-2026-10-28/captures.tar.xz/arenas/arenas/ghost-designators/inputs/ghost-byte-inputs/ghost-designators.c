struct S {int a[2];int b;};
static struct S s[2]={[1].a[1]=5,[0]={.a={1,2},.b=3}};
int main(void){int a[]={1,2,3};return s[1].a[1]+s[0].b+a[2]-11;}
