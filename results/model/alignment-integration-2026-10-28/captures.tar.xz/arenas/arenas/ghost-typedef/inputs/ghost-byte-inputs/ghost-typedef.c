typedef int T;
static T f(T x){T y=x;{int T=2;y+=T;}return y;}
int main(void){return f(3)-5;}
