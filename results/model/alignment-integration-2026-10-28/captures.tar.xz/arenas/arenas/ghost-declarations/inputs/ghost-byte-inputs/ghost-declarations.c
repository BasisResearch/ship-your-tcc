typedef unsigned long Word;
static const int values[2][2]={{1,2},{3,4}};
static int add(int a,int b){return a+b;}
int main(void){int (*fp)(int,int)=add; Word x=values[1][0]; return fp((int)x,2)-5;}
