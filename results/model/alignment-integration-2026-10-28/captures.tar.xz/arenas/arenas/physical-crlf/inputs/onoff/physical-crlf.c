int lo\
ngname=2; int main(void){return longname-2;}
