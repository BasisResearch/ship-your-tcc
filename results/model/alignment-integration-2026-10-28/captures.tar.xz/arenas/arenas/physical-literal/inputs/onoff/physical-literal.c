char *s="ab\
cd"; int main(void){return s[2]-99;}
