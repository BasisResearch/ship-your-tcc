#define NA\
ME(x) x+\
1
int lo\
ngname=2; int main(void){return NAME(longname)-3;}
