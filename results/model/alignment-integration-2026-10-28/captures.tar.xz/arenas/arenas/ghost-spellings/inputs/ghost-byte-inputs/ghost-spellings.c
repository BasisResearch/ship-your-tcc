static const char *s="\x41" "1" "\101";
int main(void){unsigned long n=0XffUL;double d=0x1.8p+2;float f=1.2500f;
return n-255+(int)d-6+(int)f-1+s[0]-'\101';}
