#define A 3
#pragma push_macro("A")
#undef A
#define A 4
#pragma pack(push,1)
struct P{char c;int n;};
#pragma pack(pop)
_Pragma("pop_macro(\"A\")")
int main(void){return sizeof(struct P)+A-8;}
