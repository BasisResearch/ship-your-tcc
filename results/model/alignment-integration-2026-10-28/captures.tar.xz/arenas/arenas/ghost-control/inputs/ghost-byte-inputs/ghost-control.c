int main(void){int n=0;for(int i=0;i<5;i++){if(i==2)continue;n+=i;}
 do{n--;}while(n>4);while(n){if(n==2)break;n--;}
 switch(n){case 1:n=5;break;case 2:n=3;break;default:n=8;}goto out;out:return n-3;}
