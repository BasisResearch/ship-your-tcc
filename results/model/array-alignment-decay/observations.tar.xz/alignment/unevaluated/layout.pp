# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/unevaluated/input.c"
int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/unevaluated/input.c"
    main
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/unevaluated/input.c"
        (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/unevaluated/input.c"
         void
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/unevaluated/input.c"
             )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/unevaluated/input.c"
              {
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/unevaluated/input.c"
               int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/unevaluated/input.c"
                   x
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/unevaluated/input.c"
                    =
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/unevaluated/input.c"
                     0
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/unevaluated/input.c"
                      ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/unevaluated/input.c"
                        return
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/unevaluated/input.c"
                               __alignof__
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/unevaluated/input.c"
                                          (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/unevaluated/input.c"
                                           x
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/unevaluated/input.c"
                                            ++
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/unevaluated/input.c"
                                              )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/unevaluated/input.c"
                                               !=
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/unevaluated/input.c"
                                                 4
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/unevaluated/input.c"
                                                   ||
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/unevaluated/input.c"
                                                      x
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/unevaluated/input.c"
                                                       !=
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/unevaluated/input.c"
                                                         0
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/unevaluated/input.c"
                                                          ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/unevaluated/input.c"
                                                           }

