# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
typedef
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
        int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
            Up
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
               __attribute__
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                            (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                             (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                              aligned
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                     (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                      16
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                        )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                         )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                          )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                           ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                             Up
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                                x
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                                 ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                                   Up
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                                      f
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                                       (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                                        void
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                                            )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                                             {
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                                              return
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                                                     0
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                                                      ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                                                       }
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
    main
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
        (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
         void
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
             )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
              {
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
               return
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                      _Alignof
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                              (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                               __typeof__
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                         (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                          f
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                           (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                            )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                             )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                              )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                               !=
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                                 16
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                                   ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/transport-return/input.c"
                                                    }
