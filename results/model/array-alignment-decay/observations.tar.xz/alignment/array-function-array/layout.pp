# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/array-function-array/input.c"
int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/array-function-array/input.c"
    f
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/array-function-array/input.c"
     [
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/array-function-array/input.c"
      1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/array-function-array/input.c"
       ]
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/array-function-array/input.c"
        (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/array-function-array/input.c"
         void
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/array-function-array/input.c"
             )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/array-function-array/input.c"
              ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/array-function-array/input.c"
                int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/array-function-array/input.c"
                    main
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/array-function-array/input.c"
                        (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/array-function-array/input.c"
                         void
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/array-function-array/input.c"
                             )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/array-function-array/input.c"
                              {
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/array-function-array/input.c"
                               return
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/array-function-array/input.c"
                                      0
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/array-function-array/input.c"
                                       ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/arraydecay-alignment-2/array-function-array/input.c"
                                        }

