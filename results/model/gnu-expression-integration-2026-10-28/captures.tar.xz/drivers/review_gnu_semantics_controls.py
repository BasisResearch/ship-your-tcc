from pathlib import Path
import json,hashlib,subprocess,time
r=Path.cwd();w=r/'.claude/worktrees/sol-c11-line';out=w/'build/gnu-expression-semantic-review';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();exe=w/'.lake/build/bin/csem_raw';host=w/'build/test-c11/host/tcc';binary=H(exe)
forms={'standard-vla':'int main(void){int n=2;int a[n];a[0]=3;return sizeof(a)!=8 || a[0]!=3;}','ordinary-conditional-control':'int main(void){int n=2,k=0,c=n++;int a=c?c:++k;int b=0?0:++k;return n!=3 || a!=2 || k!=1 || b!=1;}'}
for name,source in forms.items():
 d=out/name;d.mkdir();p=d/'input.c';p.write_text(source+'\n');cmd=[str(exe),'--tcc','--fslist',str(w/'c/build/fs.list'),'--semantic',str(p)];start=time.time();q=subprocess.run(cmd,cwd=w,capture_output=True,timeout=120);(d/'stdout').write_bytes(q.stdout);(d/'stderr').write_bytes(q.stderr);(d/'receipt.json').write_text(json.dumps(dict(case=name,command=cmd,exit=q.returncode,wall=time.time()-start,source_sha256=H(p),binary_sha256=binary),indent=2)+'\n')
rows=[]
for p in sorted(out.glob('*/input.c')):
 d=p.parent;native=[]
 for engine,cc in [('gcc',['gcc','-std=gnu11','-O0']),('host-tcc',[str(host),'-B'+str(host.parent),'-std=c11'])]:
  command=cc+[str(p),'-o',str(d/engine)];q=subprocess.run(command,cwd=w,capture_output=True,timeout=60);(d/(engine+'.compile.stderr')).write_bytes(q.stderr);assert q.returncode==0,(d.name,engine,q.stderr)
  x=subprocess.run([str(d/engine)],capture_output=True,timeout=30);assert x.returncode==0 and x.stdout==b'' and x.stderr==b''
  native.append(dict(engine=engine,command=command,compile_exit=q.returncode,exit=x.returncode,executable_sha256=H(d/engine)))
 raw=json.loads((d/'stdout').read_text());row=dict(case=d.name,source_sha256=H(p),semantics=raw['semantics'],engines=native);rows.append(row);print(d.name,json.dumps(raw['semantics']),flush=True)
assert H(exe)==binary;(out/'summary.json').write_text(json.dumps(dict(rows=rows,binaries=dict(csem_raw=binary,host_tcc=H(host)),scope='Bounded independent raw CSem and GCC/host execution; no new native Sail claim'),indent=2)+'\n')
