from pathlib import Path
import importlib.util,json,hashlib,subprocess,time
r=Path.cwd();w=r/'.claude/worktrees/sol-c11-line';out=w/'build/gnu-expression-semantic-review';out.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('extra',w/'results/model/gnu-expression-syntax/extra.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
forms=dict(module.FORMS)
forms['conditional-single-evaluation']='int main(void){int n=2,k=0;int a=n++ ?: ++k;int b=0 ?: ++k;return n!=3 || a!=2 || k!=1 || b!=1;}'
forms['choose-single-evaluation']='int main(void){int n=2,k=0;int a=__builtin_choose_expr(1,n++,++k);return n!=3 || a!=2 || k;}'
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();exe=w/'.lake/build/bin/csem_raw';binary=H(exe);rows=[]
for name,source in forms.items():
 d=out/name;d.mkdir(exist_ok=True);p=d/'input.c';p.write_text(source+'\n');cmd=[str(exe),'--tcc','--fslist',str(w/'c/build/fs.list'),'--semantic',str(p)];start=time.time()
 try:
  q=subprocess.run(cmd,cwd=w,capture_output=True,timeout=120);rc=q.returncode;stdout=q.stdout;stderr=q.stderr
 except subprocess.TimeoutExpired as e:rc='timeout';stdout=e.stdout or b'';stderr=e.stderr or b''
 (d/'stdout').write_bytes(stdout);(d/'stderr').write_bytes(stderr);row=dict(case=name,command=cmd,exit=rc,wall=time.time()-start,source_sha256=H(p),binary_sha256=binary);(d/'receipt.json').write_text(json.dumps(row,indent=2)+'\n');rows.append(row);print(name,rc,round(row['wall'],2),flush=True)
assert H(exe)==binary;(out/'report.json').write_text(json.dumps(dict(rows=rows),indent=2)+'\n')
