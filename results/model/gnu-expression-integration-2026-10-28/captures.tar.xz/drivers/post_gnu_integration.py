from pathlib import Path
import json,hashlib,subprocess,time
r=Path.cwd();w=r/'.claude/worktrees/sol-c11-line';out=w/'build/gnu-expr-integrated';q=json.loads((w/'build/worker-build.gnu-expr-integrated-1.request').read_text());H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for _ in range(720):
 p=w/'build/worker-build.result'
 if p.exists():
  v=json.loads(p.read_text())
  if v.get('request_id')==q['request_id']:
   assert v['exit']==0 and v['source_hashes_verified'],v
   (w/'build/worker-build.gnu-expr-integrated-1.result').write_text(json.dumps(v,indent=2)+'\n');break
 time.sleep(10)
else:raise TimeoutError('GNU combined gate receipt not ready')
assert all(H(w/p)==h for p,h in q['sha256'].items());pins={n:H(w/'.lake/build/bin'/n) for n in ['csem_raw','csem_run','tcc_ghost','tcc_model']};commands=[]
for name,opts in [('shared',[]),('component',['--raw']),('independent',['--independent-raw'])]:
 commands.append((name,['python3','scripts/ghost_cabs_cmp.py','--build-id',q['request_id'],'--out',str(out/name),*opts]))
commands.extend([('physical',['python3','scripts/ghost_origins_cmp.py','--build-id',q['request_id'],'--out',str(out/'physical')]),('onoff',['python3','scripts/physical_onoff_cmp.py','--build-id',q['request_id'],'--out',str(out/'onoff')]),('vla',['python3','results/model/gnu-expression-syntax/extra.py','--out',str(out/'vla')])])
for name,command in commands:
 with (out/(name+'.log')).open('w') as f:p=subprocess.run(command,cwd=w,stdout=f,stderr=subprocess.STDOUT,timeout=7200)
 (out/(name+'.command.json')).write_text(json.dumps(dict(command=command,exit=p.returncode),indent=2)+'\n');assert p.returncode==0,(name,p.returncode)
 print('PASS',name,flush=True)
assert all(H(w/p)==h for p,h in q['sha256'].items());assert all(H(w/'.lake/build/bin'/n)==h for n,h in pins.items());(out/'postcheck-pins.json').write_text(json.dumps(dict(primary=len(q['sha256']),binaries=pins,driver_sha256=H(Path(__file__))),indent=2)+'\n');print('GNU postchecks complete',flush=True)
