from pathlib import Path
import json,hashlib,tarfile,re,sys
r=Path.cwd();w=r/'.claude/worktrees/sol-c11-line';out=w/'results/model/gnu-expression-integration-2026-10-28';out.mkdir(exist_ok=True);H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();files={}
def addtree(p,prefix):
 for f in p.rglob('*'):
  if f.is_file() and '__pycache__' not in f.parts:files[prefix+'/'+str(f.relative_to(p))]=f
q=json.loads((w/'build/worker-build.gnu-expr-integrated-1.request').read_text());v=json.loads((w/'build/worker-build.gnu-expr-integrated-1.result').read_text());assert v['exit']==0 and v['source_hashes_verified'];assert all(H(w/p)==h for p,h in q['sha256'].items());post=json.loads((w/'build/gnu-expr-integrated/postcheck-pins.json').read_text());assert all(H(w/'.lake/build/bin'/n)==h for n,h in post['binaries'].items())
supp=json.loads((w/'build/gnu-expr-integrated/supplementary-pins.json').read_text());assert all(H(w/p)==h for p,h in supp['sha256'].items())
for ext in ['request','result']:files['gate/'+ext+'.json']=w/'build'/('worker-build.gnu-expr-integrated-1.'+ext)
files['gate/log.txt']=w/'build/worker-build-gnu-expr-integrated-1.log';log=files['gate/log.txt'].read_text();assert log.rstrip().endswith('check: OK')
addtree(w/'build/gnu-expr-integrated','post')
addtree(w/'build/gnu-expression-semantic-review','semantic-probes')
for n in ['post_gnu_integration.py','package_gnu_integration.py','review_gnu_semantics.py','review_gnu_semantics_controls.py']:files['drivers/'+n]=r/'build'/n
roots=re.findall(r'^(?:unevaluated syntax artifacts|assertion message artifacts|GNU expression artifacts|array decay artifacts): (.+)$',log,re.M);assert len(roots)==4,roots
sys.path.insert(0,str(w/'scripts'));from freeze_sail_arenas import freeze
exports=w/'build/gnu-expr-integrated-native-exports';exports.mkdir(exist_ok=False);native=[]
for path in roots:
 addtree(w/path,'gates/'+Path(path).name)
 for report in (w/path).rglob('arenas.json'):
  d=json.loads(report.read_text())
  if not d.get('sail_settings'):continue
  prefix=str(len(native));info=freeze(report,exports/prefix);assert info['successes']==1;native.append(dict(prefix=prefix,report='gates/'+str(report.relative_to(w/Path(path).parent)),inventory=info))
assert len(native)==6
addtree(exports,'native');(out/'native-index.json').write_text(json.dumps(native,indent=2)+'\n')
focused=[]
for p in w.glob('build/bitfields-gate.*/report.json'):
 d=json.loads(p.read_text())
 if d['source_revision']==q['source_revision']:focused.append(p)
assert len(focused)==1;assert json.loads(focused[0].read_text())['binary_sha256']==post['binaries']['csem_raw'];addtree(focused[0].parent,'bitfields')
# New sources are recoverable by digest; all primary pins remain mandatory.
for p,h in {**q['sha256'],**supp['sha256']}.items():files['sources/'+h]=w/p
manifest={n:H(p) for n,p in files.items()}
with tarfile.open(out/'captures.tar.xz','w:xz',preset=6) as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(out/'captures.tar.xz','r|xz') as t:assert {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t if m.isfile()}==manifest
pins=dict(archive_sha256=H(out/'captures.tar.xz'),native_index_sha256=H(out/'native-index.json'),primary_inputs=len(q['sha256']),supplementary_inputs=len(supp['sha256']),members=manifest,worker_manifest_sha256=H(w/'results/model/gnu-expression-syntax/artifact-manifest.json'))
(out/'pins.json').write_text(json.dumps(pins,indent=2)+'\n');print('Packaged',len(manifest),'members;',len(native),'complete native exports;',len(q['sha256']),'primary inputs',flush=True)
