# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-nested-incomplete-array/input.c"
typedef
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-nested-incomplete-array/input.c"
        int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-nested-incomplete-array/input.c"
            A
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-nested-incomplete-array/input.c"
             [
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-nested-incomplete-array/input.c"
              ]
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-nested-incomplete-array/input.c"
               [
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-nested-incomplete-array/input.c"
                2
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-nested-incomplete-array/input.c"
                 ]
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-nested-incomplete-array/input.c"
                  ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-nested-incomplete-array/input.c"
                    typedef
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-nested-incomplete-array/input.c"
                            A
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-nested-incomplete-array/input.c"
                              B
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-nested-incomplete-array/input.c"
                               [
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-nested-incomplete-array/input.c"
                                2
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-nested-incomplete-array/input.c"
                                 ]
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-nested-incomplete-array/input.c"
                                  ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-nested-incomplete-array/input.c"
                                    int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-nested-incomplete-array/input.c"
                                        main
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-nested-incomplete-array/input.c"
                                            (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-nested-incomplete-array/input.c"
                                             void
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-nested-incomplete-array/input.c"
                                                 )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-nested-incomplete-array/input.c"
                                                  {
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-nested-incomplete-array/input.c"
                                                   return
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-nested-incomplete-array/input.c"
                                                          0
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-nested-incomplete-array/input.c"
                                                           ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-nested-incomplete-array/input.c"
                                                            }
