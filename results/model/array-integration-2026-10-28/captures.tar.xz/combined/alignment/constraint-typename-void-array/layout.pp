# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-typename-void-array/input.c"
typedef
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-typename-void-array/input.c"
        void
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-typename-void-array/input.c"
             V
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-typename-void-array/input.c"
              ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-typename-void-array/input.c"
                int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-typename-void-array/input.c"
                    x
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-typename-void-array/input.c"
                     [
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-typename-void-array/input.c"
                      sizeof
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-typename-void-array/input.c"
                            (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-typename-void-array/input.c"
                             V
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-typename-void-array/input.c"
                              [
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-typename-void-array/input.c"
                               1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-typename-void-array/input.c"
                                ]
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-typename-void-array/input.c"
                                 )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-typename-void-array/input.c"
                                  ]
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-typename-void-array/input.c"
                                   ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-typename-void-array/input.c"
                                     int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-typename-void-array/input.c"
                                         main
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-typename-void-array/input.c"
                                             (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-typename-void-array/input.c"
                                              void
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-typename-void-array/input.c"
                                                  )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-typename-void-array/input.c"
                                                   {
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-typename-void-array/input.c"
                                                    return
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-typename-void-array/input.c"
                                                           0
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-typename-void-array/input.c"
                                                            ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/constraint-typename-void-array/input.c"
                                                             }

