# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/array-void-array-typedef/input.c"
typedef
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/array-void-array-typedef/input.c"
        void
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/array-void-array-typedef/input.c"
             V
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/array-void-array-typedef/input.c"
              ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/array-void-array-typedef/input.c"
                typedef
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/array-void-array-typedef/input.c"
                        V
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/array-void-array-typedef/input.c"
                          Bad
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/array-void-array-typedef/input.c"
                             [
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/array-void-array-typedef/input.c"
                              1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/array-void-array-typedef/input.c"
                               ]
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/array-void-array-typedef/input.c"
                                ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/array-void-array-typedef/input.c"
                                  int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/array-void-array-typedef/input.c"
                                      main
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/array-void-array-typedef/input.c"
                                          (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/array-void-array-typedef/input.c"
                                           void
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/array-void-array-typedef/input.c"
                                               )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/array-void-array-typedef/input.c"
                                                {
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/array-void-array-typedef/input.c"
                                                 return
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/array-void-array-typedef/input.c"
                                                        0
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/array-void-array-typedef/input.c"
                                                         ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/array-void-array-typedef/input.c"
                                                          }

