# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
    obj
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
        __attribute__
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                     (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                      (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                       aligned
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                              (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                               32
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                 )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                  )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                   )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                    ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
    main
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
        (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
         void
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
             )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
              {
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
               return
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                      (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                       __alignof__
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                  (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                   obj
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                      )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                       !=
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                         32
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                            ||
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                               __alignof__
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                          (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                           &
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                            obj
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                               )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                !=
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                  sizeof
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                        (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                         void
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                             *
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                              )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                ||
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                   __alignof__
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                              (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                               +
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                                obj
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                                   )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                                    !=
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                                      4
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                                        ||
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                                           __alignof__
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                                                      (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                                                       (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                                                        obj
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                                                           ,
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                                                            obj
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                                                               )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                                                                )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                                                                 !=
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                                                                   4
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                                                                     ||
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                                                                        _Alignof
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                                                                                (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                                                                                 __typeof__
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                                                                                           (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                                                                                            obj
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                                                                                               )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                                                                                                )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                                                                                                 !=
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                                                                                                   4
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                                                                                                    )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                                                                                                     ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/array-integrated/alignment/expression-global/input.c"
                                                                                                                                                                      }
