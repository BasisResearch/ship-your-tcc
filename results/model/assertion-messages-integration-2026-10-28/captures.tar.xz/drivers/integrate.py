from pathlib import Path
import json,hashlib,subprocess,fcntl,os
root=Path(__file__).resolve().parents[1];w=root/'.claude/worktrees/sol-c11-line';sw=root/'.claude/worktrees/sol-f2-tokens';rid='assert-integrated-1';out=w/'build/assert-integrated';out.mkdir(exist_ok=True)
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((w/'build/worker-build.replay-integrated-1.request').read_text());worker=json.loads((sw/'build/worker-build.assert-messages-full-1.request').read_text());receipt=json.loads((sw/'build/worker-build.assert-messages-full-1.result').read_text());assert receipt['exit']==0 and receipt['source_hashes_verified']
assert all(H(w/p)==h for p,h in worker['sha256'].items())
extra={p:h for p,h in old['sha256'].items() if p not in worker['sha256']};assert all(H(w/p)==h for p,h in extra.items())
changed=subprocess.check_output(['git','diff','--name-only','a9a67fc','1964825'],cwd=w,text=True).splitlines();assert all(p.endswith('.md') or p.startswith(('results/','tasks/')) for p in changed),changed
q=dict(request_id=rid,cwd=str(w),source_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),kind='integration-default-gate-validation',command=['scripts/check.sh'],targets=[],sha256={**worker['sha256'],**extra},note='Fresh combined default gate; all3379 runtime inputs identical to independently reviewed/passing worker full-CSem gate. Additional269previous-main pins unchanged; current compiler image rebuilt. Worker5nativepairs remain image-pinned worker observations, not new lead runs.')
for name in ['worker-build.request',f'worker-build.{rid}.request']:(w/'build'/name).write_text(json.dumps(q,indent=2)+'\n')
(out/'equivalence.json').write_text(json.dumps(dict(worker_commit='a9a67fccfd2092c32966026a967592e748765e71',combined_commit=q['source_revision'],runtime_inputs=len(worker['sha256']),extra_inputs=len(extra),nonruntime_tree_changes=changed,worker_receipt=receipt),indent=2)+'\n')
def verify():assert all(H(w/p)==h for p,h in q['sha256'].items())
with (root/'build/lake.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX);verify();subprocess.run(['free','-g'],check=True);assert int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))//1024**2>=25
 cmd=['systemd-run','--user','--scope','-p','MemoryMax=12G','make','-s','-C','c','BUILD=build','FLAGS=0','ELF=build/base.elf','build/base.elf']
 with (out/'image-build.log').open('w') as f:subprocess.run(cmd,cwd=w,stdout=f,stderr=subprocess.STDOUT,check=True)
(out/'image-pins.json').write_text(json.dumps({str(p.relative_to(w)):H(p) for p in [w/'c/build/base.elf',w/'c/build/tcc.o',w/'build/cross/riscv64-tcc',w/'build/cross/riscv64-libtcc1.a']},indent=2)+'\n')
log=w/f'build/worker-build-{rid}.log'
with log.open('w') as f:p=subprocess.run(['scripts/check.sh'],cwd=w,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'SYT_LAKE_LOCK':str(root/'build/lake.lock')})
verify();res=dict(request_id=rid,exit=p.returncode,command=['scripts/check.sh'],source_hashes_verified=True,log=str(log.relative_to(w)),validation_scope=q['note'])
for name in ['worker-build.result',f'worker-build.{rid}.result']:(w/'build'/name).write_text(json.dumps(res,indent=2)+'\n')
print(res,flush=True)
