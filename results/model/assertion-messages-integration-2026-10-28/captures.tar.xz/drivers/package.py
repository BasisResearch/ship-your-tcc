from pathlib import Path
import json,hashlib,tarfile,io,shutil,sys
r=Path(__file__).resolve().parents[1];w=r/'.claude/worktrees/sol-c11-line';sw=r/'.claude/worktrees/sol-f2-tokens';d=w/'results/model/assertion-messages-integration-2026-10-28';d.mkdir(exist_ok=True)
q=json.loads((w/'build/worker-build.assert-integrated-1.request').read_text());res=json.loads((w/'build/worker-build.assert-integrated-1.result').read_text());assert res['exit']==0 and res['source_hashes_verified'];H=lambda b:hashlib.sha256(b).hexdigest();assert all(H((w/p).read_bytes())==h for p,h in q['sha256'].items())
paths={'gate/request.json':w/'build/worker-build.assert-integrated-1.request','gate/result.json':w/'build/worker-build.assert-integrated-1.result','gate/log':w/res['log'],'prior/request.json':w/'build/worker-build.replay-integrated-1.request'}
for name in ['request','result']:paths['worker/full.'+name+'.json']=sw/('build/worker-build.assert-messages-full-1.'+name)
for name in ['equivalence.json','image-pins.json','image-build.log']:paths['combined/'+name]=w/'build/assert-integrated'/name
paths['drivers/integrate.py']=r/'build/run_assert_integration.py';paths['worker/report.md']=w/'results/model/static-assert-messages.md'
for name in ['image-comparison.json','archive-sections.json','archive-symbols.json']:paths['combined/'+name]=w/'build/assert-integrated'/name
for name in ['compare_assert_archives.py','compare_assert_symbols.py']:paths['drivers/'+name]=r/'build'/name
paths['drivers/package.py']=Path(__file__)
def tree(p,prefix):
 for f in p.rglob('*'):
  if f.is_file():paths[prefix+'/'+str(f.relative_to(p))]=f
native=w/'build/assert-integrated/native';tree(native,'native/execution')
sys.path.insert(0,str(w/'scripts'))
import model_diff as m
from source_fixtures import fixture_entries
nd=json.loads((native/'arenas.json').read_text());assert nd['totals']=={'n':1,'same':1}
row=[row for rs in nd['results'].values() for row in rs][0];name=row['name'];source=(w/name).resolve();extra=[(v,str(h)) for v,h in fixture_entries(source)]
key=m.sha('independent-c11-handoff-v4',source.read_bytes(),repr(extra),repr(['-w']),repr([]),nd['runtime_key'],(w/'c/src/gen_embed.sh').read_bytes(),*[Path(h).read_bytes() for _,h in extra])
key=m.sha(key,'native-sail-full-arena-v1',json.dumps(nd['sail_settings'],sort_keys=True))
ref=w/f'build/model_diff/cache/{key}.arena';model=w/f'build/model_diff/work/{m.sha(name,"c")}.arena';assert H(ref.read_bytes())==H(model.read_bytes())
paths['native/reference.arena']=ref;paths['native/model.arena']=model;paths['native/source.c']=source
tree(w/f'build/model_diff/cache/{key}.sail','native/capture')
for suffix in ['json','log']:paths['native/capture.'+suffix]=w/f'build/model_diff/cache/{key}.sail.{suffix}'
manifest={}
with tarfile.open(d/'captures.tar.xz','w:xz',preset=6) as t:
 for n,p in paths.items():
  b=p.read_bytes();manifest[n]=H(b);i=tarfile.TarInfo(n);i.size=len(b);t.addfile(i,io.BytesIO(b))
(w/'results/model/assertion-messages-integration-2026-10-28/pins.json').write_text(json.dumps(dict(archive_sha256=H((d/'captures.tar.xz').read_bytes()),members=manifest,worker_archive_sha256=H((w/'results/model/static-assert-messages/evidence.tar.xz').read_bytes()),source_inputs=len(q['sha256'])),indent=2)+'\n')
print('Packaged',len(manifest),'combined captures;',len(q['sha256']),'source inputs',flush=True)
