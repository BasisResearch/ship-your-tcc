from pathlib import Path
import struct,subprocess,json,hashlib
r=Path(__file__).resolve().parents[1];w=r/'.claude/worktrees/sol-c11-line';sw=r/'.claude/worktrees/sol-f2-tokens';a=w/'build/cross/riscv64-libtcc1.a';b=sw/'build/cross/riscv64-libtcc1.a';names=subprocess.check_output(['ar','t',str(a)],text=True).splitlines();rows=[]
def symbols(data):
 off=struct.unpack_from('<Q',data,40)[0];size,n,_=struct.unpack_from('<HHH',data,58);hs=[struct.unpack_from('<IIQQQQIIQQ',data,off+i*size) for i in range(n)];sh=next(h for h in hs if h[1]==2);ss=hs[sh[6]];strings=data[ss[4]:ss[4]+ss[5]];out=[]
 for i in range(sh[5]//sh[9]):
  no,info,other,idx,value,sz=struct.unpack_from('<IBBHQQ',data,sh[4]+i*sh[9]);out.append((strings[no:].split(b'\0',1)[0].decode(),info,other,idx,value,sz))
 return out
for name in names:
 x=symbols(subprocess.check_output(['ar','p',str(a),name]));y=symbols(subprocess.check_output(['ar','p',str(b),name]));assert len(x)==len(y);diff=[]
 for i,(l,q) in enumerate(zip(x,y)):
  if l!=q:
   assert l[1:]==q[1:] and l[1]&15==4 and Path(l[0]).name==Path(q[0]).name,(name,i,l,q)
   diff.append(dict(index=i,combined=l,worker=q))
 rows.append(dict(member=name,symbol_count=len(x),file_symbol_differences=diff));print(name,'only',len(diff),'STT_FILE path difference(s)')
(w/'build/assert-integrated/archive-symbols.json').write_text(json.dumps(dict(driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=rows),indent=2)+'\n')
