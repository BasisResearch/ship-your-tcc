from pathlib import Path
import subprocess,struct,hashlib,json
r=Path(__file__).resolve().parents[1];w=r/'.claude/worktrees/sol-c11-line';sw=r/'.claude/worktrees/sol-f2-tokens';a=w/'build/cross/riscv64-libtcc1.a';b=sw/'build/cross/riscv64-libtcc1.a';names=subprocess.check_output(['ar','t',str(a)],text=True).splitlines();rows=[]
H=lambda b:hashlib.sha256(b).hexdigest()
def sections(data):
 assert data[:6]==b'\x7fELF\x02\x01';off=struct.unpack_from('<Q',data,40)[0];size,n,stridx=struct.unpack_from('<HHH',data,58)
 hs=[struct.unpack_from('<IIQQQQIIQQ',data,off+i*size) for i in range(n)];sh=hs[stridx];strings=data[sh[4]:sh[4]+sh[5]]
 out={}
 for h in hs:
  name=strings[h[0]:].split(b'\0',1)[0].decode();payload=data[h[4]:h[4]+h[5]] if h[1]!=8 else b'';out[name]=dict(type=h[1],flags=h[2],size=h[5],sha256=H(payload),data=payload)
 return out
for name in names:
 x=subprocess.check_output(['ar','p',str(a),name]);y=subprocess.check_output(['ar','p',str(b),name]);sx,sy=sections(x),sections(y);diff=[]
 for k in sorted(set(sx)|set(sy)):
  p,q=sx.get(k),sy.get(k)
  if p!=q:diff.append(dict(section=k,combined={n:v for n,v in (p or {}).items() if n!='data'},worker={n:v for n,v in (q or {}).items() if n!='data'},combined_excerpt=p['data'][:200].decode('utf8','backslashreplace') if p and k in ['.strtab','.comment','.debug_str'] else None,worker_excerpt=q['data'][:200].decode('utf8','backslashreplace') if q and k in ['.strtab','.comment','.debug_str'] else None))
 rows.append(dict(member=name,combined=H(x),worker=H(y),differences=diff));print(name,[d['section'] for d in diff])
(w/'build/assert-integrated/archive-sections.json').write_text(json.dumps(dict(driver_sha256=H(Path(__file__).read_bytes()),rows=rows),indent=2)+'\n')
