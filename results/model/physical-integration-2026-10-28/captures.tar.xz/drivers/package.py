from pathlib import Path
import hashlib,json,tarfile,gzip,shutil,sys
root=Path(__file__).resolve().parents[1];w=root/'.claude/worktrees/sol-c11-line';out=w/'results/model/physical-integration-2026-10-28';out.mkdir(exist_ok=True)
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(w/'scripts'))
from source_fixtures import fixture_entries
from model_diff import sha
files={}
for p in (w/'build/physical-integrated').rglob('*'):
 if p.is_file():files['observations/'+str(p.relative_to(w/'build/physical-integrated'))]=p
for p in w.glob('build/physical-integrated-*.log'):files['logs/'+p.name]=p
files['logs/full-gate.log']=w/'build/worker-build-physical-integrated-1.log'
files['drivers/package.py']=Path(__file__)
for n in ['ghost_origins_cmp.py','ghost_cabs_cmp.py','physical_onoff_cmp.py','model_diff.py']:files['drivers/'+n]=w/'scripts'/n
q=json.loads((w/'build/worker-build.physical-integrated-1.request').read_text());r=json.loads((w/'build/worker-build.physical-integrated-1.result').read_text())
assert r['exit']==0 and r['source_hashes_verified'] and q['request_id']==r['request_id']
assert all(H(w/p)==h for p,h in q['sha256'].items())
for n,d in [('gate.request',q),('gate.result',r)]: (out/(n+'.json.gz')).write_bytes(gzip.compress(json.dumps(d,indent=2).encode(),mtime=0))
for n,p in [('origins','origins/comparison.json'),('shared','shared/comparison.json'),('raw','raw/comparison.json'),('erasure','onoff/erasure.json'),('arenas','arenas.json')]:shutil.copyfile(w/'build/physical-integrated'/p,out/(n+'.json'))
d=json.loads((out/'arenas.json').read_text());assert d['totals']=={'n':15,'same':15}
index=[]
for rows in d['results'].values():
 for row in rows:
  name=row['name'];p=(w/name).resolve();extra=[(v,str(h)) for v,h in fixture_entries(p)]
  def key(libs):return sha('independent-c11-handoff-v4',p.read_bytes(),repr(extra),repr(['-w']),repr(libs),d['runtime_key'],(w/'c/src/gen_embed.sh').read_bytes(),*[Path(h).read_bytes() for _,h in extra])
  k=key([]);s=(w/f'build/model_diff/cache/{k}.status').read_text()
  if 'lm' in s:k=key(['-lm']);s=(w/f'build/model_diff/cache/{k}.status').read_text()
  assert s.strip()=='ran';ref=w/f'build/model_diff/cache/{k}.arena';model=w/f'build/model_diff/work/{sha(name,"c")}.arena';assert H(ref)==H(model)
  for n,v in [('model',model),('reference',ref),('source',p)]:files[f'arenas/{p.stem}/{n}'+('.c' if n=='source' else '.arena')]=v
  index.append(dict(source=name,source_sha256=H(p),arena_sha256=H(ref),cache_key=k))
(out/'arena-index.json').write_text(json.dumps(index,indent=2)+'\n')
manifest={n:H(p) for n,p in files.items()}
with tarfile.open(out/'captures.tar.xz','w:xz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(out/'captures.tar.xz') as t:assert {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t.getmembers() if m.isfile()}==manifest
(out/'pins.json').write_text(json.dumps(dict(archive_members=manifest,artifacts={p.name:H(p) for p in out.iterdir() if p.is_file() and p.name not in ['pins.json','verify.py']},binary_pins={n:H(w/n) for n in ['.lake/build/bin/tcc_ghost','.lake/build/bin/tcc_model']}),indent=2)+'\n')
print(len(manifest),'verified captures;',len(q['sha256']),'source pins')
