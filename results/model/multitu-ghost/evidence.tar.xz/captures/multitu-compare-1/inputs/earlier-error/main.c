#ifdef LEAK
#error macro leaked across translation units
#endif
#define WIDTH long
#include "two/same.h"
#include "two/same.h"
_Static_assert(__COUNTER__==0,"counter reset");
struct Reset {char c; int x;};
_Static_assert(sizeof(struct Reset)==8,"pack reset");
static T collide=4;
static int local(void){return collide;}
int companion(void);
int main(void){return companion()+local()-7;}
