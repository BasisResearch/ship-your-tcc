#ifndef COMMON_H
#define COMMON_H
#ifndef WIDTH
#error missing local WIDTH
#endif
typedef WIDTH T;
struct Collision { T member; };
static T header_local;
#endif
/* distinct physical header */
