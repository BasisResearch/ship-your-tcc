#define __uint128__ first_uint128
#include <tccdefs.h>
#define WIDTH int
#define LEAK 99
#include "same.h"
#include "same.h"
_Static_assert(__COUNTER__==0,"counter first");
static T collide=3;
static int local(void){return collide;}
int companion(void){return local();}
