from pathlib import Path
import hashlib,io,json,re,subprocess,tarfile
ROOT=Path.cwd();OUT=ROOT/'results/model/multitu-ghost'
H=lambda b:hashlib.sha256(b).hexdigest()
files={}
def add(path,name):
 path=Path(path)
 if path.is_dir():
  for p in sorted(path.rglob('*')):
   if p.is_file() and '__pycache__' not in p.parts:add(p,name+'/'+str(p.relative_to(path)))
 else:
  b=path.read_bytes()
  if name in files:assert files[name]==b,name
  files[name]=b
final=json.loads(Path('build/worker-build.multitu-full-1.result').read_text())
assert final['exit']==0 and final['source_hashes_verified']
for p in sorted(Path('build').glob('multitu-*')):
 if p.name.startswith(('multitu-package','multitu-source-candidates','multitu-missing-source')):continue
 add(p,'captures/'+p.name)
for p in sorted(Path('build').glob('worker-build*multitu*')):add(p,'receipts/'+p.name)
add('build/lead-note.txt','receipts/final-lead-note.txt')
add('build/multitu-package-1.log','packaging/failed-1.log')
add(__file__,'tooling/package.py')
log=Path('build/worker-build-multitu-full-1.log').read_text()
for directory in re.findall(r'artifacts: (build/[^\s)]+)',log):
 if Path(directory).is_dir():add(directory,'gate-artifacts/'+directory.removeprefix('build/'))
candidates=json.loads(Path('build/multitu-source-candidates.json').read_text())
requests=sorted(Path('build').glob('worker-build.multitu-*.request'))
for req in requests:
 for name,h in json.loads(req.read_text())['sha256'].items():
  p=Path(name)
  if p.is_file() and H(p.read_bytes())==h:candidates[h]=str(p)
  assert h in candidates,(req.name,name,h)
  p=Path(candidates[h]);assert H(p.read_bytes())==h
  if 'sources/'+h not in files:add(p,'sources/'+h)
add('c/build/base.elf','runtime/base.elf');add('c/build/fs.list','runtime/fs.list');add('build/image.syms','runtime/image.syms')
ordered=[]
for line in Path('c/build/fs.list').read_text().splitlines():
 virtual,host=line.split('=',1);b=Path(host).read_bytes();h=H(b);ordered.append(dict(path=virtual,host=host,sha256=h));files['runtime/files/'+h]=b
files['runtime/ordered-files.json']=(json.dumps(ordered,indent=2)+'\n').encode()
# The original invocation and inputs remain exact, independent of captures.
add('c/invocations/tinycc-104-inline.json','invocation/manifest.json')
for p in ['vendor/tinycc/tests/tests2/104_inline.c','vendor/tinycc/tests/tests2/104+_inline.c','vendor/tinycc/tests/tests2/Makefile']:add(p,'invocation/'+Path(p).name)
OUT.mkdir(parents=True,exist_ok=True)
archive=OUT/'evidence.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as t:
 for name,b in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(b);info.mtime=0;info.mode=0o644;t.addfile(info,io.BytesIO(b))
manifest=dict(archive_sha256=H(archive.read_bytes()),members_sha256={p:H(b) for p,b in sorted(files.items())},final_build='multitu-full-1',scope='finite ordered TU and complete arena observations; universal transport, whole-run erasure and binary refinement remain open')
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('packaged',len(files),'independently hashed members;',archive.stat().st_size,'bytes')
