#ifndef COMMON_H
#define COMMON_H
#ifndef WIDTH
#error missing local WIDTH
#endif
typedef WIDTH T;
static T header_local;
#endif
/* distinct physical header */
