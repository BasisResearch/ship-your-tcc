#define WIDTH int
#define LEAK 99
#include "same.h"
#include "same.h"
struct Collision { T member; };
_Static_assert(__COUNTER__==0,"counter first");
static T collide=3;
static int local(void){return collide;}
int companion(void){return local();}
