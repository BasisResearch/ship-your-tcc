#define WIDTH int
#define LEAK 99
#include "same.h"
#include "same.h"
struct Collision { T member; };
_Static_assert(__COUNTER__==0,"counter first");
static T collide=3;
static int local(void){return collide;}
int companion(void){return local();}
int later();
static inline int unused_early(void){return later(1); }
int later(void){return 0;}
