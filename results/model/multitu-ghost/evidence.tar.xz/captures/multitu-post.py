from pathlib import Path
import json,subprocess,time,sys
root=Path.cwd();rid='multitu-full-1'
while True:
 found=None
 for p in [root/'build'/f'worker-build.{rid}.result',root/'build/worker-build.result']:
  if p.exists():
   r=json.loads(p.read_text())
   if r.get('request_id',r.get('request'))==rid:found=r;break
 if found is not None:break
 time.sleep(15)
assert found['exit']==0 and found['source_hashes_verified'],{k:found.get(k) for k in ['request_id','exit','source_hashes_verified']}
def run(command,name):
 with open('build/'+name+'.log','wb') as log:
  r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,cwd=root)
 assert r.returncode==0,(name,r.returncode)
 print(name,'passed',flush=True)
run(['python3','scripts/multitu_build_request.py',rid,'--verify'],'multitu-full-1.verify')
run(['python3','scripts/multitu_ghost_cmp.py','--build-id',rid,'--out','build/multitu-final'],'multitu-final')
children=[]
for name,command in [
 ('multitu-independent-final',['python3','scripts/ghost_cabs_cmp.py','--independent-raw','--build-id',rid,'--out','build/multitu-independent-final']),
 ('multitu-fast',['python3','scripts/multitu_arenas.py','--build-id',rid,'--comparison','build/multitu-final/comparison.json','--out','build/multitu-fast'])]:
 log=open('build/'+name+'.log','wb');children.append((name,subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,cwd=root),log))
failed=[]
for name,child,log in children:
 code=child.wait();log.close();print(name,'exit',code,flush=True)
 if code:failed.append(name)
assert not failed,failed
print('all final source-pinned postchecks passed',flush=True)
