from pathlib import Path
import hashlib,json,subprocess
H=lambda b:hashlib.sha256(b).hexdigest()
requests=sorted(Path('build').glob('worker-build.multitu-*.request'))
needed={}
for req in requests:
 for name,h in json.loads(req.read_text())['sha256'].items():needed.setdefault(name,set()).add(h)
candidates={}
for name,hs in needed.items():
 p=Path(name)
 if p.is_file():candidates.setdefault(H(p.read_bytes()),str(p))
for p in Path('build').glob('multitu-*-build-sources/**/*'):
 if p.is_file():candidates.setdefault(H(p.read_bytes()),str(p))
for p in Path('build/multitu-reconstructed-source').rglob('*'):
 if p.is_file():candidates.setdefault(H(p.read_bytes()),str(p))
missing=[]
for name,hs in needed.items():
 if hs-set(candidates):
  try:
   data=subprocess.check_output(['git','show','HEAD:'+name],stderr=subprocess.DEVNULL)
   h=H(data)
   if h in hs:
    p=Path('build/multitu-original-sources')/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);candidates[h]=str(p)
  except subprocess.CalledProcessError:pass
 for h in hs:
  if h not in candidates:missing.append((name,h))
Path('build/multitu-source-candidates.json').write_text(json.dumps(candidates,indent=2)+'\n')
Path('build/multitu-missing-source-variants.json').write_text(json.dumps(missing,indent=2)+'\n')
print('source versions found',len(candidates),'missing',len(missing))
for name,h in missing:print(name,h[:12])
