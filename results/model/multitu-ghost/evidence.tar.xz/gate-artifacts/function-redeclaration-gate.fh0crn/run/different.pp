# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
static
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
       int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
           mine
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
               (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                   )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                    ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
static
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
       int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
           mine
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
               (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                    x
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                     )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                      {
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                       return
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                              x
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                               +
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                10
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                  ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                   }
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
static
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
       int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
           mine
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
               (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                   )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                    ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
static
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
       int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
           other
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                 int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                    )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                     ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                      static
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                             int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                 other
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                      (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                       int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                           x
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                            )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                             {
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                              return
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                     x
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                      +
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                       20
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                         ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                          }
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                           static
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                  int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                      other
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                           (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                            int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                               )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                 int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                     main
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                         (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                          void
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                              )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                               {
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                    (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                     *
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                      p
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                       )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                        (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                         int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                            )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                             =
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                              mine
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                  ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                   int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                       (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                        *
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                         q
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                          )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                           (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                            int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                               )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                =
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                 other
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                      ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                       return
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                              p
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                               ==
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                                 q
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                                   ||
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                                      p
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                                       (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                                        1
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                                         )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                                          !=
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                                            11
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                                               ||
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                                                  q
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                                                   (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                                                    1
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                                                     )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                                                      !=
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                                                        21
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                                                           ||
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                                                              p
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                                                               !=
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                                                                 mine
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                                                                      ||
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                                                                         q
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                                                                          !=
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                                                                            other
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                                                                                 ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/different.c"
                                                                                                                                                                                                  }

