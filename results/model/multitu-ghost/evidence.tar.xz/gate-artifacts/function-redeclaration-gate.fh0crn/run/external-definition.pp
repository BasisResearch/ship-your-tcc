# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
    mine
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
        (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
         int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
             x
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
              )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
               {
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                return
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                       x
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                        +
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                         10
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                           ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                            }
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
    main
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
        (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
         void
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
             )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
              {
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
               int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                   (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                    *
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                     p
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                      )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                       (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                        int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                           )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                            =
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                             mine
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                 ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                   int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                       (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                        *
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                         q
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                          )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                           (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                            int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                               )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                =
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                 &
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                  mine
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                      ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                        return
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                               mine
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                   (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                    7
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                     )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                      !=
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                        17
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                           ||
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                              p
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                               (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                                7
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                                 )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                                  !=
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                                    17
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                                       ||
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                                          (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                                           *
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                                            q
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                                             )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                                              (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                                               7
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                                                )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                                                 !=
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                                                   17
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                                                      ||
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                                                         p
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                                                          !=
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                                                            q
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                                                              ||
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                                                                 p
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                                                                  ==
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                                                                    0
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                                                                     ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-f2-tokens/build/function-redeclaration-gate.fh0crn/run/sources/external-definition.c"
                                                                                                                      }

