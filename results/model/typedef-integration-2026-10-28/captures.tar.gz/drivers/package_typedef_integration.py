import json,gzip,hashlib,tarfile,shutil,re
from pathlib import Path
root=Path(__file__).resolve().parents[1];w=root/'.claude/worktrees/sol-c11-line';old=root/'.claude/worktrees/sol-f2-tokens';out=w/'results/model/typedef-integration-2026-10-28';out.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
q=json.loads((w/'build/worker-build.typedef-integrated-1.request').read_text());r=json.loads((w/'build/worker-build.typedef-integrated-1.result').read_text());supp=json.loads((w/'build/typedef-integrated-supplementary-pins.json').read_text());assert r['exit']==0 and r['source_hashes_verified']
for d in [q,supp]:assert all(sha(w/p)==h for p,h in d['sha256'].items())
for name,p in {'gate.request':w/'build/worker-build.typedef-integrated-1.request','gate.result':w/'build/worker-build.typedef-integrated-1.result','supplementary':w/'build/typedef-integrated-supplementary-pins.json'}.items():(out/(name+'.json.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
paths={n:w/f'build/typedef-integrated/{n}/comparison.json' for n in ['fixtures','raw-ghost','origins','erasure','native']}
paths.update({'arenas':w/'build/typedef-integrated/arenas.json','worker-native':old/'build/typedef-lead-native/comparison.json','historical-corpus':old/'build/typedef-lead-native/historical-corpus.json'})
for n,p in paths.items():shutil.copyfile(p,out/(n+'.json'))
gatelog=w/'build/worker-build-typedef-integrated-1.log';gatepath=re.findall(r'^GNU declaration/header artifacts: (.+)$',gatelog.read_text(),re.M)[-1]
files={}
def tree(base,prefix,target):
 for p in base.rglob('*'):
  if p.is_file():files[prefix+'/'+str(p.relative_to(target))]=p
for name in ['build/typedef-integrated',gatepath,'build/ghost-byte-inputs']:tree(w/name,'combined',w)
for name in ['build/typedef-lead-native','build/typedef-fixtures-final4']:tree(old/name,'worker',old)
for key in ['574f5892d88cec33d2e1dca9','7ae48c8bcb77995a09f43f8e']:
 tree(old/f'build/model_diff/cache/{key}.sail','worker',old)
 for p in (old/'build/model_diff/cache').glob(key+'.*'):
  if p.is_file():files['worker/'+str(p.relative_to(old))]=p
# Retain the exact historical 400 mutants; source pins were verified before run.
for p in (old/'build').rglob('*.c'):
 if 'gen-mutant' in str(p):files['worker/'+str(p.relative_to(old))]=p
for base,prefix in [(w,'combined'),(old,'worker')]:
 for n in ['build/image.syms','c/build/fs.list','c/build/base.elf']:
  files[prefix+'/'+n]=base/n
for n in ['worker-build-typedef-integrated-1.log','typedef-integrated-image.log','typedef-integrated-image.sha256','typedef-fixtures.log','typedef-raw-ghost.log','typedef-origins.log','typedef-arenas.log']:
 p=w/'build'/n
 if p.exists():files['combined/build/'+n]=p
for name in ['package_typedef_integration.py','recompare_typedef_native.py','replay_typedef_erasure.py']:files['drivers/'+name]=root/'build'/name
# Validate the worker archive independently rather than trust its prose.
m=json.loads((w/'results/model/typedef-alignment/manifest.json').read_text());a=w/'results/model/typedef-alignment/observations.tar.gz';assert sha(a)==m['archive_sha256']
with tarfile.open(a) as t:assert {x.name:hashlib.sha256(t.extractfile(x).read()).hexdigest() for x in t.getmembers() if x.isfile()}==m['members_sha256']
manifest={a:sha(p) for a,p in sorted(files.items())}
with tarfile.open(out/'captures.tar.gz','w:gz') as t:
 for a,p in sorted(files.items()):t.add(p,arcname=a,recursive=False)
with tarfile.open(out/'captures.tar.gz') as t:assert {x.name:hashlib.sha256(t.extractfile(x).read()).hexdigest() for x in t.getmembers() if x.isfile()}==manifest
bins={str(p.relative_to(w)):sha(p) for p in (w/'.lake/build/bin').iterdir() if p.name in ['tcc_ghost','tcc_model','csem_raw','csem_cparse','pre_spec','tcc_pre_tokens']}
for n in ['fixtures','raw-ghost','origins']:assert json.loads((out/(n+'.json')).read_text())['binary_sha256']==bins['.lake/build/bin/tcc_ghost']
dump(out/'pins.json',dict(gate_source_count=len(q['sha256']),supplementary_source_count=len(supp['sha256']),worker_archive_members=len(m['members_sha256']),binary_pins=bins,archive_members=manifest,artifacts={p.name:sha(p) for p in out.iterdir() if p.is_file() and p.name not in ['pins.json','verify.py']}))
print(len(manifest),'verified combined capture members;',len(m['members_sha256']),'verified worker members')
