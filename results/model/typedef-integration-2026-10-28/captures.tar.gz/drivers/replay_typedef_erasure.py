import hashlib,json,subprocess,os
from pathlib import Path
root=Path(__file__).resolve().parents[1];w=root/'.claude/worktrees/sol-c11-line';prior=w/'build/ghost-erasure-final/comparison.json';out=w/'build/typedef-integrated/erasure';out.mkdir(parents=True,exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
old=json.loads(prior.read_text());exe=w/'.lake/build/bin/tcc_model';pin=sha(exe);rows=[]
for r in old['rows']:
 src=w/r['source'];assert sha(src)==r['source_sha256'];row={'source':r['source'],'source_sha256':sha(src),'runs':[]}
 for command in r['commands']:
  command=[x.replace(str(w/'build/ghost-erasure-final'),str(out)) for x in command]
  assert command[0]==str(exe)
  p=subprocess.run(command,cwd=w,capture_output=True,timeout=180,env={**os.environ,'LEAN_ABORT_ON_PANIC':'1'})
  arena=Path(command[command.index('--arena-out')+1]);console=Path(command[command.index('--console-out')+1]);stem=arena.with_suffix('')
  Path(str(stem)+'.stdout').write_bytes(p.stdout);Path(str(stem)+'.stderr').write_bytes(p.stderr)
  assert p.returncode==0 and p.stdout==b'ran\n' and not p.stderr,(r['source'],p.returncode,p.stderr)
  record={'command':command,'exit':p.returncode,'arena_sha256':sha(arena),'console_sha256':sha(console),'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()}
  if '--ghost-out' in command:
   g=json.loads(Path(command[command.index('--ghost-out')+1]).read_text());record['ghost_status']=g['status'];assert g['status']=='ok'
  row['runs'].append(record)
 keys=['arena_sha256','console_sha256','stdout_sha256','stderr_sha256'];row['equal']=all(row['runs'][0][k]==row['runs'][1][k] for k in keys);assert row['equal'];rows.append(row);print(src.name,'equal',flush=True)
assert sha(exe)==pin;dump(out/'comparison.json',{'driver_sha256':sha(Path(__file__)),'model_sha256':pin,'prior_commands_sha256':sha(prior),'rows':rows})
