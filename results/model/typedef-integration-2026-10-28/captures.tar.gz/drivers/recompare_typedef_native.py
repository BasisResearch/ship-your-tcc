from pathlib import Path
import json,hashlib,subprocess,sys
root=Path(__file__).resolve().parents[1];w=root/'.claude/worktrees/sol-c11-line';old=root/'.claude/worktrees/sol-f2-tokens';out=w/'build/typedef-integrated/native';out.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(w/'scripts'))
from compare_sail_arena import compare
from source_fixtures import fixture_entries
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
exe=w/'.lake/build/bin/tcc_model';syms=old/'build/image.syms';fs=old/'c/build/fs.list'
pins={str(p):sha(p) for p in [exe,syms,fs,Path(__file__)]}
# Both candidates have the identical maintained compiler patches. Runtime and
# symbol files here belong to the newly captured native image, not another image.
for p in sorted((old/'patches').glob('000*.patch')):assert sha(p)==sha(w/'patches'/p.name);pins[str(p)]=sha(p)
rows=[]
for key,src in [('574f5892d88cec33d2e1dca9','results/repro/tcc_gnu_typedef_alignment.c'),('7ae48c8bcb77995a09f43f8e','build/typedef-fixtures-final4/expression-address.c')]:
 source=old/src;cap=old/f'build/model_diff/cache/{key}.sail';m=json.loads((cap/'cut.json').read_text());assert sha(source)==m['source_sha256'];pins[str(source)]=sha(source)
 fixtures=fixture_entries(source);arena=out/(source.stem+'.arena');console=out/(source.stem+'.console')
 cmd=[str(exe),'--fs',str(fs),'--syms',str(syms),'--prog',str(source),'--arena-out',str(arena),'--console-out',str(console),'--arg','-w']
 for virtual,p in fixtures:cmd+=['--extra',virtual+'='+str(p)];pins[str(p)]=sha(p)
 p=subprocess.run(cmd,cwd=old,capture_output=True,timeout=600)
 (out/(source.stem+'.stdout')).write_bytes(p.stdout);(out/(source.stem+'.stderr')).write_bytes(p.stderr)
 assert p.returncode==0 and p.stdout==b'ran\n' and not p.stderr,(p.returncode,p.stdout,p.stderr)
 result=compare(cap,arena);assert result['status']=='equal' and result['compared_bytes']==4194304
 rows.append(dict(source=src,command=cmd,exit=p.returncode,capture=str(cap.relative_to(old)),comparison=result));print(src,'equal 4194304 bytes and handoff',flush=True)
assert all(sha(p)==h for p,h in pins.items())
(out/'comparison.json').write_text(json.dumps(dict(pins=pins,rows=rows,note='Fresh combined-model executions against the two new alignment native captures, using their pinned runtime filesystem and symbols. No additional Sail execution in this recomparison.'),indent=2)+'\n')
