from pathlib import Path
import json,hashlib,tarfile,re,sys
r=Path.cwd();w=r/'.claude/worktrees/sol-c11-line';rid='multitu-physical-integrated-1';post=w/'build/multitu-physical-integrated'
out=w/'results/model/multitu-physical-integration-2026-10-28';out.mkdir(exist_ok=True)
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();files={}
def tree(path,prefix):
 for p in path.rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts:files[prefix+'/'+str(p.relative_to(path))]=p
q=json.loads((w/'build'/f'worker-build.{rid}.request').read_text());v=json.loads((w/'build'/f'worker-build.{rid}.result').read_text())
assert v['exit']==0 and v['source_hashes_verified'] and len(q['sha256'])==4162
assert all(H(w/p)==h for p,h in q['sha256'].items())
postpins=json.loads((post/'postcheck-pins.json').read_text());assert all(H(w/'.lake/build/bin'/n)==h for n,h in postpins['binaries'].items())
n=json.loads((post/'native104/receipt.json').read_text());assert n['exit']==0 and n['console_equal'] and n['source_hashes_verified']
for suffix in ['request','result']:files['gate/'+suffix+'.json']=w/'build'/f'worker-build.{rid}.{suffix}'
files['gate/log.txt']=w/'build'/f'worker-build-{rid}.log';log=files['gate/log.txt'].read_text();assert log.rstrip().endswith('check: OK')
files['runtime/image.syms']=w/'build/image.syms';tree(post,'post')
for p in ['package_multitu_physical.py','prepare_multitu_verifier.py','post_multitu_physical_integration.py','measure_multitu104_native.py','freeze_invocation_arenas.py','review_combined_attribute_cabs.py']:files['drivers/'+p]=r/'build'/p
roots=re.findall(r'^(?:unevaluated syntax artifacts|assertion message artifacts|GNU expression artifacts|array decay artifacts): (.+)$',log,re.M);assert len(roots)==4,roots
sys.path.insert(0,str(w/'scripts'));from freeze_sail_arenas import freeze
exports=w/'build/multitu-physical-native-exports';exports.mkdir(exist_ok=True);native=[]
for root in roots:
 tree(w/root,'gates/'+Path(root).name)
 for report in (w/root).rglob('arenas.json'):
  if not json.loads(report.read_text()).get('sail_settings'):continue
  prefix=str(len(native));target=exports/prefix
  info=json.loads((target/'inventory.json').read_text()) if target.exists() else freeze(report,target)
  assert info['successes']==1 and info['report_sha256']==H(report)
  assert all(H(target/row['directory']/p)==h for row in info['rows'] for p,h in row['files'].items())
  native.append(dict(prefix=prefix,report='gates/'+str(report.relative_to(w/Path(root).parent)),inventory=info))
assert len(native)==6;tree(exports,'native')
(out/'native-index.json').write_text(json.dumps(native,indent=2)+'\n')
for p,h in q['sha256'].items():files['sources/'+h]=w/p
references={p:H(w/p) for p in ['results/model/multitu-ghost/manifest.json','results/model/physical-transform-proofs/pins.json','results/csem/bitfield-attributes-integration-2026-10-28/pins.json']}
manifest={name:H(p) for name,p in files.items()}
archive=out/'captures.tar.xz';assert not archive.exists(),'retain previous attempt explicitly before retry'
with tarfile.open(archive,'w:xz',preset=6,dereference=True) as t:
 for name,p in sorted(files.items()):t.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r|xz') as t:
 observed={}
 for m in t:
  assert m.isfile() and m.name not in observed
  observed[m.name]=hashlib.sha256(t.extractfile(m).read()).hexdigest()
 assert observed==manifest
assert all(H(w/p)==h for p,h in q['sha256'].items())
(out/'pins.json').write_text(json.dumps(dict(archive_sha256=H(archive),native_index_sha256=H(out/'native-index.json'),inputs=len(q['sha256']),references=references,members=manifest),indent=2)+'\n')
print('Packaged',len(manifest),'members;',len(native),'inherited native exports plus new104;4162inputs',flush=True)
