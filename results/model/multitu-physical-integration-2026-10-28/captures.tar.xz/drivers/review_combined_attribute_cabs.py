from pathlib import Path
import json,hashlib,subprocess,gzip,os,sys,collections
r=Path.cwd();w=r/'.claude/worktrees/sol-c11-line';out=w/'build/multitu-physical-integrated/attribute-merge-review';out.mkdir(exist_ok=False)
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
q=json.loads((w/'build/worker-build.multitu-physical-integrated-1.request').read_text())
assert all(H(w/p)==h for p,h in q['sha256'].items())
old=r/'.lake/build/bin/tcc_ghost';new=w/'.lake/build/bin/tcc_ghost';binary={str(p):H(p) for p in [old,new]}
refresh=json.loads((r/'build/main-artifact-refresh-2026-10-28-bitattr/result.json').read_text());assert refresh['exit']==0 and H(old)==refresh['binaries']['tcc_ghost']
sys.path.insert(0,str(w/'scripts'));from ghost_cabs_cmp import first_diff
rows=[]
for ent in json.loads((w/'c/tests/bitfield-attributes/manifest.json').read_text()):
    p=w/ent['path'];assert H(p)==ent['sha256'];d=out/ent['name'];d.mkdir();objects={}
    for name,exe,mode in [('adopted-model',old,'raw-model'),('combined-model',new,'raw-model'),('independent-raw',new,'independent-raw')]:
        cmd=[str(exe),mode,str(p)]
        result=subprocess.run(cmd,capture_output=True,timeout=180,env={**os.environ,'LEAN_ABORT_ON_PANIC':'1'})
        (d/(name+'.command.json')).write_text(json.dumps(dict(command=cmd,exit=result.returncode))+'\n');(d/(name+'.json.gz')).write_bytes(gzip.compress(result.stdout,mtime=0));(d/(name+'.stderr')).write_bytes(result.stderr)
        assert result.returncode==0,(ent['name'],name,result.returncode)
        objects[name]=json.loads(result.stdout)
    spec=objects['independent-raw'];row=dict(ent,comparisons={})
    for name in ['adopted-model','combined-model']:
        m=objects[name];diff=first_diff(m['cabs'],spec['cabs']) if m['status']==spec['status']=='ok' else 'explicit-nonsuccess'
        row['comparisons'][name]=dict(model=m['status'],spec=spec['status'],difference=diff,gap=m.get('gap'),model_error=m.get('error'),spec_error=spec.get('error'))
        assert m.get('section_bytes_equal') is not False,(ent['name'],name)
    row['regression']=row['comparisons']['adopted-model']['difference'] is None and row['comparisons']['combined-model']['difference'] is not None
    rows.append(row);print(ent['name'],row['comparisons']['adopted-model']['difference'],row['comparisons']['combined-model']['difference'],flush=True)
assert all(H(p)==h for p,h in binary.items()) and all(H(w/p)==h for p,h in q['sha256'].items())
summary={n:dict(collections.Counter('exact' if x['comparisons'][n]['difference'] is None else x['comparisons'][n]['difference'] for x in rows)) for n in ['adopted-model','combined-model']}
(out/'report.json').write_text(json.dumps(dict(note='Focused model-owned Cabs merge review; independent syntax only, no new semantic or theorem claim.',rows=rows,summary=summary,binaries=binary,request_sha256=H(w/'build/worker-build.multitu-physical-integrated-1.request'),driver_sha256=H(__file__)),indent=2)+'\n');print(summary,flush=True)
assert not any(x['regression'] for x in rows),'combined model regresses an adopted exact case'
