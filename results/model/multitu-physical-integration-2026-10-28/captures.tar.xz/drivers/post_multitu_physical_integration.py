from pathlib import Path
import json,hashlib,subprocess,time
r=Path.cwd();w=r/'.claude/worktrees/sol-c11-line';out=w/'build/multitu-physical-integrated';rid='multitu-physical-integrated-1'
q=json.loads((w/'build'/f'worker-build.{rid}.request').read_text());H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for _ in range(1440):
 p=w/'build/worker-build.result'
 if p.exists():
  v=json.loads(p.read_text())
  if v.get('request_id')==rid:
   assert v['exit']==0 and v['source_hashes_verified'],v
   (w/'build'/f'worker-build.{rid}.result').write_text(json.dumps(v,indent=2)+'\n');break
 time.sleep(5)
else:raise TimeoutError('combined full gate did not complete')
assert all(H(w/p)==h for p,h in q['sha256'].items())
bins={n:H(w/'.lake/build/bin'/n) for n in ['tcc_model','tcc_ghost','csem_raw','csem_cparse','csem_run']}
commands=[('multitu',['python3','scripts/multitu_ghost_cmp.py','--build-id',rid,'--out',str(out/'multitu')]),('multitu-arenas',['python3','scripts/multitu_arenas.py','--build-id',rid,'--comparison',str(out/'multitu/comparison.json'),'--out',str(out/'multitu-arenas')])]
for name,opts in [('shared',[]),('component',['--raw']),('independent',['--independent-raw'])]:commands.append((name,['python3','scripts/ghost_cabs_cmp.py','--build-id',rid,'--out',str(out/name),*opts]))
commands.extend([('physical',['python3','scripts/ghost_origins_cmp.py','--build-id',rid,'--out',str(out/'physical')]),('onoff',['python3','scripts/physical_onoff_cmp.py','--build-id',rid,'--out',str(out/'onoff')])])
for name,cmd in commands:
 with (out/(name+'.log')).open('w') as f:v=subprocess.run(cmd,cwd=w,stdout=f,stderr=subprocess.STDOUT,timeout=7200)
 (out/(name+'.command.json')).write_text(json.dumps(dict(command=cmd,exit=v.returncode),indent=2)+'\n');assert v.returncode==0,(name,v.returncode)
 print('PASS',name,flush=True)
assert all(H(w/p)==h for p,h in q['sha256'].items()) and all(H(w/'.lake/build/bin'/n)==h for n,h in bins.items())
(out/'postcheck-pins.json').write_text(json.dumps(dict(primary=len(q['sha256']),binaries=bins,driver_sha256=H(Path(__file__))),indent=2)+'\n');print('Combined independent postchecks complete',flush=True)
