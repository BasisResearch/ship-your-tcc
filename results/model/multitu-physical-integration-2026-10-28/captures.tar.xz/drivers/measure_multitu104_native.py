from pathlib import Path
import hashlib,json,subprocess,os,sys,time,re,lzma,shutil

r=Path.cwd();w=r/'.claude/worktrees/sol-c11-line'
rid='multitu-physical-integrated-1'
q=json.loads((w/'build'/f'worker-build.{rid}.request').read_text())
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def verify():
    assert all(H(w/p)==h for p,h in q['sha256'].items())
def memory():
    subprocess.run(['free','-g'],check=True)
    assert int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))//1024**2>=25

# The default/model build and axiom checks precede this marker. Later CSem
# builds do not modify tcc_model; preserve and recheck its actual binary hash.
for _ in range(720):
    log=w/'build'/f'worker-build-{rid}.log'
    if log.exists() and '== (8) CSem gates' in log.read_text():break
    time.sleep(5)
else:raise TimeoutError('combined model build did not complete')
verify();memory()
out=w/'build/multitu-physical-integrated/native104';out.mkdir(exist_ok=False)
binary=H(w/'.lake/build/bin/tcc_model')
capture=w/'build/unevaluated-native-tool/capture_cut';assert capture.is_file()
cmd=['python3','scripts/model_diff.py','--invocations','--no-report','--require-success','1','--json-out',str(out/'arenas.json'),'--sail-capture',str(capture),'-j','1','c/invocations/tinycc-104-inline.json']
start=time.monotonic()
with (out/'arenas.log').open('w') as f:run=subprocess.run(cmd,cwd=w,stdout=f,stderr=subprocess.STDOUT,timeout=3600)
(out/'arenas-command.json').write_text(json.dumps(dict(command=cmd,exit=run.returncode),indent=2)+'\n');assert run.returncode==0
subprocess.run(['python3',str(r/'build/freeze_invocation_arenas.py'),'--repo',str(w),'--report',str(out/'arenas.json'),'--out',str(out/'capture')],check=True)
report=json.loads((out/'arenas.json').read_text());rows=[x for xs in report['results'].values() for x in xs];assert len(rows)==1 and rows[0]['result']=='same';observation=rows[0]['sail']
sys.path.insert(0,str(w/'scripts'));from source_fixtures import load_invocation
inv=load_invocation(w/'c/invocations/tinycc-104-inline.json',w)
env={**os.environ,'ELF_OUT':str(out/'prog.elf'),'TCC_ARGS':''.join(json.dumps(a)+',' for a in inv['args']),'TCC_LIBS':' ','EXTRA_FILES':' '.join(v+'='+str(p) for v,p in inv['extra'])}
cmd=['scripts/ref_arena.sh',inv['source'],str(out/'reconstructed.arena'),str(out/'reconstructed.console')]
with (out/'reconstructed.log').open('w') as f:run=subprocess.run(cmd,cwd=w,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=600)
(out/'reconstructed-command.json').write_text(json.dumps(dict(command=cmd,exit=run.returncode,invocation=inv),indent=2)+'\n');assert run.returncode==0
elf=out/'prog.elf';assert H(elf)==observation['elf_sha256'],'reconstruction is not the observed ELF'
assert not (out/'reconstructed.console').read_bytes()
tc=next((Path.home()/'toolchains').glob('xpack-riscv-none-elf-gcc-15.2.0-*/bin'))
nm=subprocess.check_output([str(tc/'riscv-none-elf-nm'),str(elf)],text=True)
symbols={line.split()[2]:int(line.split()[0],16) for line in nm.splitlines() if len(line.split())==3}
dis=subprocess.check_output([str(tc/'riscv-none-elf-objdump'),'-d','--disassemble=_exit',str(elf)],text=True)
exitpc=int(next(line.split()[0].rstrip(':') for line in dis.splitlines() if len(line.split())>2 and line.split()[2]=='sd'),16)
pcs=[symbols['tcc_baremetal_run'],symbols['tcc_baremetal_enter'],exitpc]
(out/'pcs').write_text(''.join(hex(p)+'\n' for p in pcs))
emu=Path.home()/'Documents/code/ship-your-lua/riscv-lean/lean_emulator/.lake/build/bin/lean_riscv_emulator'
memory();cmd=['systemd-run','--user','--scope','-p','MemoryMax=12G',str(emu),str(elf),'--trace-pcs',str(out/'pcs'),'--max-steps','200000000']
with (out/'raw').open('wb') as so,(out/'trace').open('wb') as se:run=subprocess.run(cmd,cwd=w,stdout=so,stderr=se,timeout=3600)
with (out/'stdout').open('wb') as f:subprocess.run(['python3','-I','scripts/sail_console.py',str(out/'raw')],cwd=w,stdout=f,check=True)
trace=(out/'trace').read_text();assert 'TRACE-FUEL-OUT' not in trace
steps={int(xs[2],16):int(xs[1]) for line in trace.splitlines() if line.startswith('T\t') for xs in [line.split('\t')]};assert all(p in steps for p in pcs)
expected=w/'vendor/tinycc/tests/tests2/104_inline.expect';assert str(expected.relative_to(w)) in q['sha256']
shutil.copyfile(expected,out/'expected.stdout');assert run.returncode==0 and (out/'stdout').read_bytes()==expected.read_bytes()
verify();assert H(w/'.lake/build/bin/tcc_model')==binary
with lzma.open(out/'prog.elf.xz','wb',preset=0) as z:z.write(elf.read_bytes())
assert hashlib.sha256(lzma.decompress((out/'prog.elf.xz').read_bytes())).hexdigest()==observation['elf_sha256']
receipt=dict(command=cmd,exit=run.returncode,source_hashes_verified=True,model_binary_sha256=binary,elf_sha256=H(elf),emulator_sha256=H(emu),invocation=inv,compile_steps=steps[pcs[0]],program_steps=steps[pcs[2]]-steps[pcs[1]]+1,total_steps=steps[pcs[2]]+1,console_equal=True,wall_seconds=time.monotonic()-start,driver_sha256=H(__file__))
elf.unlink()
receipt['artifacts']={str(p.relative_to(out)):H(p) for p in out.rglob('*') if p.is_file()}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print({k:v for k,v in receipt.items() if k not in ('artifacts','invocation')},flush=True)
