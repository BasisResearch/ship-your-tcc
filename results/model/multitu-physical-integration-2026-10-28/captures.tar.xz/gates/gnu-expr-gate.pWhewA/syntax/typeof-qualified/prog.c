const volatile int x=3; typeof(x) y=4; typeof(x) *p=&y;
