int f(typeof(const int *) p,typeof(int [3]) a);
