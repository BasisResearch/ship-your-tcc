int x;typeof(typeof(x)) y;
