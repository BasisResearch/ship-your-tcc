typeof(const volatile unsigned long *) p;
