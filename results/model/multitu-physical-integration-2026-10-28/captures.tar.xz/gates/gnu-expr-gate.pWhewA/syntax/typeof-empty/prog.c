typeof() x;
