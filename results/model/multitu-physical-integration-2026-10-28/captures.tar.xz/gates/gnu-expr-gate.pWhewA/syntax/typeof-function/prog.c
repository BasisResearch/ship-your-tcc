int f(int);typeof(f) g;typeof(&f) p;
