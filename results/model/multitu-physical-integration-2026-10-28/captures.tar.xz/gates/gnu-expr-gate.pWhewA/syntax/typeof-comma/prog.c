int x,y;typeof((x,y)) z;
