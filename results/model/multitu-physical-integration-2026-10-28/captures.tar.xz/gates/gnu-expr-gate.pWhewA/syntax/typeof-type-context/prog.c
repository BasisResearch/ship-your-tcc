typedef typeof(int) N;struct S{typeof(N) n;};
