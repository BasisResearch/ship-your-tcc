typedef int T; typeof(T) x; typeof(T *) p;
