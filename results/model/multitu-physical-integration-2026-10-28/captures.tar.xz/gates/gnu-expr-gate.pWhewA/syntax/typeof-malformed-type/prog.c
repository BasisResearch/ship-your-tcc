typeof(int *) ) x;
