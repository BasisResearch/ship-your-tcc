int f(int n){int a[n++];typeof(a) b;return sizeof(b)+n;}
