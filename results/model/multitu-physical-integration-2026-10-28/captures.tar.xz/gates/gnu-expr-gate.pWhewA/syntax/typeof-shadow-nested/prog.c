typedef int T;int f(T x){{int T=3;typeof(T) a=T;}typeof(T) b=x;return b;}
