int f(void){int n=0;typeof(n++) x=2;return n+x;}
