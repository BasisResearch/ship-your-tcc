const int n=1;typeof(++n) x;
