int a[_Generic(0,int:2,default:3)]; int f(void){int n=_Generic(0,int:1,default:2); return n;}
