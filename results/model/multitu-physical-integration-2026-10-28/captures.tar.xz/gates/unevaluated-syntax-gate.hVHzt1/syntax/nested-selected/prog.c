int f(int x){return _Generic(x,int:_Generic(x,int:1,default:2),default:3);}
