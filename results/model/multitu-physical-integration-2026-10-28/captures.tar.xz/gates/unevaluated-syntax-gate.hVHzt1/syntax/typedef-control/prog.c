typedef int Number; int f(Number x){return _Generic(x,Number:1,default:2);}
