int f(void){return _Generic(0,double:1);}
