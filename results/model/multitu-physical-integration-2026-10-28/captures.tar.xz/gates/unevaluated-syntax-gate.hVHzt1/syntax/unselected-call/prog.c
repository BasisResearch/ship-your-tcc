int call(void); int f(void){return _Generic(0,int:7,default:call());}
