int f(void){return _Generic(0,int:1,int:2);}
