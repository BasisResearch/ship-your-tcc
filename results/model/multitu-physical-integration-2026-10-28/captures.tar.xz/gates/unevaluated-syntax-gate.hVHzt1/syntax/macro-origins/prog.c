#define PICK(x) _Generic((x),int:(x)+1,default:(x)+2)
#define ASSERT(e) _Static_assert((e),"macro" " msg")
#line 70 "unevaluated.c"
ASSERT(PICK(0)==1); int f(int n){return PICK(n++);}
