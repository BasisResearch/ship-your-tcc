int f(void){_Static_assert(0,"false block"); return 0;}
