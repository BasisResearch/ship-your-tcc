#include "syntax.h"
_Static_assert(SELECT(0)==1,"header"); int f(int n){return SELECT(n);}
