union U {_Static_assert(1,"union"); int n;};
