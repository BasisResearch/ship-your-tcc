struct S {struct T {_Static_assert(1,"nested"); int n;} t; _Static_assert(1,"after");};
