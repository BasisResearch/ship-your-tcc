typedef int *Pointer; int f(Pointer x){return _Generic(x,Pointer:1,default:2);}
