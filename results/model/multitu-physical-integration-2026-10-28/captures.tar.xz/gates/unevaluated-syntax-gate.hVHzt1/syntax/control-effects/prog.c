int f(void){int n=0; return _Generic(n++,int:n,default:n+1);}
