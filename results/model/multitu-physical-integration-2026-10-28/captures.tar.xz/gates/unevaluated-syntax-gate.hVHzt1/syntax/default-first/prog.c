int f(double x){return _Generic(x,default:7,int:9);}
