_Static_assert(_Generic(0,int:1,default:0),"generic"); int x;
