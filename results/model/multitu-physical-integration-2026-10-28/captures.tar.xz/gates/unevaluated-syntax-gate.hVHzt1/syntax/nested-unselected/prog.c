int f(int x){return _Generic(x,int:1,default:_Generic(x,int:2,default:3));}
