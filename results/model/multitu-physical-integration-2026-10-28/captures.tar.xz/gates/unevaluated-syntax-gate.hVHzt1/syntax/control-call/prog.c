int call(void); int f(void){return _Generic(call(),int:7,default:9);}
