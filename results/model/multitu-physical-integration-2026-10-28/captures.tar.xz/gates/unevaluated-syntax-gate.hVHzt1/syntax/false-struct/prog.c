struct S {_Static_assert(0,"false member"); int n;};
