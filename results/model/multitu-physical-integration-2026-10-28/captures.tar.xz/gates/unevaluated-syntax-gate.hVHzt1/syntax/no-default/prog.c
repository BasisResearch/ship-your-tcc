int f(int x){return _Generic(x,int:7,double:9);}
