_Static_assert(sizeof(_Generic(0,int:"ab",default:"long"))==3,"string"); int x;
