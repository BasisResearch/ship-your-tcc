_Static_assert(1,"raw\x41" "1" "\101"); int x;
