int f(void){return _Generic(0,int:1,default:2,default:3);}
