char *f(int x){return _Generic(x,int:"a" "b",default:"c" "d");}
