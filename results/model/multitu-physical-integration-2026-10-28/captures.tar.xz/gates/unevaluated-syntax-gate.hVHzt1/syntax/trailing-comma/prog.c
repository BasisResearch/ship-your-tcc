int f(void){return _Generic(0,int:1,);}
