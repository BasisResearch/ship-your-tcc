int f(void){_Static_assert(1,"outer"); { _Static_assert(sizeof(int)==4,"inner"); } return 0;}
