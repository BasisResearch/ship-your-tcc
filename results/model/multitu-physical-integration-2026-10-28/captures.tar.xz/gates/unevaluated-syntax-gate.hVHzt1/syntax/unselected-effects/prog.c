int f(void){int n=0; return _Generic(n,int:7,default:++n)+n;}
