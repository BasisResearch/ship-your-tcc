# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
static
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
       int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
           mine
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
               (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                    x
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                     )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                      {
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                       return
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                              x
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                               +
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                10
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                  ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                   }
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
static
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
       int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
           mine
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
               (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                   )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                    ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
    main
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
        (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
         void
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
             )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
              {
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
               int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                   (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                    *
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                     p
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                      )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                       (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                        int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                           )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                            =
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                             mine
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                 ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                   int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                       (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                        *
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                         q
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                          )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                           (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                            int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                               )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                =
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                 &
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                  mine
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                      ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                        return
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                               mine
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                   (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                    7
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                     )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                      !=
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                        17
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                           ||
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                              p
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                               (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                                7
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                                 )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                                  !=
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                                    17
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                                       ||
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                                          (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                                           *
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                                            q
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                                             )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                                              (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                                               7
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                                                )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                                                 !=
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                                                   17
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                                                      ||
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                                                         p
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                                                          !=
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                                                            q
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                                                              ||
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                                                                 p
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                                                                  ==
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                                                                    0
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                                                                     ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                                                                                                                      }
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
static
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
       int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
           mine
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
               (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                   )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/results/csem/function-redeclaration/after/sources/internal-dpmp.c"
                    ;

