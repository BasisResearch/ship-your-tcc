# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/invalid-return.c"
int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/invalid-return.c"
    mine
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/invalid-return.c"
        (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/invalid-return.c"
         int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/invalid-return.c"
            )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/invalid-return.c"
             ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/invalid-return.c"
              void
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/invalid-return.c"
                   mine
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/invalid-return.c"
                       (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/invalid-return.c"
                        int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/invalid-return.c"
                           )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/invalid-return.c"
                            ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/invalid-return.c"
                             int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/invalid-return.c"
                                 main
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/invalid-return.c"
                                     (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/invalid-return.c"
                                      void
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/invalid-return.c"
                                          )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/invalid-return.c"
                                           {
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/invalid-return.c"
                                            return
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/invalid-return.c"
                                                   0
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/invalid-return.c"
                                                    ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/invalid-return.c"
                                                     }

