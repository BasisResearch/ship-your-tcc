# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
static
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
       int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
           mine
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
               (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                   )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                    ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
static
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
       int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
           mine
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
               (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                   )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                    ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
static
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
       int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
           mine
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
               (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                   )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                    ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
static
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
       int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
           mine
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
               (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                    x
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                     )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                      {
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                       return
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                              x
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                               +
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                10
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                  ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                   }
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
int
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
    main
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
        (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
         void
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
             )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
              {
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
               int
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                   (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                    *
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                     p
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                      )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                       (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                        int
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                           )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                            =
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                             mine
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                 ;
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                   int
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                       (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                        *
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                         q
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                          )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                           (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                            int
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                               )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                =
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                 &
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                  mine
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                      ;
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                        return
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                               mine
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                   (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                    7
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                     )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                      !=
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                        17
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                           ||
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                              p
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                               (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                                7
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                                 )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                                  !=
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                                    17
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                                       ||
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                                          (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                                           *
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                                            q
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                                             )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                                              (
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                                               7
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                                                )
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                                                 !=
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                                                   17
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                                                      ||
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                                                         p
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                                                          !=
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                                                            q
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                                                              ||
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                                                                 p
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                                                                  ==
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                                                                    0
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                                                                     ;
# 5 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/internal-pprdm.c"
                                                                                                                      }

