# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
static
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
       int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
           mine
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
               (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                   )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                    ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
static
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
       int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
           mine
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
               (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                    x
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                     )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                      {
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                       return
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                              x
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                               +
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                10
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                  ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                   }
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
static
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
       int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
           mine
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
               (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                   )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                    ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
    main
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
        (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
         void
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
             )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
              {
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
               int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                   (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                    *
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                     p
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                      )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                       (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                        int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                           )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                            =
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                             mine
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                 ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                  {
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                   int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                       mine
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                           =
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                            29
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                              ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                               if
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                                 (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                                  mine
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                                      !=
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                                        29
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                                          )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                                           return
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                                                  1
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                                                   ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                                                    }
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                                                     return
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                                                            p
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                                                             !=
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                                                               mine
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                                                                    ||
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                                                                       p
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                                                                        (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                                                                         7
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                                                                          )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                                                                           !=
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                                                                             17
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                                                                               ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/shadow-object.c"
                                                                                                }

