# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
    mine
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
        (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
         int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
             x
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
              )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
               {
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                return
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                       x
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                        +
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                         10
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                           ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                            }
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
    mine
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
        (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
         int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
            )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
             ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
    main
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
        (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
         void
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
             )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
              {
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
               int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                   (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                    *
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                     p
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                      )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                       (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                        int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                           )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                            =
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                             mine
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                 ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                   int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                       (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                        *
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                         q
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                          )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                           (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                            int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                               )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                =
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                 &
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                  mine
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                      ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                        return
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                               mine
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                   (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                    7
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                     )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                      !=
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                        17
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                           ||
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                              p
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                               (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                                7
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                                 )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                                  !=
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                                    17
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                                       ||
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                                          (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                                           *
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                                            q
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                                             )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                                              (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                                               7
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                                                )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                                                 !=
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                                                   17
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                                                      ||
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                                                         p
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                                                          !=
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                                                            q
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                                                              ||
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                                                                 p
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                                                                  ==
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                                                                    0
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                                                                     ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
                                                                                                                      }
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
    mine
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
        (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
         int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
            )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/external-dpmp.c"
             ;

