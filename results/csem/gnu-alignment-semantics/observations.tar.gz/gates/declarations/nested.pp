# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
static
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
       int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
           mine
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
               (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                   )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                    ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
static
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
       int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
           mine
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
               (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                    x
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                     )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                      {
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                       return
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                              x
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                               +
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                10
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                  ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                   }
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
static
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
       int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
           mine
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
               (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                   )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                    ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
    main
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
        (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
         void
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
             )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
              {
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
               int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                   (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                    *
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                     p
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                      )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                       (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                        int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                           )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                            =
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                             mine
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                 ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                  {
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                   extern
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                          int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                              mine
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                  (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                   int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                      )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                       ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                        int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                            (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                             *
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                              q
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                               )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                 int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                    )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                     =
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                      mine
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                          ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                           {
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                            extern
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                   int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                       mine
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                           (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                            int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                               )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                 if
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                   (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                    q
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                     !=
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                       mine
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                            ||
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                               p
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                !=
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                  mine
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                      )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                       return
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                              1
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                               ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                                }
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                                 if
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                                   (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                                    q
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                                     (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                                      6
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                                       )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                                        !=
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                                          16
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                                            )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                                             return
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                                                    2
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                                                     ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                                                      }
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                                                       return
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                                                              p
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                                                               (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                                                                7
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                                                                 )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                                                                  !=
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                                                                    17
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                                                                      ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/function-redeclaration-gate.4xNQ3g/run/sources/nested.c"
                                                                                                                                                                       }

