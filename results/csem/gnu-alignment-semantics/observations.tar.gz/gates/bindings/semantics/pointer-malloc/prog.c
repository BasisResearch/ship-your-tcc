void *malloc(unsigned long);void free(void *);int main(void){void *(*p)(unsigned long)=&__builtin_malloc;void *(*q)(unsigned long)=malloc;void *x=p(8);int r=p!=q || x==0;free(x);return r;}
