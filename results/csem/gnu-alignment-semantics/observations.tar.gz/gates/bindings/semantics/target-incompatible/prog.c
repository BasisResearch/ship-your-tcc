int malloc(int);int main(void){return 0;}
