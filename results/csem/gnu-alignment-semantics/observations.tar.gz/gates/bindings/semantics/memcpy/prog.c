int main(void){char a[4]={1,2,3,0};char b[4];return __builtin_memcpy(b,a,4)!=b || b[2]!=3;}
