int main(void){char a[4];__builtin_strcpy(a,"a");return 0;}
