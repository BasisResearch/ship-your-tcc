int main(void){__builtin_strcmp("a","a");return 0;}
