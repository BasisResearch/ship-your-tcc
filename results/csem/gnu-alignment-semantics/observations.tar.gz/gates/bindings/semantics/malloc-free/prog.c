int main(void){int *p=__builtin_malloc(sizeof(int));*p=37;int r=*p!=37;__builtin_free(p);return r;}
