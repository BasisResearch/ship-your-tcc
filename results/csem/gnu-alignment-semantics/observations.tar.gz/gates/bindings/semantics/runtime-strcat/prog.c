int main(void){char a[4]={65,0};__builtin_strcat(a,"b");return 0;}
