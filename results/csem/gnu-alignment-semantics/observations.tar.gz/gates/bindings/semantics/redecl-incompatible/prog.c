int __builtin_malloc(int);int main(void){return 0;}
