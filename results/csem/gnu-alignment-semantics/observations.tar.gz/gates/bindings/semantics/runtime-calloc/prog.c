int main(void){__builtin_calloc(2,4);return 0;}
