int main(void){__builtin_strrchr("a",65);return 0;}
