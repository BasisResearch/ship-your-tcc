#include <tccdefs.h>
int main(void){return 0;}
