int main(void){char a[4]={1,2,3,0};__builtin_memmove(a+1,a,2);__builtin_memset(a,7,1);return a[0]!=7 || a[1]!=1 || a[2]!=2;}
