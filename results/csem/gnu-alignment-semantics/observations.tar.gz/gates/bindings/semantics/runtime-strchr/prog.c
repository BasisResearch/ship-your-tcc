int main(void){__builtin_strchr("a",65);return 0;}
