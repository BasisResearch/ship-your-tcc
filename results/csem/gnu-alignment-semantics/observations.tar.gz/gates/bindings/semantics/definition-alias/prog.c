unsigned long __builtin_strlen(const char *s){unsigned long n=0;while(s[n])n++;return n;}unsigned long strlen(const char *);int main(void){return __builtin_strlen!=strlen || strlen("abc")!=3;}
