int main(void){char a[4]={65,0};__builtin_strncat(a,"b",1);return 0;}
