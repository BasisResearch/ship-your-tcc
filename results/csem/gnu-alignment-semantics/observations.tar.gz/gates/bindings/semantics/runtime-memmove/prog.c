int main(void){char a[2]={1,0};__builtin_memmove(a+1,a,1);return 0;}
