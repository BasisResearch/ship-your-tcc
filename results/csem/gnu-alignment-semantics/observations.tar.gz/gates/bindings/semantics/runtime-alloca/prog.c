int main(void){char *p=__builtin_alloca(4);p[0]=37;return p[0]!=37;}
