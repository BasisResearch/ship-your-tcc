void *__builtin_memcpy(void *,const void *,unsigned long) __asm__("memcpy");int main(void){return 0;}
