int main(void){__builtin_strncmp("a","a",1);return 0;}
