int main(void){return __builtin_strlen("abc")!=3;}
