int main(void){char a[2];__builtin_memset(a,7,2);return 0;}
