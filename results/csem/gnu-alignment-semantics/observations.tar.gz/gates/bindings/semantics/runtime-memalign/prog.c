int main(void){__builtin_memalign(16,32);return 0;}
