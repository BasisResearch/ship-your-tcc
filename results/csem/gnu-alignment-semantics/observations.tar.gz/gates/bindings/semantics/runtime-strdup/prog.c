int main(void){__builtin_strdup("a");return 0;}
