#line 283 "/lib/tcc/include/tccdefs.h"
void *mine(void *,const void *,unsigned long) __asm__("memcpy");int main(void){return 0;}
