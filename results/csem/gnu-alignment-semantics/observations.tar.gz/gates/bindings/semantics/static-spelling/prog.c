static void *memcpy(void *d,const void *s,unsigned long n){return d;}int main(void){char a[2]={37,0},b[2];return memcpy==__builtin_memcpy || __builtin_memcpy(b,a,2)!=b || b[0]!=37;}
