int main(void){char a[2]={3,4};char b[2]={3,4};return __builtin_memcmp(a,b,2)!=0;}
