int main(void){char a[4];__builtin_strncpy(a,"a",2);return 0;}
