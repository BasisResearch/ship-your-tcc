unsigned long strlen(const char *s){return 1;}unsigned long __builtin_strlen(const char *s){return 2;}int main(void){return 0;}
