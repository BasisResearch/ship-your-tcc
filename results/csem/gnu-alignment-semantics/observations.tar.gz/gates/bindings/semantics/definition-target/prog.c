unsigned long strlen(const char *s){unsigned long n=0;while(s[n])n++;return n;}int main(void){unsigned long (*p)(const char *)=__builtin_strlen;return p!=strlen || p("abc")!=3;}
