int main(void){char *p=__builtin_malloc(2);p[0]=37;p=__builtin_realloc(p,4);int r=p[0]!=37;__builtin_free(p);return r;}
