int main(void){return __builtin_strlen("abc")!=3;}unsigned long strlen(const char *s){unsigned long n=0;while(s[n])n++;return n;}
