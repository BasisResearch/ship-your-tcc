typedef int A[2] __attribute__((aligned(32))); A a; int main(void){return __alignof__(a);}
