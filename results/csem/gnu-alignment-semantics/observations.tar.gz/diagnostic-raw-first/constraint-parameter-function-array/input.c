typedef int F(void); int f(F a[1]); int main(void){return 0;}
