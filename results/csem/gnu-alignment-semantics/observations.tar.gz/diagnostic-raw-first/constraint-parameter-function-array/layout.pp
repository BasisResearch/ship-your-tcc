# 1 "build/alignsem-raw-first/constraint-parameter-function-array/input.c"
typedef
# 1 "build/alignsem-raw-first/constraint-parameter-function-array/input.c"
        int
# 1 "build/alignsem-raw-first/constraint-parameter-function-array/input.c"
            F
# 1 "build/alignsem-raw-first/constraint-parameter-function-array/input.c"
             (
# 1 "build/alignsem-raw-first/constraint-parameter-function-array/input.c"
              void
# 1 "build/alignsem-raw-first/constraint-parameter-function-array/input.c"
                  )
# 1 "build/alignsem-raw-first/constraint-parameter-function-array/input.c"
                   ;
# 1 "build/alignsem-raw-first/constraint-parameter-function-array/input.c"
                     int
# 1 "build/alignsem-raw-first/constraint-parameter-function-array/input.c"
                         f
# 1 "build/alignsem-raw-first/constraint-parameter-function-array/input.c"
                          (
# 1 "build/alignsem-raw-first/constraint-parameter-function-array/input.c"
                           F
# 1 "build/alignsem-raw-first/constraint-parameter-function-array/input.c"
                             a
# 1 "build/alignsem-raw-first/constraint-parameter-function-array/input.c"
                              [
# 1 "build/alignsem-raw-first/constraint-parameter-function-array/input.c"
                               1
# 1 "build/alignsem-raw-first/constraint-parameter-function-array/input.c"
                                ]
# 1 "build/alignsem-raw-first/constraint-parameter-function-array/input.c"
                                 )
# 1 "build/alignsem-raw-first/constraint-parameter-function-array/input.c"
                                  ;
# 1 "build/alignsem-raw-first/constraint-parameter-function-array/input.c"
                                    int
# 1 "build/alignsem-raw-first/constraint-parameter-function-array/input.c"
                                        main
# 1 "build/alignsem-raw-first/constraint-parameter-function-array/input.c"
                                            (
# 1 "build/alignsem-raw-first/constraint-parameter-function-array/input.c"
                                             void
# 1 "build/alignsem-raw-first/constraint-parameter-function-array/input.c"
                                                 )
# 1 "build/alignsem-raw-first/constraint-parameter-function-array/input.c"
                                                  {
# 1 "build/alignsem-raw-first/constraint-parameter-function-array/input.c"
                                                   return
# 1 "build/alignsem-raw-first/constraint-parameter-function-array/input.c"
                                                          0
# 1 "build/alignsem-raw-first/constraint-parameter-function-array/input.c"
                                                           ;
# 1 "build/alignsem-raw-first/constraint-parameter-function-array/input.c"
                                                            }

