# 1 "build/alignsem-raw-first/address-type/input.c"
typedef
# 1 "build/alignsem-raw-first/address-type/input.c"
        int
# 1 "build/alignsem-raw-first/address-type/input.c"
            Up
# 1 "build/alignsem-raw-first/address-type/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/address-type/input.c"
                            (
# 1 "build/alignsem-raw-first/address-type/input.c"
                             (
# 1 "build/alignsem-raw-first/address-type/input.c"
                              aligned
# 1 "build/alignsem-raw-first/address-type/input.c"
                                     (
# 1 "build/alignsem-raw-first/address-type/input.c"
                                      16
# 1 "build/alignsem-raw-first/address-type/input.c"
                                        )
# 1 "build/alignsem-raw-first/address-type/input.c"
                                         )
# 1 "build/alignsem-raw-first/address-type/input.c"
                                          )
# 1 "build/alignsem-raw-first/address-type/input.c"
                                           ;
# 2 "build/alignsem-raw-first/address-type/input.c"
typedef
# 2 "build/alignsem-raw-first/address-type/input.c"
        int
# 2 "build/alignsem-raw-first/address-type/input.c"
            Down
# 2 "build/alignsem-raw-first/address-type/input.c"
                 __attribute__
# 2 "build/alignsem-raw-first/address-type/input.c"
                              (
# 2 "build/alignsem-raw-first/address-type/input.c"
                               (
# 2 "build/alignsem-raw-first/address-type/input.c"
                                aligned
# 2 "build/alignsem-raw-first/address-type/input.c"
                                       (
# 2 "build/alignsem-raw-first/address-type/input.c"
                                        1
# 2 "build/alignsem-raw-first/address-type/input.c"
                                         )
# 2 "build/alignsem-raw-first/address-type/input.c"
                                          )
# 2 "build/alignsem-raw-first/address-type/input.c"
                                           )
# 2 "build/alignsem-raw-first/address-type/input.c"
                                            ;
# 3 "build/alignsem-raw-first/address-type/input.c"
typedef
# 3 "build/alignsem-raw-first/address-type/input.c"
        Up
# 3 "build/alignsem-raw-first/address-type/input.c"
           Again
# 3 "build/alignsem-raw-first/address-type/input.c"
                ;
# 4 "build/alignsem-raw-first/address-type/input.c"
Up
# 4 "build/alignsem-raw-first/address-type/input.c"
   x
# 4 "build/alignsem-raw-first/address-type/input.c"
    ;
# 5 "build/alignsem-raw-first/address-type/input.c"
int
# 5 "build/alignsem-raw-first/address-type/input.c"
    main
# 5 "build/alignsem-raw-first/address-type/input.c"
        (
# 5 "build/alignsem-raw-first/address-type/input.c"
         void
# 5 "build/alignsem-raw-first/address-type/input.c"
             )
# 5 "build/alignsem-raw-first/address-type/input.c"
              {
# 5 "build/alignsem-raw-first/address-type/input.c"
               return
# 5 "build/alignsem-raw-first/address-type/input.c"
                      (
# 5 "build/alignsem-raw-first/address-type/input.c"
                       _Alignof
# 5 "build/alignsem-raw-first/address-type/input.c"
                               (
# 5 "build/alignsem-raw-first/address-type/input.c"
                                __typeof__
# 5 "build/alignsem-raw-first/address-type/input.c"
                                          (
# 5 "build/alignsem-raw-first/address-type/input.c"
                                           &
# 5 "build/alignsem-raw-first/address-type/input.c"
                                            x
# 5 "build/alignsem-raw-first/address-type/input.c"
                                             )
# 5 "build/alignsem-raw-first/address-type/input.c"
                                              )
# 5 "build/alignsem-raw-first/address-type/input.c"
                                               !=
# 5 "build/alignsem-raw-first/address-type/input.c"
                                                 sizeof
# 5 "build/alignsem-raw-first/address-type/input.c"
                                                       (
# 5 "build/alignsem-raw-first/address-type/input.c"
                                                        void
# 5 "build/alignsem-raw-first/address-type/input.c"
                                                            *
# 5 "build/alignsem-raw-first/address-type/input.c"
                                                             )
# 5 "build/alignsem-raw-first/address-type/input.c"
                                                               ||
# 5 "build/alignsem-raw-first/address-type/input.c"
                                                                  _Alignof
# 5 "build/alignsem-raw-first/address-type/input.c"
                                                                          (
# 5 "build/alignsem-raw-first/address-type/input.c"
                                                                           __typeof__
# 5 "build/alignsem-raw-first/address-type/input.c"
                                                                                     (
# 5 "build/alignsem-raw-first/address-type/input.c"
                                                                                      (
# 5 "build/alignsem-raw-first/address-type/input.c"
                                                                                       Up
# 5 "build/alignsem-raw-first/address-type/input.c"
                                                                                         )
# 5 "build/alignsem-raw-first/address-type/input.c"
                                                                                          1
# 5 "build/alignsem-raw-first/address-type/input.c"
                                                                                           )
# 5 "build/alignsem-raw-first/address-type/input.c"
                                                                                            )
# 5 "build/alignsem-raw-first/address-type/input.c"
                                                                                             !=
# 5 "build/alignsem-raw-first/address-type/input.c"
                                                                                               4
# 5 "build/alignsem-raw-first/address-type/input.c"
                                                                                                )
# 5 "build/alignsem-raw-first/address-type/input.c"
                                                                                                 ;
# 5 "build/alignsem-raw-first/address-type/input.c"
                                                                                                  }

