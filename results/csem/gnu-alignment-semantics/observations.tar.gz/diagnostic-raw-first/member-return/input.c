typedef int Up __attribute__((aligned(16))); struct S{Up x;}; struct S f(void){struct S s={0};return s;} int main(void){return _Alignof(__typeof__(f().x))!=16;}
