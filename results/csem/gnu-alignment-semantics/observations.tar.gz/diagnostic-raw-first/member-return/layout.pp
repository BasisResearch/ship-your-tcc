# 1 "build/alignsem-raw-first/member-return/input.c"
typedef
# 1 "build/alignsem-raw-first/member-return/input.c"
        int
# 1 "build/alignsem-raw-first/member-return/input.c"
            Up
# 1 "build/alignsem-raw-first/member-return/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/member-return/input.c"
                            (
# 1 "build/alignsem-raw-first/member-return/input.c"
                             (
# 1 "build/alignsem-raw-first/member-return/input.c"
                              aligned
# 1 "build/alignsem-raw-first/member-return/input.c"
                                     (
# 1 "build/alignsem-raw-first/member-return/input.c"
                                      16
# 1 "build/alignsem-raw-first/member-return/input.c"
                                        )
# 1 "build/alignsem-raw-first/member-return/input.c"
                                         )
# 1 "build/alignsem-raw-first/member-return/input.c"
                                          )
# 1 "build/alignsem-raw-first/member-return/input.c"
                                           ;
# 1 "build/alignsem-raw-first/member-return/input.c"
                                             struct
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                    S
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                     {
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                      Up
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                         x
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                          ;
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                           }
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                            ;
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                              struct
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                     S
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                       f
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                        (
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                         void
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                             )
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                              {
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                               struct
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                      S
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                        s
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                         =
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                          {
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                           0
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                            }
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                             ;
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                              return
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                                     s
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                                      ;
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                                       }
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                                         int
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                                             main
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                                                 (
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                                                  void
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                                                      )
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                                                       {
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                                                        return
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                                                               _Alignof
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                                                                       (
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                                                                        __typeof__
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                                                                                  (
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                                                                                   f
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                                                                                    (
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                                                                                     )
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                                                                                      .
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                                                                                       x
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                                                                                        )
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                                                                                         )
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                                                                                          !=
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                                                                                            16
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                                                                                              ;
# 1 "build/alignsem-raw-first/member-return/input.c"
                                                                                                                                                               }

