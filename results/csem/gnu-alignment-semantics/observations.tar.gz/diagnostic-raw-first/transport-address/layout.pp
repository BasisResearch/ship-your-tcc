# 1 "build/alignsem-raw-first/transport-address/input.c"
typedef
# 1 "build/alignsem-raw-first/transport-address/input.c"
        int
# 1 "build/alignsem-raw-first/transport-address/input.c"
            Up
# 1 "build/alignsem-raw-first/transport-address/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/transport-address/input.c"
                            (
# 1 "build/alignsem-raw-first/transport-address/input.c"
                             (
# 1 "build/alignsem-raw-first/transport-address/input.c"
                              aligned
# 1 "build/alignsem-raw-first/transport-address/input.c"
                                     (
# 1 "build/alignsem-raw-first/transport-address/input.c"
                                      16
# 1 "build/alignsem-raw-first/transport-address/input.c"
                                        )
# 1 "build/alignsem-raw-first/transport-address/input.c"
                                         )
# 1 "build/alignsem-raw-first/transport-address/input.c"
                                          )
# 1 "build/alignsem-raw-first/transport-address/input.c"
                                           ;
# 1 "build/alignsem-raw-first/transport-address/input.c"
                                             Up
# 1 "build/alignsem-raw-first/transport-address/input.c"
                                                x
# 1 "build/alignsem-raw-first/transport-address/input.c"
                                                 ;
# 1 "build/alignsem-raw-first/transport-address/input.c"
                                                   Up
# 1 "build/alignsem-raw-first/transport-address/input.c"
                                                      f
# 1 "build/alignsem-raw-first/transport-address/input.c"
                                                       (
# 1 "build/alignsem-raw-first/transport-address/input.c"
                                                        void
# 1 "build/alignsem-raw-first/transport-address/input.c"
                                                            )
# 1 "build/alignsem-raw-first/transport-address/input.c"
                                                             {
# 1 "build/alignsem-raw-first/transport-address/input.c"
                                                              return
# 1 "build/alignsem-raw-first/transport-address/input.c"
                                                                     0
# 1 "build/alignsem-raw-first/transport-address/input.c"
                                                                      ;
# 1 "build/alignsem-raw-first/transport-address/input.c"
                                                                       }
# 2 "build/alignsem-raw-first/transport-address/input.c"
int
# 2 "build/alignsem-raw-first/transport-address/input.c"
    main
# 2 "build/alignsem-raw-first/transport-address/input.c"
        (
# 2 "build/alignsem-raw-first/transport-address/input.c"
         void
# 2 "build/alignsem-raw-first/transport-address/input.c"
             )
# 2 "build/alignsem-raw-first/transport-address/input.c"
              {
# 2 "build/alignsem-raw-first/transport-address/input.c"
               return
# 2 "build/alignsem-raw-first/transport-address/input.c"
                      _Alignof
# 2 "build/alignsem-raw-first/transport-address/input.c"
                              (
# 2 "build/alignsem-raw-first/transport-address/input.c"
                               __typeof__
# 2 "build/alignsem-raw-first/transport-address/input.c"
                                         (
# 2 "build/alignsem-raw-first/transport-address/input.c"
                                          &
# 2 "build/alignsem-raw-first/transport-address/input.c"
                                           x
# 2 "build/alignsem-raw-first/transport-address/input.c"
                                            )
# 2 "build/alignsem-raw-first/transport-address/input.c"
                                             )
# 2 "build/alignsem-raw-first/transport-address/input.c"
                                              !=
# 2 "build/alignsem-raw-first/transport-address/input.c"
                                                8
# 2 "build/alignsem-raw-first/transport-address/input.c"
                                                 ;
# 2 "build/alignsem-raw-first/transport-address/input.c"
                                                  }

