# 1 "build/alignsem-raw-first/queries/input.c"
typedef
# 1 "build/alignsem-raw-first/queries/input.c"
        int
# 1 "build/alignsem-raw-first/queries/input.c"
            Up
# 1 "build/alignsem-raw-first/queries/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/queries/input.c"
                            (
# 1 "build/alignsem-raw-first/queries/input.c"
                             (
# 1 "build/alignsem-raw-first/queries/input.c"
                              aligned
# 1 "build/alignsem-raw-first/queries/input.c"
                                     (
# 1 "build/alignsem-raw-first/queries/input.c"
                                      16
# 1 "build/alignsem-raw-first/queries/input.c"
                                        )
# 1 "build/alignsem-raw-first/queries/input.c"
                                         )
# 1 "build/alignsem-raw-first/queries/input.c"
                                          )
# 1 "build/alignsem-raw-first/queries/input.c"
                                           ;
# 2 "build/alignsem-raw-first/queries/input.c"
typedef
# 2 "build/alignsem-raw-first/queries/input.c"
        int
# 2 "build/alignsem-raw-first/queries/input.c"
            Down
# 2 "build/alignsem-raw-first/queries/input.c"
                 __attribute__
# 2 "build/alignsem-raw-first/queries/input.c"
                              (
# 2 "build/alignsem-raw-first/queries/input.c"
                               (
# 2 "build/alignsem-raw-first/queries/input.c"
                                aligned
# 2 "build/alignsem-raw-first/queries/input.c"
                                       (
# 2 "build/alignsem-raw-first/queries/input.c"
                                        1
# 2 "build/alignsem-raw-first/queries/input.c"
                                         )
# 2 "build/alignsem-raw-first/queries/input.c"
                                          )
# 2 "build/alignsem-raw-first/queries/input.c"
                                           )
# 2 "build/alignsem-raw-first/queries/input.c"
                                            ;
# 3 "build/alignsem-raw-first/queries/input.c"
typedef
# 3 "build/alignsem-raw-first/queries/input.c"
        Up
# 3 "build/alignsem-raw-first/queries/input.c"
           Again
# 3 "build/alignsem-raw-first/queries/input.c"
                ;
# 4 "build/alignsem-raw-first/queries/input.c"
int
# 4 "build/alignsem-raw-first/queries/input.c"
    main
# 4 "build/alignsem-raw-first/queries/input.c"
        (
# 4 "build/alignsem-raw-first/queries/input.c"
         void
# 4 "build/alignsem-raw-first/queries/input.c"
             )
# 4 "build/alignsem-raw-first/queries/input.c"
              {
# 4 "build/alignsem-raw-first/queries/input.c"
               return
# 4 "build/alignsem-raw-first/queries/input.c"
                      (
# 4 "build/alignsem-raw-first/queries/input.c"
                       _Alignof
# 4 "build/alignsem-raw-first/queries/input.c"
                               (
# 4 "build/alignsem-raw-first/queries/input.c"
                                Up
# 4 "build/alignsem-raw-first/queries/input.c"
                                  )
# 4 "build/alignsem-raw-first/queries/input.c"
                                   !=
# 4 "build/alignsem-raw-first/queries/input.c"
                                     16
# 4 "build/alignsem-raw-first/queries/input.c"
                                        ||
# 4 "build/alignsem-raw-first/queries/input.c"
                                           __alignof__
# 4 "build/alignsem-raw-first/queries/input.c"
                                                      (
# 4 "build/alignsem-raw-first/queries/input.c"
                                                       Down
# 4 "build/alignsem-raw-first/queries/input.c"
                                                           )
# 4 "build/alignsem-raw-first/queries/input.c"
                                                            !=
# 4 "build/alignsem-raw-first/queries/input.c"
                                                              1
# 4 "build/alignsem-raw-first/queries/input.c"
                                                                ||
# 4 "build/alignsem-raw-first/queries/input.c"
                                                                   __alignof
# 4 "build/alignsem-raw-first/queries/input.c"
                                                                            (
# 4 "build/alignsem-raw-first/queries/input.c"
                                                                             Again
# 4 "build/alignsem-raw-first/queries/input.c"
                                                                                  )
# 4 "build/alignsem-raw-first/queries/input.c"
                                                                                   !=
# 4 "build/alignsem-raw-first/queries/input.c"
                                                                                     16
# 4 "build/alignsem-raw-first/queries/input.c"
                                                                                        ||
# 4 "build/alignsem-raw-first/queries/input.c"
                                                                                           sizeof
# 4 "build/alignsem-raw-first/queries/input.c"
                                                                                                 (
# 4 "build/alignsem-raw-first/queries/input.c"
                                                                                                  Again
# 4 "build/alignsem-raw-first/queries/input.c"
                                                                                                       )
# 4 "build/alignsem-raw-first/queries/input.c"
                                                                                                        !=
# 4 "build/alignsem-raw-first/queries/input.c"
                                                                                                          4
# 4 "build/alignsem-raw-first/queries/input.c"
                                                                                                           )
# 4 "build/alignsem-raw-first/queries/input.c"
                                                                                                            ;
# 4 "build/alignsem-raw-first/queries/input.c"
                                                                                                             }

