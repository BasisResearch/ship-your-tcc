typedef int F(void); typedef F (*P)[1]; int main(void){return 0;}
