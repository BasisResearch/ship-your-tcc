# 1 "build/alignsem-raw-first/array-function-array-typedef/input.c"
typedef
# 1 "build/alignsem-raw-first/array-function-array-typedef/input.c"
        int
# 1 "build/alignsem-raw-first/array-function-array-typedef/input.c"
            F
# 1 "build/alignsem-raw-first/array-function-array-typedef/input.c"
             (
# 1 "build/alignsem-raw-first/array-function-array-typedef/input.c"
              void
# 1 "build/alignsem-raw-first/array-function-array-typedef/input.c"
                  )
# 1 "build/alignsem-raw-first/array-function-array-typedef/input.c"
                   ;
# 1 "build/alignsem-raw-first/array-function-array-typedef/input.c"
                     typedef
# 1 "build/alignsem-raw-first/array-function-array-typedef/input.c"
                             F
# 1 "build/alignsem-raw-first/array-function-array-typedef/input.c"
                               Bad
# 1 "build/alignsem-raw-first/array-function-array-typedef/input.c"
                                  [
# 1 "build/alignsem-raw-first/array-function-array-typedef/input.c"
                                   1
# 1 "build/alignsem-raw-first/array-function-array-typedef/input.c"
                                    ]
# 1 "build/alignsem-raw-first/array-function-array-typedef/input.c"
                                     ;
# 1 "build/alignsem-raw-first/array-function-array-typedef/input.c"
                                       int
# 1 "build/alignsem-raw-first/array-function-array-typedef/input.c"
                                           main
# 1 "build/alignsem-raw-first/array-function-array-typedef/input.c"
                                               (
# 1 "build/alignsem-raw-first/array-function-array-typedef/input.c"
                                                void
# 1 "build/alignsem-raw-first/array-function-array-typedef/input.c"
                                                    )
# 1 "build/alignsem-raw-first/array-function-array-typedef/input.c"
                                                     {
# 1 "build/alignsem-raw-first/array-function-array-typedef/input.c"
                                                      return
# 1 "build/alignsem-raw-first/array-function-array-typedef/input.c"
                                                             0
# 1 "build/alignsem-raw-first/array-function-array-typedef/input.c"
                                                              ;
# 1 "build/alignsem-raw-first/array-function-array-typedef/input.c"
                                                               }

