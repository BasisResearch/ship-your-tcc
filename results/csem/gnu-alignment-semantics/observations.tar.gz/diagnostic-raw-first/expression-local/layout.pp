# 1 "build/alignsem-raw-first/expression-local/input.c"
typedef
# 1 "build/alignsem-raw-first/expression-local/input.c"
        int
# 1 "build/alignsem-raw-first/expression-local/input.c"
            Up
# 1 "build/alignsem-raw-first/expression-local/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/expression-local/input.c"
                            (
# 1 "build/alignsem-raw-first/expression-local/input.c"
                             (
# 1 "build/alignsem-raw-first/expression-local/input.c"
                              aligned
# 1 "build/alignsem-raw-first/expression-local/input.c"
                                     (
# 1 "build/alignsem-raw-first/expression-local/input.c"
                                      16
# 1 "build/alignsem-raw-first/expression-local/input.c"
                                        )
# 1 "build/alignsem-raw-first/expression-local/input.c"
                                         )
# 1 "build/alignsem-raw-first/expression-local/input.c"
                                          )
# 1 "build/alignsem-raw-first/expression-local/input.c"
                                           ;
# 2 "build/alignsem-raw-first/expression-local/input.c"
typedef
# 2 "build/alignsem-raw-first/expression-local/input.c"
        int
# 2 "build/alignsem-raw-first/expression-local/input.c"
            Down
# 2 "build/alignsem-raw-first/expression-local/input.c"
                 __attribute__
# 2 "build/alignsem-raw-first/expression-local/input.c"
                              (
# 2 "build/alignsem-raw-first/expression-local/input.c"
                               (
# 2 "build/alignsem-raw-first/expression-local/input.c"
                                aligned
# 2 "build/alignsem-raw-first/expression-local/input.c"
                                       (
# 2 "build/alignsem-raw-first/expression-local/input.c"
                                        1
# 2 "build/alignsem-raw-first/expression-local/input.c"
                                         )
# 2 "build/alignsem-raw-first/expression-local/input.c"
                                          )
# 2 "build/alignsem-raw-first/expression-local/input.c"
                                           )
# 2 "build/alignsem-raw-first/expression-local/input.c"
                                            ;
# 3 "build/alignsem-raw-first/expression-local/input.c"
typedef
# 3 "build/alignsem-raw-first/expression-local/input.c"
        Up
# 3 "build/alignsem-raw-first/expression-local/input.c"
           Again
# 3 "build/alignsem-raw-first/expression-local/input.c"
                ;
# 4 "build/alignsem-raw-first/expression-local/input.c"
int
# 4 "build/alignsem-raw-first/expression-local/input.c"
    main
# 4 "build/alignsem-raw-first/expression-local/input.c"
        (
# 4 "build/alignsem-raw-first/expression-local/input.c"
         void
# 4 "build/alignsem-raw-first/expression-local/input.c"
             )
# 4 "build/alignsem-raw-first/expression-local/input.c"
              {
# 4 "build/alignsem-raw-first/expression-local/input.c"
               return
# 4 "build/alignsem-raw-first/expression-local/input.c"
                      (
# 4 "build/alignsem-raw-first/expression-local/input.c"
                       (
# 4 "build/alignsem-raw-first/expression-local/input.c"
                        {
# 4 "build/alignsem-raw-first/expression-local/input.c"
                         int
# 4 "build/alignsem-raw-first/expression-local/input.c"
                             obj
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                 __attribute__
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                              (
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                               (
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                aligned
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                       (
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                        32
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                          )
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                           )
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                            )
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                             ;
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                               __alignof__
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                          (
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                           obj
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                              )
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                               !=
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                 32
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                    ||
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                       __alignof__
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                  (
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                   &
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                    obj
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                       )
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                        !=
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                          sizeof
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                (
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                 void
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                     *
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                      )
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                        ||
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                           __alignof__
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                                      (
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                                       (
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                                        int
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                                           )
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                                            obj
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                                               )
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                                                !=
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                                                  4
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                                                    ||
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                                                       _Alignof
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                                                               (
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                                                                __typeof__
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                                                                          (
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                                                                           obj
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                                                                              )
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                                                                               )
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                                                                                !=
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                                                                                  4
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                                                                                   ;
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                                                                                    }
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                                                                                     )
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                                                                                      )
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                                                                                       ;
# 4 "build/alignsem-raw-first/expression-local/input.c"
                                                                                                                                                                                        }

