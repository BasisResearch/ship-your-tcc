# 1 "build/alignsem-raw-first/pointers/input.c"
typedef
# 1 "build/alignsem-raw-first/pointers/input.c"
        int
# 1 "build/alignsem-raw-first/pointers/input.c"
            Up
# 1 "build/alignsem-raw-first/pointers/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/pointers/input.c"
                            (
# 1 "build/alignsem-raw-first/pointers/input.c"
                             (
# 1 "build/alignsem-raw-first/pointers/input.c"
                              aligned
# 1 "build/alignsem-raw-first/pointers/input.c"
                                     (
# 1 "build/alignsem-raw-first/pointers/input.c"
                                      16
# 1 "build/alignsem-raw-first/pointers/input.c"
                                        )
# 1 "build/alignsem-raw-first/pointers/input.c"
                                         )
# 1 "build/alignsem-raw-first/pointers/input.c"
                                          )
# 1 "build/alignsem-raw-first/pointers/input.c"
                                           ;
# 2 "build/alignsem-raw-first/pointers/input.c"
typedef
# 2 "build/alignsem-raw-first/pointers/input.c"
        int
# 2 "build/alignsem-raw-first/pointers/input.c"
            Down
# 2 "build/alignsem-raw-first/pointers/input.c"
                 __attribute__
# 2 "build/alignsem-raw-first/pointers/input.c"
                              (
# 2 "build/alignsem-raw-first/pointers/input.c"
                               (
# 2 "build/alignsem-raw-first/pointers/input.c"
                                aligned
# 2 "build/alignsem-raw-first/pointers/input.c"
                                       (
# 2 "build/alignsem-raw-first/pointers/input.c"
                                        1
# 2 "build/alignsem-raw-first/pointers/input.c"
                                         )
# 2 "build/alignsem-raw-first/pointers/input.c"
                                          )
# 2 "build/alignsem-raw-first/pointers/input.c"
                                           )
# 2 "build/alignsem-raw-first/pointers/input.c"
                                            ;
# 3 "build/alignsem-raw-first/pointers/input.c"
typedef
# 3 "build/alignsem-raw-first/pointers/input.c"
        Up
# 3 "build/alignsem-raw-first/pointers/input.c"
           Again
# 3 "build/alignsem-raw-first/pointers/input.c"
                ;
# 4 "build/alignsem-raw-first/pointers/input.c"
typedef
# 4 "build/alignsem-raw-first/pointers/input.c"
        Up
# 4 "build/alignsem-raw-first/pointers/input.c"
           *
# 4 "build/alignsem-raw-first/pointers/input.c"
            P
# 4 "build/alignsem-raw-first/pointers/input.c"
             ;
# 4 "build/alignsem-raw-first/pointers/input.c"
               typedef
# 4 "build/alignsem-raw-first/pointers/input.c"
                       Down
# 4 "build/alignsem-raw-first/pointers/input.c"
                            *
# 4 "build/alignsem-raw-first/pointers/input.c"
                             Q
# 4 "build/alignsem-raw-first/pointers/input.c"
                              ;
# 4 "build/alignsem-raw-first/pointers/input.c"
                                typedef
# 4 "build/alignsem-raw-first/pointers/input.c"
                                        P
# 4 "build/alignsem-raw-first/pointers/input.c"
                                          R
# 4 "build/alignsem-raw-first/pointers/input.c"
                                           ;
# 5 "build/alignsem-raw-first/pointers/input.c"
int
# 5 "build/alignsem-raw-first/pointers/input.c"
    main
# 5 "build/alignsem-raw-first/pointers/input.c"
        (
# 5 "build/alignsem-raw-first/pointers/input.c"
         void
# 5 "build/alignsem-raw-first/pointers/input.c"
             )
# 5 "build/alignsem-raw-first/pointers/input.c"
              {
# 5 "build/alignsem-raw-first/pointers/input.c"
               return
# 5 "build/alignsem-raw-first/pointers/input.c"
                      (
# 5 "build/alignsem-raw-first/pointers/input.c"
                       _Alignof
# 5 "build/alignsem-raw-first/pointers/input.c"
                               (
# 5 "build/alignsem-raw-first/pointers/input.c"
                                Up
# 5 "build/alignsem-raw-first/pointers/input.c"
                                  *
# 5 "build/alignsem-raw-first/pointers/input.c"
                                   )
# 5 "build/alignsem-raw-first/pointers/input.c"
                                    !=
# 5 "build/alignsem-raw-first/pointers/input.c"
                                      sizeof
# 5 "build/alignsem-raw-first/pointers/input.c"
                                            (
# 5 "build/alignsem-raw-first/pointers/input.c"
                                             void
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                 *
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                  )
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                    ||
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                       _Alignof
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                               (
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                P
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                 )
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                  !=
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                    sizeof
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                          (
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                           void
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                               *
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                )
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                  ||
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                     _Alignof
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                             (
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                              R
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                               )
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                !=
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                  sizeof
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                        (
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                         void
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                             *
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                              )
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                ||
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                   _Alignof
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                           (
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                            Q
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                             )
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                              !=
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                sizeof
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                      (
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                       void
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                           *
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                            )
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                              ||
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                                 _Alignof
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                                         (
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                                          Up
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                                            *
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                                             *
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                                              )
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                                               !=
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                                                 sizeof
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                                                       (
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                                                        void
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                                                            *
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                                                             )
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                                                               ||
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                                                                  sizeof
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                                                                        (
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                                                                         P
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                                                                          )
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                                                                           !=
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                                                                             sizeof
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                                                                                   (
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                                                                                    void
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                                                                                        *
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                                                                                         )
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                                                                                          )
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                                                                                           ;
# 5 "build/alignsem-raw-first/pointers/input.c"
                                                                                                                                                                                                            }

