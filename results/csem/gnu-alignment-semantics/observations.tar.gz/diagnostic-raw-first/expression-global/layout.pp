# 1 "build/alignsem-raw-first/expression-global/input.c"
int
# 1 "build/alignsem-raw-first/expression-global/input.c"
    obj
# 1 "build/alignsem-raw-first/expression-global/input.c"
        __attribute__
# 1 "build/alignsem-raw-first/expression-global/input.c"
                     (
# 1 "build/alignsem-raw-first/expression-global/input.c"
                      (
# 1 "build/alignsem-raw-first/expression-global/input.c"
                       aligned
# 1 "build/alignsem-raw-first/expression-global/input.c"
                              (
# 1 "build/alignsem-raw-first/expression-global/input.c"
                               32
# 1 "build/alignsem-raw-first/expression-global/input.c"
                                 )
# 1 "build/alignsem-raw-first/expression-global/input.c"
                                  )
# 1 "build/alignsem-raw-first/expression-global/input.c"
                                   )
# 1 "build/alignsem-raw-first/expression-global/input.c"
                                    ;
# 2 "build/alignsem-raw-first/expression-global/input.c"
int
# 2 "build/alignsem-raw-first/expression-global/input.c"
    main
# 2 "build/alignsem-raw-first/expression-global/input.c"
        (
# 2 "build/alignsem-raw-first/expression-global/input.c"
         void
# 2 "build/alignsem-raw-first/expression-global/input.c"
             )
# 2 "build/alignsem-raw-first/expression-global/input.c"
              {
# 2 "build/alignsem-raw-first/expression-global/input.c"
               return
# 2 "build/alignsem-raw-first/expression-global/input.c"
                      (
# 2 "build/alignsem-raw-first/expression-global/input.c"
                       __alignof__
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                  (
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                   obj
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                      )
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                       !=
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                         32
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                            ||
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                               __alignof__
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                          (
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                           &
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                            obj
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                               )
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                !=
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                  sizeof
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                        (
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                         void
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                             *
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                              )
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                ||
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                   __alignof__
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                              (
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                               +
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                                obj
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                                   )
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                                    !=
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                                      4
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                                        ||
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                                           __alignof__
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                                                      (
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                                                       (
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                                                        obj
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                                                           ,
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                                                            obj
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                                                               )
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                                                                )
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                                                                 !=
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                                                                   4
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                                                                     ||
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                                                                        _Alignof
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                                                                                (
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                                                                                 __typeof__
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                                                                                           (
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                                                                                            obj
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                                                                                               )
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                                                                                                )
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                                                                                                 !=
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                                                                                                   4
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                                                                                                    )
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                                                                                                     ;
# 2 "build/alignsem-raw-first/expression-global/input.c"
                                                                                                                                                                      }

