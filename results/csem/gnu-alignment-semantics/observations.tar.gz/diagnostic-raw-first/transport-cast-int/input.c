typedef int Up __attribute__((aligned(16))); Up x; Up f(void){return 0;}
int main(void){return _Alignof(__typeof__((int)x))!=4;}
