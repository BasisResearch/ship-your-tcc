typedef void V; int x[sizeof(V[1])]; int main(void){return 0;}
