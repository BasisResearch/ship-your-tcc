# 1 "build/alignsem-raw-first/constraint-typename-void-array/input.c"
typedef
# 1 "build/alignsem-raw-first/constraint-typename-void-array/input.c"
        void
# 1 "build/alignsem-raw-first/constraint-typename-void-array/input.c"
             V
# 1 "build/alignsem-raw-first/constraint-typename-void-array/input.c"
              ;
# 1 "build/alignsem-raw-first/constraint-typename-void-array/input.c"
                int
# 1 "build/alignsem-raw-first/constraint-typename-void-array/input.c"
                    x
# 1 "build/alignsem-raw-first/constraint-typename-void-array/input.c"
                     [
# 1 "build/alignsem-raw-first/constraint-typename-void-array/input.c"
                      sizeof
# 1 "build/alignsem-raw-first/constraint-typename-void-array/input.c"
                            (
# 1 "build/alignsem-raw-first/constraint-typename-void-array/input.c"
                             V
# 1 "build/alignsem-raw-first/constraint-typename-void-array/input.c"
                              [
# 1 "build/alignsem-raw-first/constraint-typename-void-array/input.c"
                               1
# 1 "build/alignsem-raw-first/constraint-typename-void-array/input.c"
                                ]
# 1 "build/alignsem-raw-first/constraint-typename-void-array/input.c"
                                 )
# 1 "build/alignsem-raw-first/constraint-typename-void-array/input.c"
                                  ]
# 1 "build/alignsem-raw-first/constraint-typename-void-array/input.c"
                                   ;
# 1 "build/alignsem-raw-first/constraint-typename-void-array/input.c"
                                     int
# 1 "build/alignsem-raw-first/constraint-typename-void-array/input.c"
                                         main
# 1 "build/alignsem-raw-first/constraint-typename-void-array/input.c"
                                             (
# 1 "build/alignsem-raw-first/constraint-typename-void-array/input.c"
                                              void
# 1 "build/alignsem-raw-first/constraint-typename-void-array/input.c"
                                                  )
# 1 "build/alignsem-raw-first/constraint-typename-void-array/input.c"
                                                   {
# 1 "build/alignsem-raw-first/constraint-typename-void-array/input.c"
                                                    return
# 1 "build/alignsem-raw-first/constraint-typename-void-array/input.c"
                                                           0
# 1 "build/alignsem-raw-first/constraint-typename-void-array/input.c"
                                                            ;
# 1 "build/alignsem-raw-first/constraint-typename-void-array/input.c"
                                                             }

