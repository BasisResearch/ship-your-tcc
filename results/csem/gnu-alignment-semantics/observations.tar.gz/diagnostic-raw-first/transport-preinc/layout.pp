# 1 "build/alignsem-raw-first/transport-preinc/input.c"
typedef
# 1 "build/alignsem-raw-first/transport-preinc/input.c"
        int
# 1 "build/alignsem-raw-first/transport-preinc/input.c"
            Up
# 1 "build/alignsem-raw-first/transport-preinc/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/transport-preinc/input.c"
                            (
# 1 "build/alignsem-raw-first/transport-preinc/input.c"
                             (
# 1 "build/alignsem-raw-first/transport-preinc/input.c"
                              aligned
# 1 "build/alignsem-raw-first/transport-preinc/input.c"
                                     (
# 1 "build/alignsem-raw-first/transport-preinc/input.c"
                                      16
# 1 "build/alignsem-raw-first/transport-preinc/input.c"
                                        )
# 1 "build/alignsem-raw-first/transport-preinc/input.c"
                                         )
# 1 "build/alignsem-raw-first/transport-preinc/input.c"
                                          )
# 1 "build/alignsem-raw-first/transport-preinc/input.c"
                                           ;
# 1 "build/alignsem-raw-first/transport-preinc/input.c"
                                             Up
# 1 "build/alignsem-raw-first/transport-preinc/input.c"
                                                x
# 1 "build/alignsem-raw-first/transport-preinc/input.c"
                                                 ;
# 1 "build/alignsem-raw-first/transport-preinc/input.c"
                                                   Up
# 1 "build/alignsem-raw-first/transport-preinc/input.c"
                                                      f
# 1 "build/alignsem-raw-first/transport-preinc/input.c"
                                                       (
# 1 "build/alignsem-raw-first/transport-preinc/input.c"
                                                        void
# 1 "build/alignsem-raw-first/transport-preinc/input.c"
                                                            )
# 1 "build/alignsem-raw-first/transport-preinc/input.c"
                                                             {
# 1 "build/alignsem-raw-first/transport-preinc/input.c"
                                                              return
# 1 "build/alignsem-raw-first/transport-preinc/input.c"
                                                                     0
# 1 "build/alignsem-raw-first/transport-preinc/input.c"
                                                                      ;
# 1 "build/alignsem-raw-first/transport-preinc/input.c"
                                                                       }
# 2 "build/alignsem-raw-first/transport-preinc/input.c"
int
# 2 "build/alignsem-raw-first/transport-preinc/input.c"
    main
# 2 "build/alignsem-raw-first/transport-preinc/input.c"
        (
# 2 "build/alignsem-raw-first/transport-preinc/input.c"
         void
# 2 "build/alignsem-raw-first/transport-preinc/input.c"
             )
# 2 "build/alignsem-raw-first/transport-preinc/input.c"
              {
# 2 "build/alignsem-raw-first/transport-preinc/input.c"
               return
# 2 "build/alignsem-raw-first/transport-preinc/input.c"
                      _Alignof
# 2 "build/alignsem-raw-first/transport-preinc/input.c"
                              (
# 2 "build/alignsem-raw-first/transport-preinc/input.c"
                               __typeof__
# 2 "build/alignsem-raw-first/transport-preinc/input.c"
                                         (
# 2 "build/alignsem-raw-first/transport-preinc/input.c"
                                          ++
# 2 "build/alignsem-raw-first/transport-preinc/input.c"
                                            x
# 2 "build/alignsem-raw-first/transport-preinc/input.c"
                                             )
# 2 "build/alignsem-raw-first/transport-preinc/input.c"
                                              )
# 2 "build/alignsem-raw-first/transport-preinc/input.c"
                                               !=
# 2 "build/alignsem-raw-first/transport-preinc/input.c"
                                                 16
# 2 "build/alignsem-raw-first/transport-preinc/input.c"
                                                   ;
# 2 "build/alignsem-raw-first/transport-preinc/input.c"
                                                    }

