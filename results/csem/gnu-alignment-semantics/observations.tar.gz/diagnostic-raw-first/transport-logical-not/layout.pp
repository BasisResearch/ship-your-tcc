# 1 "build/alignsem-raw-first/transport-logical-not/input.c"
typedef
# 1 "build/alignsem-raw-first/transport-logical-not/input.c"
        int
# 1 "build/alignsem-raw-first/transport-logical-not/input.c"
            Up
# 1 "build/alignsem-raw-first/transport-logical-not/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/transport-logical-not/input.c"
                            (
# 1 "build/alignsem-raw-first/transport-logical-not/input.c"
                             (
# 1 "build/alignsem-raw-first/transport-logical-not/input.c"
                              aligned
# 1 "build/alignsem-raw-first/transport-logical-not/input.c"
                                     (
# 1 "build/alignsem-raw-first/transport-logical-not/input.c"
                                      16
# 1 "build/alignsem-raw-first/transport-logical-not/input.c"
                                        )
# 1 "build/alignsem-raw-first/transport-logical-not/input.c"
                                         )
# 1 "build/alignsem-raw-first/transport-logical-not/input.c"
                                          )
# 1 "build/alignsem-raw-first/transport-logical-not/input.c"
                                           ;
# 1 "build/alignsem-raw-first/transport-logical-not/input.c"
                                             Up
# 1 "build/alignsem-raw-first/transport-logical-not/input.c"
                                                x
# 1 "build/alignsem-raw-first/transport-logical-not/input.c"
                                                 ;
# 1 "build/alignsem-raw-first/transport-logical-not/input.c"
                                                   Up
# 1 "build/alignsem-raw-first/transport-logical-not/input.c"
                                                      f
# 1 "build/alignsem-raw-first/transport-logical-not/input.c"
                                                       (
# 1 "build/alignsem-raw-first/transport-logical-not/input.c"
                                                        void
# 1 "build/alignsem-raw-first/transport-logical-not/input.c"
                                                            )
# 1 "build/alignsem-raw-first/transport-logical-not/input.c"
                                                             {
# 1 "build/alignsem-raw-first/transport-logical-not/input.c"
                                                              return
# 1 "build/alignsem-raw-first/transport-logical-not/input.c"
                                                                     0
# 1 "build/alignsem-raw-first/transport-logical-not/input.c"
                                                                      ;
# 1 "build/alignsem-raw-first/transport-logical-not/input.c"
                                                                       }
# 2 "build/alignsem-raw-first/transport-logical-not/input.c"
int
# 2 "build/alignsem-raw-first/transport-logical-not/input.c"
    main
# 2 "build/alignsem-raw-first/transport-logical-not/input.c"
        (
# 2 "build/alignsem-raw-first/transport-logical-not/input.c"
         void
# 2 "build/alignsem-raw-first/transport-logical-not/input.c"
             )
# 2 "build/alignsem-raw-first/transport-logical-not/input.c"
              {
# 2 "build/alignsem-raw-first/transport-logical-not/input.c"
               return
# 2 "build/alignsem-raw-first/transport-logical-not/input.c"
                      _Alignof
# 2 "build/alignsem-raw-first/transport-logical-not/input.c"
                              (
# 2 "build/alignsem-raw-first/transport-logical-not/input.c"
                               __typeof__
# 2 "build/alignsem-raw-first/transport-logical-not/input.c"
                                         (
# 2 "build/alignsem-raw-first/transport-logical-not/input.c"
                                          !
# 2 "build/alignsem-raw-first/transport-logical-not/input.c"
                                           x
# 2 "build/alignsem-raw-first/transport-logical-not/input.c"
                                            )
# 2 "build/alignsem-raw-first/transport-logical-not/input.c"
                                             )
# 2 "build/alignsem-raw-first/transport-logical-not/input.c"
                                              !=
# 2 "build/alignsem-raw-first/transport-logical-not/input.c"
                                                4
# 2 "build/alignsem-raw-first/transport-logical-not/input.c"
                                                 ;
# 2 "build/alignsem-raw-first/transport-logical-not/input.c"
                                                  }

