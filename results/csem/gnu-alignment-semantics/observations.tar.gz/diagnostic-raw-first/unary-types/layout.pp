# 1 "build/alignsem-raw-first/unary-types/input.c"
typedef
# 1 "build/alignsem-raw-first/unary-types/input.c"
        int
# 1 "build/alignsem-raw-first/unary-types/input.c"
            Up
# 1 "build/alignsem-raw-first/unary-types/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/unary-types/input.c"
                            (
# 1 "build/alignsem-raw-first/unary-types/input.c"
                             (
# 1 "build/alignsem-raw-first/unary-types/input.c"
                              aligned
# 1 "build/alignsem-raw-first/unary-types/input.c"
                                     (
# 1 "build/alignsem-raw-first/unary-types/input.c"
                                      16
# 1 "build/alignsem-raw-first/unary-types/input.c"
                                        )
# 1 "build/alignsem-raw-first/unary-types/input.c"
                                         )
# 1 "build/alignsem-raw-first/unary-types/input.c"
                                          )
# 1 "build/alignsem-raw-first/unary-types/input.c"
                                           ;
# 2 "build/alignsem-raw-first/unary-types/input.c"
typedef
# 2 "build/alignsem-raw-first/unary-types/input.c"
        int
# 2 "build/alignsem-raw-first/unary-types/input.c"
            Down
# 2 "build/alignsem-raw-first/unary-types/input.c"
                 __attribute__
# 2 "build/alignsem-raw-first/unary-types/input.c"
                              (
# 2 "build/alignsem-raw-first/unary-types/input.c"
                               (
# 2 "build/alignsem-raw-first/unary-types/input.c"
                                aligned
# 2 "build/alignsem-raw-first/unary-types/input.c"
                                       (
# 2 "build/alignsem-raw-first/unary-types/input.c"
                                        1
# 2 "build/alignsem-raw-first/unary-types/input.c"
                                         )
# 2 "build/alignsem-raw-first/unary-types/input.c"
                                          )
# 2 "build/alignsem-raw-first/unary-types/input.c"
                                           )
# 2 "build/alignsem-raw-first/unary-types/input.c"
                                            ;
# 3 "build/alignsem-raw-first/unary-types/input.c"
typedef
# 3 "build/alignsem-raw-first/unary-types/input.c"
        Up
# 3 "build/alignsem-raw-first/unary-types/input.c"
           Again
# 3 "build/alignsem-raw-first/unary-types/input.c"
                ;
# 4 "build/alignsem-raw-first/unary-types/input.c"
typedef
# 4 "build/alignsem-raw-first/unary-types/input.c"
        short
# 4 "build/alignsem-raw-first/unary-types/input.c"
              H
# 4 "build/alignsem-raw-first/unary-types/input.c"
                __attribute__
# 4 "build/alignsem-raw-first/unary-types/input.c"
                             (
# 4 "build/alignsem-raw-first/unary-types/input.c"
                              (
# 4 "build/alignsem-raw-first/unary-types/input.c"
                               aligned
# 4 "build/alignsem-raw-first/unary-types/input.c"
                                      (
# 4 "build/alignsem-raw-first/unary-types/input.c"
                                       8
# 4 "build/alignsem-raw-first/unary-types/input.c"
                                        )
# 4 "build/alignsem-raw-first/unary-types/input.c"
                                         )
# 4 "build/alignsem-raw-first/unary-types/input.c"
                                          )
# 4 "build/alignsem-raw-first/unary-types/input.c"
                                           ;
# 4 "build/alignsem-raw-first/unary-types/input.c"
                                             Up
# 4 "build/alignsem-raw-first/unary-types/input.c"
                                                x
# 4 "build/alignsem-raw-first/unary-types/input.c"
                                                 ;
# 4 "build/alignsem-raw-first/unary-types/input.c"
                                                   H
# 4 "build/alignsem-raw-first/unary-types/input.c"
                                                     h
# 4 "build/alignsem-raw-first/unary-types/input.c"
                                                      ;
# 5 "build/alignsem-raw-first/unary-types/input.c"
int
# 5 "build/alignsem-raw-first/unary-types/input.c"
    main
# 5 "build/alignsem-raw-first/unary-types/input.c"
        (
# 5 "build/alignsem-raw-first/unary-types/input.c"
         void
# 5 "build/alignsem-raw-first/unary-types/input.c"
             )
# 5 "build/alignsem-raw-first/unary-types/input.c"
              {
# 5 "build/alignsem-raw-first/unary-types/input.c"
               return
# 5 "build/alignsem-raw-first/unary-types/input.c"
                      (
# 5 "build/alignsem-raw-first/unary-types/input.c"
                       _Alignof
# 5 "build/alignsem-raw-first/unary-types/input.c"
                               (
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                __typeof__
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                          (
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                           +
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                            x
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                             )
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                              )
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                               !=
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                 16
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                    ||
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                       _Alignof
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                               (
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                __typeof__
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                          (
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                           -
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                            x
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                             )
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                              )
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                               !=
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                 16
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                    ||
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                       _Alignof
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                               (
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                __typeof__
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                          (
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                           ~
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                            x
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                             )
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                              )
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                               !=
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                                 16
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                                    ||
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                                       _Alignof
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                                               (
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                                                __typeof__
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                                                          (
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                                                           !
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                                                            x
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                                                             )
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                                                              )
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                                                               !=
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                                                                 4
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                                                                   ||
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                                                                      _Alignof
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                                                                              (
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                                                                               __typeof__
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                                                                                         (
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                                                                                          +
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                                                                                           h
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                                                                                            )
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                                                                                             )
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                                                                                              !=
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                                                                                                4
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                                                                                                 )
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                                                                                                  ;
# 5 "build/alignsem-raw-first/unary-types/input.c"
                                                                                                                                                                                   }

