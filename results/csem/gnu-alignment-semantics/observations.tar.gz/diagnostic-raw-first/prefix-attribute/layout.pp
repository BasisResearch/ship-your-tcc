# 1 "build/alignsem-raw-first/prefix-attribute/input.c"
typedef
# 1 "build/alignsem-raw-first/prefix-attribute/input.c"
        int
# 1 "build/alignsem-raw-first/prefix-attribute/input.c"
            Up
# 1 "build/alignsem-raw-first/prefix-attribute/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/prefix-attribute/input.c"
                            (
# 1 "build/alignsem-raw-first/prefix-attribute/input.c"
                             (
# 1 "build/alignsem-raw-first/prefix-attribute/input.c"
                              aligned
# 1 "build/alignsem-raw-first/prefix-attribute/input.c"
                                     (
# 1 "build/alignsem-raw-first/prefix-attribute/input.c"
                                      16
# 1 "build/alignsem-raw-first/prefix-attribute/input.c"
                                        )
# 1 "build/alignsem-raw-first/prefix-attribute/input.c"
                                         )
# 1 "build/alignsem-raw-first/prefix-attribute/input.c"
                                          )
# 1 "build/alignsem-raw-first/prefix-attribute/input.c"
                                           ;
# 2 "build/alignsem-raw-first/prefix-attribute/input.c"
typedef
# 2 "build/alignsem-raw-first/prefix-attribute/input.c"
        int
# 2 "build/alignsem-raw-first/prefix-attribute/input.c"
            Down
# 2 "build/alignsem-raw-first/prefix-attribute/input.c"
                 __attribute__
# 2 "build/alignsem-raw-first/prefix-attribute/input.c"
                              (
# 2 "build/alignsem-raw-first/prefix-attribute/input.c"
                               (
# 2 "build/alignsem-raw-first/prefix-attribute/input.c"
                                aligned
# 2 "build/alignsem-raw-first/prefix-attribute/input.c"
                                       (
# 2 "build/alignsem-raw-first/prefix-attribute/input.c"
                                        1
# 2 "build/alignsem-raw-first/prefix-attribute/input.c"
                                         )
# 2 "build/alignsem-raw-first/prefix-attribute/input.c"
                                          )
# 2 "build/alignsem-raw-first/prefix-attribute/input.c"
                                           )
# 2 "build/alignsem-raw-first/prefix-attribute/input.c"
                                            ;
# 3 "build/alignsem-raw-first/prefix-attribute/input.c"
typedef
# 3 "build/alignsem-raw-first/prefix-attribute/input.c"
        Up
# 3 "build/alignsem-raw-first/prefix-attribute/input.c"
           Again
# 3 "build/alignsem-raw-first/prefix-attribute/input.c"
                ;
# 4 "build/alignsem-raw-first/prefix-attribute/input.c"
typedef
# 4 "build/alignsem-raw-first/prefix-attribute/input.c"
        __attribute__
# 4 "build/alignsem-raw-first/prefix-attribute/input.c"
                     (
# 4 "build/alignsem-raw-first/prefix-attribute/input.c"
                      (
# 4 "build/alignsem-raw-first/prefix-attribute/input.c"
                       aligned
# 4 "build/alignsem-raw-first/prefix-attribute/input.c"
                              (
# 4 "build/alignsem-raw-first/prefix-attribute/input.c"
                               2
# 4 "build/alignsem-raw-first/prefix-attribute/input.c"
                                )
# 4 "build/alignsem-raw-first/prefix-attribute/input.c"
                                 )
# 4 "build/alignsem-raw-first/prefix-attribute/input.c"
                                  )
# 4 "build/alignsem-raw-first/prefix-attribute/input.c"
                                    Up
# 4 "build/alignsem-raw-first/prefix-attribute/input.c"
                                       Weak
# 4 "build/alignsem-raw-first/prefix-attribute/input.c"
                                           ;
# 4 "build/alignsem-raw-first/prefix-attribute/input.c"
                                             typedef
# 4 "build/alignsem-raw-first/prefix-attribute/input.c"
                                                     __attribute__
# 4 "build/alignsem-raw-first/prefix-attribute/input.c"
                                                                  (
# 4 "build/alignsem-raw-first/prefix-attribute/input.c"
                                                                   (
# 4 "build/alignsem-raw-first/prefix-attribute/input.c"
                                                                    __aligned__
# 4 "build/alignsem-raw-first/prefix-attribute/input.c"
                                                                               (
# 4 "build/alignsem-raw-first/prefix-attribute/input.c"
                                                                                32
# 4 "build/alignsem-raw-first/prefix-attribute/input.c"
                                                                                  )
# 4 "build/alignsem-raw-first/prefix-attribute/input.c"
                                                                                   )
# 4 "build/alignsem-raw-first/prefix-attribute/input.c"
                                                                                    )
# 4 "build/alignsem-raw-first/prefix-attribute/input.c"
                                                                                      Down
# 4 "build/alignsem-raw-first/prefix-attribute/input.c"
                                                                                           Strong
# 4 "build/alignsem-raw-first/prefix-attribute/input.c"
                                                                                                 ;
# 5 "build/alignsem-raw-first/prefix-attribute/input.c"
int
# 5 "build/alignsem-raw-first/prefix-attribute/input.c"
    main
# 5 "build/alignsem-raw-first/prefix-attribute/input.c"
        (
# 5 "build/alignsem-raw-first/prefix-attribute/input.c"
         void
# 5 "build/alignsem-raw-first/prefix-attribute/input.c"
             )
# 5 "build/alignsem-raw-first/prefix-attribute/input.c"
              {
# 5 "build/alignsem-raw-first/prefix-attribute/input.c"
               return
# 5 "build/alignsem-raw-first/prefix-attribute/input.c"
                      (
# 5 "build/alignsem-raw-first/prefix-attribute/input.c"
                       _Alignof
# 5 "build/alignsem-raw-first/prefix-attribute/input.c"
                               (
# 5 "build/alignsem-raw-first/prefix-attribute/input.c"
                                Weak
# 5 "build/alignsem-raw-first/prefix-attribute/input.c"
                                    )
# 5 "build/alignsem-raw-first/prefix-attribute/input.c"
                                     !=
# 5 "build/alignsem-raw-first/prefix-attribute/input.c"
                                       2
# 5 "build/alignsem-raw-first/prefix-attribute/input.c"
                                         ||
# 5 "build/alignsem-raw-first/prefix-attribute/input.c"
                                            _Alignof
# 5 "build/alignsem-raw-first/prefix-attribute/input.c"
                                                    (
# 5 "build/alignsem-raw-first/prefix-attribute/input.c"
                                                     Strong
# 5 "build/alignsem-raw-first/prefix-attribute/input.c"
                                                           )
# 5 "build/alignsem-raw-first/prefix-attribute/input.c"
                                                            !=
# 5 "build/alignsem-raw-first/prefix-attribute/input.c"
                                                              32
# 5 "build/alignsem-raw-first/prefix-attribute/input.c"
                                                                )
# 5 "build/alignsem-raw-first/prefix-attribute/input.c"
                                                                 ;
# 5 "build/alignsem-raw-first/prefix-attribute/input.c"
                                                                  }

