# 1 "build/alignsem-raw-first/expression-parent/input.c"
struct
# 1 "build/alignsem-raw-first/expression-parent/input.c"
       S
# 1 "build/alignsem-raw-first/expression-parent/input.c"
         {
# 1 "build/alignsem-raw-first/expression-parent/input.c"
          char
# 1 "build/alignsem-raw-first/expression-parent/input.c"
               c
# 1 "build/alignsem-raw-first/expression-parent/input.c"
                ;
# 1 "build/alignsem-raw-first/expression-parent/input.c"
                  int
# 1 "build/alignsem-raw-first/expression-parent/input.c"
                      i
# 1 "build/alignsem-raw-first/expression-parent/input.c"
                       ;
# 1 "build/alignsem-raw-first/expression-parent/input.c"
                        }
# 1 "build/alignsem-raw-first/expression-parent/input.c"
                         ;
# 1 "build/alignsem-raw-first/expression-parent/input.c"
                           struct
# 1 "build/alignsem-raw-first/expression-parent/input.c"
                                  S
# 1 "build/alignsem-raw-first/expression-parent/input.c"
                                    obj
# 1 "build/alignsem-raw-first/expression-parent/input.c"
                                        __attribute__
# 1 "build/alignsem-raw-first/expression-parent/input.c"
                                                     (
# 1 "build/alignsem-raw-first/expression-parent/input.c"
                                                      (
# 1 "build/alignsem-raw-first/expression-parent/input.c"
                                                       aligned
# 1 "build/alignsem-raw-first/expression-parent/input.c"
                                                              (
# 1 "build/alignsem-raw-first/expression-parent/input.c"
                                                               32
# 1 "build/alignsem-raw-first/expression-parent/input.c"
                                                                 )
# 1 "build/alignsem-raw-first/expression-parent/input.c"
                                                                  )
# 1 "build/alignsem-raw-first/expression-parent/input.c"
                                                                   )
# 1 "build/alignsem-raw-first/expression-parent/input.c"
                                                                    ;
# 2 "build/alignsem-raw-first/expression-parent/input.c"
int
# 2 "build/alignsem-raw-first/expression-parent/input.c"
    main
# 2 "build/alignsem-raw-first/expression-parent/input.c"
        (
# 2 "build/alignsem-raw-first/expression-parent/input.c"
         void
# 2 "build/alignsem-raw-first/expression-parent/input.c"
             )
# 2 "build/alignsem-raw-first/expression-parent/input.c"
              {
# 2 "build/alignsem-raw-first/expression-parent/input.c"
               return
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                      (
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                       __alignof__
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                  (
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                   obj
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                      )
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                       !=
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                         32
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                            ||
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                               __alignof__
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                          (
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                           obj
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                              .
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                               c
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                )
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                 !=
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                   1
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                     ||
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                        __alignof__
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                                   (
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                                    obj
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                                       .
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                                        i
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                                         )
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                                          !=
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                                            4
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                                              ||
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                                                 __alignof__
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                                                            (
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                                                             &
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                                                              obj
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                                                                 .
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                                                                  c
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                                                                   )
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                                                                    !=
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                                                                      sizeof
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                                                                            (
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                                                                             void
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                                                                                 *
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                                                                                  )
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                                                                                   )
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                                                                                    ;
# 2 "build/alignsem-raw-first/expression-parent/input.c"
                                                                                                                                     }

