# 1 "build/alignsem-raw-first/expression-array/input.c"
int
# 1 "build/alignsem-raw-first/expression-array/input.c"
    arr
# 1 "build/alignsem-raw-first/expression-array/input.c"
       [
# 1 "build/alignsem-raw-first/expression-array/input.c"
        3
# 1 "build/alignsem-raw-first/expression-array/input.c"
         ]
# 1 "build/alignsem-raw-first/expression-array/input.c"
           __attribute__
# 1 "build/alignsem-raw-first/expression-array/input.c"
                        (
# 1 "build/alignsem-raw-first/expression-array/input.c"
                         (
# 1 "build/alignsem-raw-first/expression-array/input.c"
                          aligned
# 1 "build/alignsem-raw-first/expression-array/input.c"
                                 (
# 1 "build/alignsem-raw-first/expression-array/input.c"
                                  32
# 1 "build/alignsem-raw-first/expression-array/input.c"
                                    )
# 1 "build/alignsem-raw-first/expression-array/input.c"
                                     )
# 1 "build/alignsem-raw-first/expression-array/input.c"
                                      )
# 1 "build/alignsem-raw-first/expression-array/input.c"
                                       ;
# 2 "build/alignsem-raw-first/expression-array/input.c"
int
# 2 "build/alignsem-raw-first/expression-array/input.c"
    main
# 2 "build/alignsem-raw-first/expression-array/input.c"
        (
# 2 "build/alignsem-raw-first/expression-array/input.c"
         void
# 2 "build/alignsem-raw-first/expression-array/input.c"
             )
# 2 "build/alignsem-raw-first/expression-array/input.c"
              {
# 2 "build/alignsem-raw-first/expression-array/input.c"
               return
# 2 "build/alignsem-raw-first/expression-array/input.c"
                      (
# 2 "build/alignsem-raw-first/expression-array/input.c"
                       __alignof__
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                  (
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                   arr
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                      )
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                       !=
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                         32
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                            ||
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                               __alignof__
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                          (
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                           &
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                            arr
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                               )
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                                !=
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                                  sizeof
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                                        (
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                                         void
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                                             *
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                                              )
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                                                ||
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                                                   sizeof
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                                                         (
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                                                          arr
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                                                             )
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                                                              !=
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                                                                12
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                                                                   ||
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                                                                      _Alignof
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                                                                              (
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                                                                               __typeof__
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                                                                                         (
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                                                                                          arr
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                                                                                             )
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                                                                                              )
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                                                                                               !=
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                                                                                                 4
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                                                                                                  )
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                                                                                                   ;
# 2 "build/alignsem-raw-first/expression-array/input.c"
                                                                                                                                    }

