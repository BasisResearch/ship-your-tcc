# 1 "build/alignsem-raw-first/arrays/input.c"
typedef
# 1 "build/alignsem-raw-first/arrays/input.c"
        int
# 1 "build/alignsem-raw-first/arrays/input.c"
            Up
# 1 "build/alignsem-raw-first/arrays/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/arrays/input.c"
                            (
# 1 "build/alignsem-raw-first/arrays/input.c"
                             (
# 1 "build/alignsem-raw-first/arrays/input.c"
                              aligned
# 1 "build/alignsem-raw-first/arrays/input.c"
                                     (
# 1 "build/alignsem-raw-first/arrays/input.c"
                                      16
# 1 "build/alignsem-raw-first/arrays/input.c"
                                        )
# 1 "build/alignsem-raw-first/arrays/input.c"
                                         )
# 1 "build/alignsem-raw-first/arrays/input.c"
                                          )
# 1 "build/alignsem-raw-first/arrays/input.c"
                                           ;
# 2 "build/alignsem-raw-first/arrays/input.c"
typedef
# 2 "build/alignsem-raw-first/arrays/input.c"
        int
# 2 "build/alignsem-raw-first/arrays/input.c"
            Down
# 2 "build/alignsem-raw-first/arrays/input.c"
                 __attribute__
# 2 "build/alignsem-raw-first/arrays/input.c"
                              (
# 2 "build/alignsem-raw-first/arrays/input.c"
                               (
# 2 "build/alignsem-raw-first/arrays/input.c"
                                aligned
# 2 "build/alignsem-raw-first/arrays/input.c"
                                       (
# 2 "build/alignsem-raw-first/arrays/input.c"
                                        1
# 2 "build/alignsem-raw-first/arrays/input.c"
                                         )
# 2 "build/alignsem-raw-first/arrays/input.c"
                                          )
# 2 "build/alignsem-raw-first/arrays/input.c"
                                           )
# 2 "build/alignsem-raw-first/arrays/input.c"
                                            ;
# 3 "build/alignsem-raw-first/arrays/input.c"
typedef
# 3 "build/alignsem-raw-first/arrays/input.c"
        Up
# 3 "build/alignsem-raw-first/arrays/input.c"
           Again
# 3 "build/alignsem-raw-first/arrays/input.c"
                ;
# 4 "build/alignsem-raw-first/arrays/input.c"
typedef
# 4 "build/alignsem-raw-first/arrays/input.c"
        Down
# 4 "build/alignsem-raw-first/arrays/input.c"
             A
# 4 "build/alignsem-raw-first/arrays/input.c"
              [
# 4 "build/alignsem-raw-first/arrays/input.c"
               3
# 4 "build/alignsem-raw-first/arrays/input.c"
                ]
# 4 "build/alignsem-raw-first/arrays/input.c"
                 ;
# 4 "build/alignsem-raw-first/arrays/input.c"
                   typedef
# 4 "build/alignsem-raw-first/arrays/input.c"
                           A
# 4 "build/alignsem-raw-first/arrays/input.c"
                             B
# 4 "build/alignsem-raw-first/arrays/input.c"
                              [
# 4 "build/alignsem-raw-first/arrays/input.c"
                               2
# 4 "build/alignsem-raw-first/arrays/input.c"
                                ]
# 4 "build/alignsem-raw-first/arrays/input.c"
                                 ;
# 4 "build/alignsem-raw-first/arrays/input.c"
                                   typedef
# 4 "build/alignsem-raw-first/arrays/input.c"
                                           const
# 4 "build/alignsem-raw-first/arrays/input.c"
                                                 A
# 4 "build/alignsem-raw-first/arrays/input.c"
                                                   C
# 4 "build/alignsem-raw-first/arrays/input.c"
                                                    ;
# 5 "build/alignsem-raw-first/arrays/input.c"
int
# 5 "build/alignsem-raw-first/arrays/input.c"
    main
# 5 "build/alignsem-raw-first/arrays/input.c"
        (
# 5 "build/alignsem-raw-first/arrays/input.c"
         void
# 5 "build/alignsem-raw-first/arrays/input.c"
             )
# 5 "build/alignsem-raw-first/arrays/input.c"
              {
# 5 "build/alignsem-raw-first/arrays/input.c"
               return
# 5 "build/alignsem-raw-first/arrays/input.c"
                      (
# 5 "build/alignsem-raw-first/arrays/input.c"
                       _Alignof
# 5 "build/alignsem-raw-first/arrays/input.c"
                               (
# 5 "build/alignsem-raw-first/arrays/input.c"
                                A
# 5 "build/alignsem-raw-first/arrays/input.c"
                                 )
# 5 "build/alignsem-raw-first/arrays/input.c"
                                  !=
# 5 "build/alignsem-raw-first/arrays/input.c"
                                    1
# 5 "build/alignsem-raw-first/arrays/input.c"
                                      ||
# 5 "build/alignsem-raw-first/arrays/input.c"
                                         _Alignof
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                 (
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                  B
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                   )
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                    !=
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                      1
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                        ||
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                           _Alignof
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                   (
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                    C
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                     )
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                      !=
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                        1
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                          ||
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                             sizeof
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                                   (
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                                    A
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                                     )
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                                      !=
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                                        12
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                                           ||
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                                              sizeof
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                                                    (
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                                                     B
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                                                      )
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                                                       !=
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                                                         24
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                                                            ||
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                                                               _Alignof
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                                                                       (
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                                                                        Down
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                                                                            [
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                                                                             3
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                                                                              ]
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                                                                               )
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                                                                                !=
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                                                                                  1
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                                                                                   )
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                                                                                    ;
# 5 "build/alignsem-raw-first/arrays/input.c"
                                                                                                                                     }

