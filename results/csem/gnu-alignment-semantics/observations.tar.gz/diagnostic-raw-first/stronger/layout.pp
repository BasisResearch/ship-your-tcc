# 1 "build/alignsem-raw-first/stronger/input.c"
typedef
# 1 "build/alignsem-raw-first/stronger/input.c"
        int
# 1 "build/alignsem-raw-first/stronger/input.c"
            Up
# 1 "build/alignsem-raw-first/stronger/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/stronger/input.c"
                            (
# 1 "build/alignsem-raw-first/stronger/input.c"
                             (
# 1 "build/alignsem-raw-first/stronger/input.c"
                              aligned
# 1 "build/alignsem-raw-first/stronger/input.c"
                                     (
# 1 "build/alignsem-raw-first/stronger/input.c"
                                      16
# 1 "build/alignsem-raw-first/stronger/input.c"
                                        )
# 1 "build/alignsem-raw-first/stronger/input.c"
                                         )
# 1 "build/alignsem-raw-first/stronger/input.c"
                                          )
# 1 "build/alignsem-raw-first/stronger/input.c"
                                           ;
# 2 "build/alignsem-raw-first/stronger/input.c"
typedef
# 2 "build/alignsem-raw-first/stronger/input.c"
        int
# 2 "build/alignsem-raw-first/stronger/input.c"
            Down
# 2 "build/alignsem-raw-first/stronger/input.c"
                 __attribute__
# 2 "build/alignsem-raw-first/stronger/input.c"
                              (
# 2 "build/alignsem-raw-first/stronger/input.c"
                               (
# 2 "build/alignsem-raw-first/stronger/input.c"
                                aligned
# 2 "build/alignsem-raw-first/stronger/input.c"
                                       (
# 2 "build/alignsem-raw-first/stronger/input.c"
                                        1
# 2 "build/alignsem-raw-first/stronger/input.c"
                                         )
# 2 "build/alignsem-raw-first/stronger/input.c"
                                          )
# 2 "build/alignsem-raw-first/stronger/input.c"
                                           )
# 2 "build/alignsem-raw-first/stronger/input.c"
                                            ;
# 3 "build/alignsem-raw-first/stronger/input.c"
typedef
# 3 "build/alignsem-raw-first/stronger/input.c"
        Up
# 3 "build/alignsem-raw-first/stronger/input.c"
           Again
# 3 "build/alignsem-raw-first/stronger/input.c"
                ;
# 4 "build/alignsem-raw-first/stronger/input.c"
typedef
# 4 "build/alignsem-raw-first/stronger/input.c"
        Down
# 4 "build/alignsem-raw-first/stronger/input.c"
             Strong
# 4 "build/alignsem-raw-first/stronger/input.c"
                    __attribute__
# 4 "build/alignsem-raw-first/stronger/input.c"
                                 (
# 4 "build/alignsem-raw-first/stronger/input.c"
                                  (
# 4 "build/alignsem-raw-first/stronger/input.c"
                                   aligned
# 4 "build/alignsem-raw-first/stronger/input.c"
                                          (
# 4 "build/alignsem-raw-first/stronger/input.c"
                                           32
# 4 "build/alignsem-raw-first/stronger/input.c"
                                             )
# 4 "build/alignsem-raw-first/stronger/input.c"
                                              )
# 4 "build/alignsem-raw-first/stronger/input.c"
                                               )
# 4 "build/alignsem-raw-first/stronger/input.c"
                                                ;
# 4 "build/alignsem-raw-first/stronger/input.c"
                                                  typedef
# 4 "build/alignsem-raw-first/stronger/input.c"
                                                          Strong
# 4 "build/alignsem-raw-first/stronger/input.c"
                                                                 S
# 4 "build/alignsem-raw-first/stronger/input.c"
                                                                  ;
# 5 "build/alignsem-raw-first/stronger/input.c"
int
# 5 "build/alignsem-raw-first/stronger/input.c"
    main
# 5 "build/alignsem-raw-first/stronger/input.c"
        (
# 5 "build/alignsem-raw-first/stronger/input.c"
         void
# 5 "build/alignsem-raw-first/stronger/input.c"
             )
# 5 "build/alignsem-raw-first/stronger/input.c"
              {
# 5 "build/alignsem-raw-first/stronger/input.c"
               return
# 5 "build/alignsem-raw-first/stronger/input.c"
                      (
# 5 "build/alignsem-raw-first/stronger/input.c"
                       _Alignof
# 5 "build/alignsem-raw-first/stronger/input.c"
                               (
# 5 "build/alignsem-raw-first/stronger/input.c"
                                S
# 5 "build/alignsem-raw-first/stronger/input.c"
                                 )
# 5 "build/alignsem-raw-first/stronger/input.c"
                                  !=
# 5 "build/alignsem-raw-first/stronger/input.c"
                                    32
# 5 "build/alignsem-raw-first/stronger/input.c"
                                       ||
# 5 "build/alignsem-raw-first/stronger/input.c"
                                          sizeof
# 5 "build/alignsem-raw-first/stronger/input.c"
                                                (
# 5 "build/alignsem-raw-first/stronger/input.c"
                                                 S
# 5 "build/alignsem-raw-first/stronger/input.c"
                                                  )
# 5 "build/alignsem-raw-first/stronger/input.c"
                                                   !=
# 5 "build/alignsem-raw-first/stronger/input.c"
                                                     4
# 5 "build/alignsem-raw-first/stronger/input.c"
                                                       ||
# 5 "build/alignsem-raw-first/stronger/input.c"
                                                          _Alignof
# 5 "build/alignsem-raw-first/stronger/input.c"
                                                                  (
# 5 "build/alignsem-raw-first/stronger/input.c"
                                                                   Down
# 5 "build/alignsem-raw-first/stronger/input.c"
                                                                       )
# 5 "build/alignsem-raw-first/stronger/input.c"
                                                                        !=
# 5 "build/alignsem-raw-first/stronger/input.c"
                                                                          1
# 5 "build/alignsem-raw-first/stronger/input.c"
                                                                           )
# 5 "build/alignsem-raw-first/stronger/input.c"
                                                                            ;
# 5 "build/alignsem-raw-first/stronger/input.c"
                                                                             }

