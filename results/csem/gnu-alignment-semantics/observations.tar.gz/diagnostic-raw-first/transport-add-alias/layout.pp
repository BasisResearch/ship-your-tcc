# 1 "build/alignsem-raw-first/transport-add-alias/input.c"
typedef
# 1 "build/alignsem-raw-first/transport-add-alias/input.c"
        int
# 1 "build/alignsem-raw-first/transport-add-alias/input.c"
            Up
# 1 "build/alignsem-raw-first/transport-add-alias/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/transport-add-alias/input.c"
                            (
# 1 "build/alignsem-raw-first/transport-add-alias/input.c"
                             (
# 1 "build/alignsem-raw-first/transport-add-alias/input.c"
                              aligned
# 1 "build/alignsem-raw-first/transport-add-alias/input.c"
                                     (
# 1 "build/alignsem-raw-first/transport-add-alias/input.c"
                                      16
# 1 "build/alignsem-raw-first/transport-add-alias/input.c"
                                        )
# 1 "build/alignsem-raw-first/transport-add-alias/input.c"
                                         )
# 1 "build/alignsem-raw-first/transport-add-alias/input.c"
                                          )
# 1 "build/alignsem-raw-first/transport-add-alias/input.c"
                                           ;
# 1 "build/alignsem-raw-first/transport-add-alias/input.c"
                                             Up
# 1 "build/alignsem-raw-first/transport-add-alias/input.c"
                                                x
# 1 "build/alignsem-raw-first/transport-add-alias/input.c"
                                                 ;
# 1 "build/alignsem-raw-first/transport-add-alias/input.c"
                                                   Up
# 1 "build/alignsem-raw-first/transport-add-alias/input.c"
                                                      f
# 1 "build/alignsem-raw-first/transport-add-alias/input.c"
                                                       (
# 1 "build/alignsem-raw-first/transport-add-alias/input.c"
                                                        void
# 1 "build/alignsem-raw-first/transport-add-alias/input.c"
                                                            )
# 1 "build/alignsem-raw-first/transport-add-alias/input.c"
                                                             {
# 1 "build/alignsem-raw-first/transport-add-alias/input.c"
                                                              return
# 1 "build/alignsem-raw-first/transport-add-alias/input.c"
                                                                     0
# 1 "build/alignsem-raw-first/transport-add-alias/input.c"
                                                                      ;
# 1 "build/alignsem-raw-first/transport-add-alias/input.c"
                                                                       }
# 2 "build/alignsem-raw-first/transport-add-alias/input.c"
int
# 2 "build/alignsem-raw-first/transport-add-alias/input.c"
    main
# 2 "build/alignsem-raw-first/transport-add-alias/input.c"
        (
# 2 "build/alignsem-raw-first/transport-add-alias/input.c"
         void
# 2 "build/alignsem-raw-first/transport-add-alias/input.c"
             )
# 2 "build/alignsem-raw-first/transport-add-alias/input.c"
              {
# 2 "build/alignsem-raw-first/transport-add-alias/input.c"
               return
# 2 "build/alignsem-raw-first/transport-add-alias/input.c"
                      _Alignof
# 2 "build/alignsem-raw-first/transport-add-alias/input.c"
                              (
# 2 "build/alignsem-raw-first/transport-add-alias/input.c"
                               __typeof__
# 2 "build/alignsem-raw-first/transport-add-alias/input.c"
                                         (
# 2 "build/alignsem-raw-first/transport-add-alias/input.c"
                                          x
# 2 "build/alignsem-raw-first/transport-add-alias/input.c"
                                           +
# 2 "build/alignsem-raw-first/transport-add-alias/input.c"
                                            x
# 2 "build/alignsem-raw-first/transport-add-alias/input.c"
                                             )
# 2 "build/alignsem-raw-first/transport-add-alias/input.c"
                                              )
# 2 "build/alignsem-raw-first/transport-add-alias/input.c"
                                               !=
# 2 "build/alignsem-raw-first/transport-add-alias/input.c"
                                                 16
# 2 "build/alignsem-raw-first/transport-add-alias/input.c"
                                                   ;
# 2 "build/alignsem-raw-first/transport-add-alias/input.c"
                                                    }

