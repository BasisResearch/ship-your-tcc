# 1 "build/alignsem-raw-first/nested-declarator/input.c"
typedef
# 1 "build/alignsem-raw-first/nested-declarator/input.c"
        int
# 1 "build/alignsem-raw-first/nested-declarator/input.c"
            Up
# 1 "build/alignsem-raw-first/nested-declarator/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/nested-declarator/input.c"
                            (
# 1 "build/alignsem-raw-first/nested-declarator/input.c"
                             (
# 1 "build/alignsem-raw-first/nested-declarator/input.c"
                              aligned
# 1 "build/alignsem-raw-first/nested-declarator/input.c"
                                     (
# 1 "build/alignsem-raw-first/nested-declarator/input.c"
                                      16
# 1 "build/alignsem-raw-first/nested-declarator/input.c"
                                        )
# 1 "build/alignsem-raw-first/nested-declarator/input.c"
                                         )
# 1 "build/alignsem-raw-first/nested-declarator/input.c"
                                          )
# 1 "build/alignsem-raw-first/nested-declarator/input.c"
                                           ;
# 2 "build/alignsem-raw-first/nested-declarator/input.c"
typedef
# 2 "build/alignsem-raw-first/nested-declarator/input.c"
        int
# 2 "build/alignsem-raw-first/nested-declarator/input.c"
            Down
# 2 "build/alignsem-raw-first/nested-declarator/input.c"
                 __attribute__
# 2 "build/alignsem-raw-first/nested-declarator/input.c"
                              (
# 2 "build/alignsem-raw-first/nested-declarator/input.c"
                               (
# 2 "build/alignsem-raw-first/nested-declarator/input.c"
                                aligned
# 2 "build/alignsem-raw-first/nested-declarator/input.c"
                                       (
# 2 "build/alignsem-raw-first/nested-declarator/input.c"
                                        1
# 2 "build/alignsem-raw-first/nested-declarator/input.c"
                                         )
# 2 "build/alignsem-raw-first/nested-declarator/input.c"
                                          )
# 2 "build/alignsem-raw-first/nested-declarator/input.c"
                                           )
# 2 "build/alignsem-raw-first/nested-declarator/input.c"
                                            ;
# 3 "build/alignsem-raw-first/nested-declarator/input.c"
typedef
# 3 "build/alignsem-raw-first/nested-declarator/input.c"
        Up
# 3 "build/alignsem-raw-first/nested-declarator/input.c"
           Again
# 3 "build/alignsem-raw-first/nested-declarator/input.c"
                ;
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
typedef
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
        Down
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
             (
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
              *
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
               P
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
                )
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
                 [
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
                  3
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
                   ]
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
                    ;
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
                      typedef
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
                              Up
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
                                 (
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
                                  *
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
                                   F
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
                                    )
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
                                     (
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
                                      Down
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
                                          )
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
                                           ;
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
                                             Up
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
                                                fun
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
                                                   (
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
                                                    Down
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
                                                         x
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
                                                          )
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
                                                           {
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
                                                            return
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                   x
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                    +
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                     1
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                      ;
# 4 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                       }
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
int
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
    main
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
        (
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
         void
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
             )
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
              {
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
               return
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                      (
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                       _Alignof
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                               (
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                P
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                 )
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                  !=
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                    sizeof
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                          (
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                           void
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                               *
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                )
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                  ||
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                     _Alignof
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                             (
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                              F
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                               )
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                !=
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                  sizeof
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                        (
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                         void
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                             *
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                              )
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                                ||
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                                   sizeof
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                                         (
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                                          P
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                                           )
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                                            !=
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                                              sizeof
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                                                    (
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                                                     void
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                                                         *
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                                                          )
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                                                            ||
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                                                               fun
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                                                                  (
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                                                                   4
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                                                                    )
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                                                                     !=
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                                                                       5
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                                                                        )
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                                                                         ;
# 5 "build/alignsem-raw-first/nested-declarator/input.c"
                                                                                                                          }

