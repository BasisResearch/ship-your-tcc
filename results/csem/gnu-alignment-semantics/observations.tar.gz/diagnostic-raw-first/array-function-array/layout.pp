# 1 "build/alignsem-raw-first/array-function-array/input.c"
int
# 1 "build/alignsem-raw-first/array-function-array/input.c"
    f
# 1 "build/alignsem-raw-first/array-function-array/input.c"
     [
# 1 "build/alignsem-raw-first/array-function-array/input.c"
      1
# 1 "build/alignsem-raw-first/array-function-array/input.c"
       ]
# 1 "build/alignsem-raw-first/array-function-array/input.c"
        (
# 1 "build/alignsem-raw-first/array-function-array/input.c"
         void
# 1 "build/alignsem-raw-first/array-function-array/input.c"
             )
# 1 "build/alignsem-raw-first/array-function-array/input.c"
              ;
# 1 "build/alignsem-raw-first/array-function-array/input.c"
                int
# 1 "build/alignsem-raw-first/array-function-array/input.c"
                    main
# 1 "build/alignsem-raw-first/array-function-array/input.c"
                        (
# 1 "build/alignsem-raw-first/array-function-array/input.c"
                         void
# 1 "build/alignsem-raw-first/array-function-array/input.c"
                             )
# 1 "build/alignsem-raw-first/array-function-array/input.c"
                              {
# 1 "build/alignsem-raw-first/array-function-array/input.c"
                               return
# 1 "build/alignsem-raw-first/array-function-array/input.c"
                                      0
# 1 "build/alignsem-raw-first/array-function-array/input.c"
                                       ;
# 1 "build/alignsem-raw-first/array-function-array/input.c"
                                        }

