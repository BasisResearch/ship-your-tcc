# 1 "build/alignsem-raw-first/transport-shift-right/input.c"
typedef
# 1 "build/alignsem-raw-first/transport-shift-right/input.c"
        int
# 1 "build/alignsem-raw-first/transport-shift-right/input.c"
            Up
# 1 "build/alignsem-raw-first/transport-shift-right/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/transport-shift-right/input.c"
                            (
# 1 "build/alignsem-raw-first/transport-shift-right/input.c"
                             (
# 1 "build/alignsem-raw-first/transport-shift-right/input.c"
                              aligned
# 1 "build/alignsem-raw-first/transport-shift-right/input.c"
                                     (
# 1 "build/alignsem-raw-first/transport-shift-right/input.c"
                                      16
# 1 "build/alignsem-raw-first/transport-shift-right/input.c"
                                        )
# 1 "build/alignsem-raw-first/transport-shift-right/input.c"
                                         )
# 1 "build/alignsem-raw-first/transport-shift-right/input.c"
                                          )
# 1 "build/alignsem-raw-first/transport-shift-right/input.c"
                                           ;
# 1 "build/alignsem-raw-first/transport-shift-right/input.c"
                                             Up
# 1 "build/alignsem-raw-first/transport-shift-right/input.c"
                                                x
# 1 "build/alignsem-raw-first/transport-shift-right/input.c"
                                                 ;
# 1 "build/alignsem-raw-first/transport-shift-right/input.c"
                                                   Up
# 1 "build/alignsem-raw-first/transport-shift-right/input.c"
                                                      f
# 1 "build/alignsem-raw-first/transport-shift-right/input.c"
                                                       (
# 1 "build/alignsem-raw-first/transport-shift-right/input.c"
                                                        void
# 1 "build/alignsem-raw-first/transport-shift-right/input.c"
                                                            )
# 1 "build/alignsem-raw-first/transport-shift-right/input.c"
                                                             {
# 1 "build/alignsem-raw-first/transport-shift-right/input.c"
                                                              return
# 1 "build/alignsem-raw-first/transport-shift-right/input.c"
                                                                     0
# 1 "build/alignsem-raw-first/transport-shift-right/input.c"
                                                                      ;
# 1 "build/alignsem-raw-first/transport-shift-right/input.c"
                                                                       }
# 2 "build/alignsem-raw-first/transport-shift-right/input.c"
int
# 2 "build/alignsem-raw-first/transport-shift-right/input.c"
    main
# 2 "build/alignsem-raw-first/transport-shift-right/input.c"
        (
# 2 "build/alignsem-raw-first/transport-shift-right/input.c"
         void
# 2 "build/alignsem-raw-first/transport-shift-right/input.c"
             )
# 2 "build/alignsem-raw-first/transport-shift-right/input.c"
              {
# 2 "build/alignsem-raw-first/transport-shift-right/input.c"
               return
# 2 "build/alignsem-raw-first/transport-shift-right/input.c"
                      _Alignof
# 2 "build/alignsem-raw-first/transport-shift-right/input.c"
                              (
# 2 "build/alignsem-raw-first/transport-shift-right/input.c"
                               __typeof__
# 2 "build/alignsem-raw-first/transport-shift-right/input.c"
                                         (
# 2 "build/alignsem-raw-first/transport-shift-right/input.c"
                                          x
# 2 "build/alignsem-raw-first/transport-shift-right/input.c"
                                           >>
# 2 "build/alignsem-raw-first/transport-shift-right/input.c"
                                             1
# 2 "build/alignsem-raw-first/transport-shift-right/input.c"
                                              )
# 2 "build/alignsem-raw-first/transport-shift-right/input.c"
                                               )
# 2 "build/alignsem-raw-first/transport-shift-right/input.c"
                                                !=
# 2 "build/alignsem-raw-first/transport-shift-right/input.c"
                                                  16
# 2 "build/alignsem-raw-first/transport-shift-right/input.c"
                                                    ;
# 2 "build/alignsem-raw-first/transport-shift-right/input.c"
                                                     }

