# 1 "build/alignsem-raw-first/weaker/input.c"
typedef
# 1 "build/alignsem-raw-first/weaker/input.c"
        int
# 1 "build/alignsem-raw-first/weaker/input.c"
            Up
# 1 "build/alignsem-raw-first/weaker/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/weaker/input.c"
                            (
# 1 "build/alignsem-raw-first/weaker/input.c"
                             (
# 1 "build/alignsem-raw-first/weaker/input.c"
                              aligned
# 1 "build/alignsem-raw-first/weaker/input.c"
                                     (
# 1 "build/alignsem-raw-first/weaker/input.c"
                                      16
# 1 "build/alignsem-raw-first/weaker/input.c"
                                        )
# 1 "build/alignsem-raw-first/weaker/input.c"
                                         )
# 1 "build/alignsem-raw-first/weaker/input.c"
                                          )
# 1 "build/alignsem-raw-first/weaker/input.c"
                                           ;
# 2 "build/alignsem-raw-first/weaker/input.c"
typedef
# 2 "build/alignsem-raw-first/weaker/input.c"
        int
# 2 "build/alignsem-raw-first/weaker/input.c"
            Down
# 2 "build/alignsem-raw-first/weaker/input.c"
                 __attribute__
# 2 "build/alignsem-raw-first/weaker/input.c"
                              (
# 2 "build/alignsem-raw-first/weaker/input.c"
                               (
# 2 "build/alignsem-raw-first/weaker/input.c"
                                aligned
# 2 "build/alignsem-raw-first/weaker/input.c"
                                       (
# 2 "build/alignsem-raw-first/weaker/input.c"
                                        1
# 2 "build/alignsem-raw-first/weaker/input.c"
                                         )
# 2 "build/alignsem-raw-first/weaker/input.c"
                                          )
# 2 "build/alignsem-raw-first/weaker/input.c"
                                           )
# 2 "build/alignsem-raw-first/weaker/input.c"
                                            ;
# 3 "build/alignsem-raw-first/weaker/input.c"
typedef
# 3 "build/alignsem-raw-first/weaker/input.c"
        Up
# 3 "build/alignsem-raw-first/weaker/input.c"
           Again
# 3 "build/alignsem-raw-first/weaker/input.c"
                ;
# 4 "build/alignsem-raw-first/weaker/input.c"
typedef
# 4 "build/alignsem-raw-first/weaker/input.c"
        Again
# 4 "build/alignsem-raw-first/weaker/input.c"
              Weak
# 4 "build/alignsem-raw-first/weaker/input.c"
                   __attribute__
# 4 "build/alignsem-raw-first/weaker/input.c"
                                (
# 4 "build/alignsem-raw-first/weaker/input.c"
                                 (
# 4 "build/alignsem-raw-first/weaker/input.c"
                                  aligned
# 4 "build/alignsem-raw-first/weaker/input.c"
                                         (
# 4 "build/alignsem-raw-first/weaker/input.c"
                                          2
# 4 "build/alignsem-raw-first/weaker/input.c"
                                           )
# 4 "build/alignsem-raw-first/weaker/input.c"
                                            )
# 4 "build/alignsem-raw-first/weaker/input.c"
                                             )
# 4 "build/alignsem-raw-first/weaker/input.c"
                                              ;
# 4 "build/alignsem-raw-first/weaker/input.c"
                                                typedef
# 4 "build/alignsem-raw-first/weaker/input.c"
                                                        Weak
# 4 "build/alignsem-raw-first/weaker/input.c"
                                                             W
# 4 "build/alignsem-raw-first/weaker/input.c"
                                                              ;
# 5 "build/alignsem-raw-first/weaker/input.c"
int
# 5 "build/alignsem-raw-first/weaker/input.c"
    main
# 5 "build/alignsem-raw-first/weaker/input.c"
        (
# 5 "build/alignsem-raw-first/weaker/input.c"
         void
# 5 "build/alignsem-raw-first/weaker/input.c"
             )
# 5 "build/alignsem-raw-first/weaker/input.c"
              {
# 5 "build/alignsem-raw-first/weaker/input.c"
               return
# 5 "build/alignsem-raw-first/weaker/input.c"
                      (
# 5 "build/alignsem-raw-first/weaker/input.c"
                       _Alignof
# 5 "build/alignsem-raw-first/weaker/input.c"
                               (
# 5 "build/alignsem-raw-first/weaker/input.c"
                                W
# 5 "build/alignsem-raw-first/weaker/input.c"
                                 )
# 5 "build/alignsem-raw-first/weaker/input.c"
                                  !=
# 5 "build/alignsem-raw-first/weaker/input.c"
                                    2
# 5 "build/alignsem-raw-first/weaker/input.c"
                                      ||
# 5 "build/alignsem-raw-first/weaker/input.c"
                                         sizeof
# 5 "build/alignsem-raw-first/weaker/input.c"
                                               (
# 5 "build/alignsem-raw-first/weaker/input.c"
                                                W
# 5 "build/alignsem-raw-first/weaker/input.c"
                                                 )
# 5 "build/alignsem-raw-first/weaker/input.c"
                                                  !=
# 5 "build/alignsem-raw-first/weaker/input.c"
                                                    4
# 5 "build/alignsem-raw-first/weaker/input.c"
                                                      ||
# 5 "build/alignsem-raw-first/weaker/input.c"
                                                         _Alignof
# 5 "build/alignsem-raw-first/weaker/input.c"
                                                                 (
# 5 "build/alignsem-raw-first/weaker/input.c"
                                                                  Up
# 5 "build/alignsem-raw-first/weaker/input.c"
                                                                    )
# 5 "build/alignsem-raw-first/weaker/input.c"
                                                                     !=
# 5 "build/alignsem-raw-first/weaker/input.c"
                                                                       16
# 5 "build/alignsem-raw-first/weaker/input.c"
                                                                         )
# 5 "build/alignsem-raw-first/weaker/input.c"
                                                                          ;
# 5 "build/alignsem-raw-first/weaker/input.c"
                                                                           }

