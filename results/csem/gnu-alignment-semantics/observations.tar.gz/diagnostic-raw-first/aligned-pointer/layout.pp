# 1 "build/alignsem-raw-first/aligned-pointer/input.c"
typedef
# 1 "build/alignsem-raw-first/aligned-pointer/input.c"
        int
# 1 "build/alignsem-raw-first/aligned-pointer/input.c"
            Up
# 1 "build/alignsem-raw-first/aligned-pointer/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/aligned-pointer/input.c"
                            (
# 1 "build/alignsem-raw-first/aligned-pointer/input.c"
                             (
# 1 "build/alignsem-raw-first/aligned-pointer/input.c"
                              aligned
# 1 "build/alignsem-raw-first/aligned-pointer/input.c"
                                     (
# 1 "build/alignsem-raw-first/aligned-pointer/input.c"
                                      16
# 1 "build/alignsem-raw-first/aligned-pointer/input.c"
                                        )
# 1 "build/alignsem-raw-first/aligned-pointer/input.c"
                                         )
# 1 "build/alignsem-raw-first/aligned-pointer/input.c"
                                          )
# 1 "build/alignsem-raw-first/aligned-pointer/input.c"
                                           ;
# 2 "build/alignsem-raw-first/aligned-pointer/input.c"
typedef
# 2 "build/alignsem-raw-first/aligned-pointer/input.c"
        int
# 2 "build/alignsem-raw-first/aligned-pointer/input.c"
            Down
# 2 "build/alignsem-raw-first/aligned-pointer/input.c"
                 __attribute__
# 2 "build/alignsem-raw-first/aligned-pointer/input.c"
                              (
# 2 "build/alignsem-raw-first/aligned-pointer/input.c"
                               (
# 2 "build/alignsem-raw-first/aligned-pointer/input.c"
                                aligned
# 2 "build/alignsem-raw-first/aligned-pointer/input.c"
                                       (
# 2 "build/alignsem-raw-first/aligned-pointer/input.c"
                                        1
# 2 "build/alignsem-raw-first/aligned-pointer/input.c"
                                         )
# 2 "build/alignsem-raw-first/aligned-pointer/input.c"
                                          )
# 2 "build/alignsem-raw-first/aligned-pointer/input.c"
                                           )
# 2 "build/alignsem-raw-first/aligned-pointer/input.c"
                                            ;
# 3 "build/alignsem-raw-first/aligned-pointer/input.c"
typedef
# 3 "build/alignsem-raw-first/aligned-pointer/input.c"
        Up
# 3 "build/alignsem-raw-first/aligned-pointer/input.c"
           Again
# 3 "build/alignsem-raw-first/aligned-pointer/input.c"
                ;
# 4 "build/alignsem-raw-first/aligned-pointer/input.c"
typedef
# 4 "build/alignsem-raw-first/aligned-pointer/input.c"
        Up
# 4 "build/alignsem-raw-first/aligned-pointer/input.c"
           *
# 4 "build/alignsem-raw-first/aligned-pointer/input.c"
            P
# 4 "build/alignsem-raw-first/aligned-pointer/input.c"
              __attribute__
# 4 "build/alignsem-raw-first/aligned-pointer/input.c"
                           (
# 4 "build/alignsem-raw-first/aligned-pointer/input.c"
                            (
# 4 "build/alignsem-raw-first/aligned-pointer/input.c"
                             aligned
# 4 "build/alignsem-raw-first/aligned-pointer/input.c"
                                    (
# 4 "build/alignsem-raw-first/aligned-pointer/input.c"
                                     32
# 4 "build/alignsem-raw-first/aligned-pointer/input.c"
                                       )
# 4 "build/alignsem-raw-first/aligned-pointer/input.c"
                                        )
# 4 "build/alignsem-raw-first/aligned-pointer/input.c"
                                         )
# 4 "build/alignsem-raw-first/aligned-pointer/input.c"
                                          ;
# 4 "build/alignsem-raw-first/aligned-pointer/input.c"
                                            typedef
# 4 "build/alignsem-raw-first/aligned-pointer/input.c"
                                                    P
# 4 "build/alignsem-raw-first/aligned-pointer/input.c"
                                                      *
# 4 "build/alignsem-raw-first/aligned-pointer/input.c"
                                                       PP
# 4 "build/alignsem-raw-first/aligned-pointer/input.c"
                                                         ;
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
int
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
    main
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
        (
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
         void
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
             )
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
              {
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
               return
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                      (
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                       _Alignof
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                               (
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                P
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                 )
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                  !=
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                    32
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                       ||
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                          _Alignof
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                                  (
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                                   PP
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                                     )
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                                      !=
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                                        sizeof
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                                              (
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                                               void
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                                                   *
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                                                    )
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                                                      ||
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                                                         sizeof
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                                                               (
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                                                                P
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                                                                 )
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                                                                  !=
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                                                                    sizeof
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                                                                          (
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                                                                           void
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                                                                               *
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                                                                                )
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                                                                                 )
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                                                                                  ;
# 5 "build/alignsem-raw-first/aligned-pointer/input.c"
                                                                                                   }

