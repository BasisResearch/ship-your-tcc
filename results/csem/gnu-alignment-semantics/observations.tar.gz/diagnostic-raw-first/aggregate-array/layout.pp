# 1 "build/alignsem-raw-first/aggregate-array/input.c"
typedef
# 1 "build/alignsem-raw-first/aggregate-array/input.c"
        struct
# 1 "build/alignsem-raw-first/aggregate-array/input.c"
               {
# 1 "build/alignsem-raw-first/aggregate-array/input.c"
                 long
# 1 "build/alignsem-raw-first/aggregate-array/input.c"
                      a
# 1 "build/alignsem-raw-first/aggregate-array/input.c"
                       ,
# 1 "build/alignsem-raw-first/aggregate-array/input.c"
                        b
# 1 "build/alignsem-raw-first/aggregate-array/input.c"
                         ;
# 1 "build/alignsem-raw-first/aggregate-array/input.c"
                           }
# 1 "build/alignsem-raw-first/aggregate-array/input.c"
                             Wide
# 1 "build/alignsem-raw-first/aggregate-array/input.c"
                                  __attribute__
# 1 "build/alignsem-raw-first/aggregate-array/input.c"
                                               (
# 1 "build/alignsem-raw-first/aggregate-array/input.c"
                                                (
# 1 "build/alignsem-raw-first/aggregate-array/input.c"
                                                 aligned
# 1 "build/alignsem-raw-first/aggregate-array/input.c"
                                                        (
# 1 "build/alignsem-raw-first/aggregate-array/input.c"
                                                         16
# 1 "build/alignsem-raw-first/aggregate-array/input.c"
                                                           )
# 1 "build/alignsem-raw-first/aggregate-array/input.c"
                                                            )
# 1 "build/alignsem-raw-first/aggregate-array/input.c"
                                                             )
# 1 "build/alignsem-raw-first/aggregate-array/input.c"
                                                              ;
# 1 "build/alignsem-raw-first/aggregate-array/input.c"
                                                                typedef
# 1 "build/alignsem-raw-first/aggregate-array/input.c"
                                                                        Wide
# 1 "build/alignsem-raw-first/aggregate-array/input.c"
                                                                             A
# 1 "build/alignsem-raw-first/aggregate-array/input.c"
                                                                              [
# 1 "build/alignsem-raw-first/aggregate-array/input.c"
                                                                               2
# 1 "build/alignsem-raw-first/aggregate-array/input.c"
                                                                                ]
# 1 "build/alignsem-raw-first/aggregate-array/input.c"
                                                                                 ;
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
int
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
    main
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
        (
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
         void
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
             )
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
              {
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
               return
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
                      (
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
                       _Alignof
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
                               (
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
                                A
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
                                 )
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
                                  !=
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
                                    16
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
                                       ||
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
                                          sizeof
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
                                                (
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
                                                 A
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
                                                  )
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
                                                   !=
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
                                                     32
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
                                                        ||
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
                                                           _Alignof
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
                                                                   (
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
                                                                    Wide
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
                                                                        )
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
                                                                         !=
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
                                                                           16
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
                                                                             )
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
                                                                              ;
# 2 "build/alignsem-raw-first/aggregate-array/input.c"
                                                                               }

