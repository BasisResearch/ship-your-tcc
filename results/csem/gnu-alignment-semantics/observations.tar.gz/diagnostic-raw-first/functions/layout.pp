# 1 "build/alignsem-raw-first/functions/input.c"
typedef
# 1 "build/alignsem-raw-first/functions/input.c"
        int
# 1 "build/alignsem-raw-first/functions/input.c"
            Up
# 1 "build/alignsem-raw-first/functions/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/functions/input.c"
                            (
# 1 "build/alignsem-raw-first/functions/input.c"
                             (
# 1 "build/alignsem-raw-first/functions/input.c"
                              aligned
# 1 "build/alignsem-raw-first/functions/input.c"
                                     (
# 1 "build/alignsem-raw-first/functions/input.c"
                                      16
# 1 "build/alignsem-raw-first/functions/input.c"
                                        )
# 1 "build/alignsem-raw-first/functions/input.c"
                                         )
# 1 "build/alignsem-raw-first/functions/input.c"
                                          )
# 1 "build/alignsem-raw-first/functions/input.c"
                                           ;
# 2 "build/alignsem-raw-first/functions/input.c"
typedef
# 2 "build/alignsem-raw-first/functions/input.c"
        int
# 2 "build/alignsem-raw-first/functions/input.c"
            Down
# 2 "build/alignsem-raw-first/functions/input.c"
                 __attribute__
# 2 "build/alignsem-raw-first/functions/input.c"
                              (
# 2 "build/alignsem-raw-first/functions/input.c"
                               (
# 2 "build/alignsem-raw-first/functions/input.c"
                                aligned
# 2 "build/alignsem-raw-first/functions/input.c"
                                       (
# 2 "build/alignsem-raw-first/functions/input.c"
                                        1
# 2 "build/alignsem-raw-first/functions/input.c"
                                         )
# 2 "build/alignsem-raw-first/functions/input.c"
                                          )
# 2 "build/alignsem-raw-first/functions/input.c"
                                           )
# 2 "build/alignsem-raw-first/functions/input.c"
                                            ;
# 3 "build/alignsem-raw-first/functions/input.c"
typedef
# 3 "build/alignsem-raw-first/functions/input.c"
        Up
# 3 "build/alignsem-raw-first/functions/input.c"
           Again
# 3 "build/alignsem-raw-first/functions/input.c"
                ;
# 4 "build/alignsem-raw-first/functions/input.c"
typedef
# 4 "build/alignsem-raw-first/functions/input.c"
        Up
# 4 "build/alignsem-raw-first/functions/input.c"
           F
# 4 "build/alignsem-raw-first/functions/input.c"
            (
# 4 "build/alignsem-raw-first/functions/input.c"
             void
# 4 "build/alignsem-raw-first/functions/input.c"
                 )
# 4 "build/alignsem-raw-first/functions/input.c"
                  ;
# 4 "build/alignsem-raw-first/functions/input.c"
                    typedef
# 4 "build/alignsem-raw-first/functions/input.c"
                            F
# 4 "build/alignsem-raw-first/functions/input.c"
                              *
# 4 "build/alignsem-raw-first/functions/input.c"
                               FP
# 4 "build/alignsem-raw-first/functions/input.c"
                                 ;
# 4 "build/alignsem-raw-first/functions/input.c"
                                   Up
# 4 "build/alignsem-raw-first/functions/input.c"
                                      fun
# 4 "build/alignsem-raw-first/functions/input.c"
                                         (
# 4 "build/alignsem-raw-first/functions/input.c"
                                          void
# 4 "build/alignsem-raw-first/functions/input.c"
                                              )
# 4 "build/alignsem-raw-first/functions/input.c"
                                               {
# 4 "build/alignsem-raw-first/functions/input.c"
                                                return
# 4 "build/alignsem-raw-first/functions/input.c"
                                                       7
# 4 "build/alignsem-raw-first/functions/input.c"
                                                        ;
# 4 "build/alignsem-raw-first/functions/input.c"
                                                         }
# 5 "build/alignsem-raw-first/functions/input.c"
int
# 5 "build/alignsem-raw-first/functions/input.c"
    main
# 5 "build/alignsem-raw-first/functions/input.c"
        (
# 5 "build/alignsem-raw-first/functions/input.c"
         void
# 5 "build/alignsem-raw-first/functions/input.c"
             )
# 5 "build/alignsem-raw-first/functions/input.c"
              {
# 5 "build/alignsem-raw-first/functions/input.c"
               return
# 5 "build/alignsem-raw-first/functions/input.c"
                      (
# 5 "build/alignsem-raw-first/functions/input.c"
                       _Alignof
# 5 "build/alignsem-raw-first/functions/input.c"
                               (
# 5 "build/alignsem-raw-first/functions/input.c"
                                F
# 5 "build/alignsem-raw-first/functions/input.c"
                                 )
# 5 "build/alignsem-raw-first/functions/input.c"
                                  !=
# 5 "build/alignsem-raw-first/functions/input.c"
                                    _Alignof
# 5 "build/alignsem-raw-first/functions/input.c"
                                            (
# 5 "build/alignsem-raw-first/functions/input.c"
                                             int
# 5 "build/alignsem-raw-first/functions/input.c"
                                                (
# 5 "build/alignsem-raw-first/functions/input.c"
                                                 void
# 5 "build/alignsem-raw-first/functions/input.c"
                                                     )
# 5 "build/alignsem-raw-first/functions/input.c"
                                                      )
# 5 "build/alignsem-raw-first/functions/input.c"
                                                        ||
# 5 "build/alignsem-raw-first/functions/input.c"
                                                           _Alignof
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                   (
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                    FP
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                      )
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                       !=
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                         sizeof
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                               (
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                void
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                    *
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                     )
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                       ||
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                          sizeof
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                (
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                 FP
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                   )
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                    !=
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                      sizeof
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                            (
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                             void
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                                 *
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                                  )
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                                    ||
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                                       _Alignof
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                                               (
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                                                __typeof__
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                                                          (
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                                                           fun
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                                                              (
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                                                               )
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                                                                )
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                                                                 )
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                                                                  !=
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                                                                    16
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                                                                       ||
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                                                                          fun
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                                                                             (
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                                                                              )
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                                                                               !=
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                                                                                 7
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                                                                                  )
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                                                                                   ;
# 5 "build/alignsem-raw-first/functions/input.c"
                                                                                                                                                                    }

