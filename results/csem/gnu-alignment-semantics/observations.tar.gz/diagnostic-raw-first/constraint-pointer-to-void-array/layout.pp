# 1 "build/alignsem-raw-first/constraint-pointer-to-void-array/input.c"
typedef
# 1 "build/alignsem-raw-first/constraint-pointer-to-void-array/input.c"
        void
# 1 "build/alignsem-raw-first/constraint-pointer-to-void-array/input.c"
             V
# 1 "build/alignsem-raw-first/constraint-pointer-to-void-array/input.c"
              ;
# 1 "build/alignsem-raw-first/constraint-pointer-to-void-array/input.c"
                typedef
# 1 "build/alignsem-raw-first/constraint-pointer-to-void-array/input.c"
                        V
# 1 "build/alignsem-raw-first/constraint-pointer-to-void-array/input.c"
                          (
# 1 "build/alignsem-raw-first/constraint-pointer-to-void-array/input.c"
                           *
# 1 "build/alignsem-raw-first/constraint-pointer-to-void-array/input.c"
                            P
# 1 "build/alignsem-raw-first/constraint-pointer-to-void-array/input.c"
                             )
# 1 "build/alignsem-raw-first/constraint-pointer-to-void-array/input.c"
                              [
# 1 "build/alignsem-raw-first/constraint-pointer-to-void-array/input.c"
                               1
# 1 "build/alignsem-raw-first/constraint-pointer-to-void-array/input.c"
                                ]
# 1 "build/alignsem-raw-first/constraint-pointer-to-void-array/input.c"
                                 ;
# 1 "build/alignsem-raw-first/constraint-pointer-to-void-array/input.c"
                                   int
# 1 "build/alignsem-raw-first/constraint-pointer-to-void-array/input.c"
                                       main
# 1 "build/alignsem-raw-first/constraint-pointer-to-void-array/input.c"
                                           (
# 1 "build/alignsem-raw-first/constraint-pointer-to-void-array/input.c"
                                            void
# 1 "build/alignsem-raw-first/constraint-pointer-to-void-array/input.c"
                                                )
# 1 "build/alignsem-raw-first/constraint-pointer-to-void-array/input.c"
                                                 {
# 1 "build/alignsem-raw-first/constraint-pointer-to-void-array/input.c"
                                                  return
# 1 "build/alignsem-raw-first/constraint-pointer-to-void-array/input.c"
                                                         0
# 1 "build/alignsem-raw-first/constraint-pointer-to-void-array/input.c"
                                                          ;
# 1 "build/alignsem-raw-first/constraint-pointer-to-void-array/input.c"
                                                           }

