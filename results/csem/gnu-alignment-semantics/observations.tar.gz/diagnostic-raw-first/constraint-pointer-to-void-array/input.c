typedef void V; typedef V (*P)[1]; int main(void){return 0;}
