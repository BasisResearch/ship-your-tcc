# 1 "build/alignsem-raw-first/array-void-array-local/input.c"
int
# 1 "build/alignsem-raw-first/array-void-array-local/input.c"
    main
# 1 "build/alignsem-raw-first/array-void-array-local/input.c"
        (
# 1 "build/alignsem-raw-first/array-void-array-local/input.c"
         void
# 1 "build/alignsem-raw-first/array-void-array-local/input.c"
             )
# 1 "build/alignsem-raw-first/array-void-array-local/input.c"
              {
# 1 "build/alignsem-raw-first/array-void-array-local/input.c"
               void
# 1 "build/alignsem-raw-first/array-void-array-local/input.c"
                    a
# 1 "build/alignsem-raw-first/array-void-array-local/input.c"
                     [
# 1 "build/alignsem-raw-first/array-void-array-local/input.c"
                      1
# 1 "build/alignsem-raw-first/array-void-array-local/input.c"
                       ]
# 1 "build/alignsem-raw-first/array-void-array-local/input.c"
                        ;
# 1 "build/alignsem-raw-first/array-void-array-local/input.c"
                         return
# 1 "build/alignsem-raw-first/array-void-array-local/input.c"
                                0
# 1 "build/alignsem-raw-first/array-void-array-local/input.c"
                                 ;
# 1 "build/alignsem-raw-first/array-void-array-local/input.c"
                                  }

