# 1 "build/alignsem-raw-first/chain/input.c"
typedef
# 1 "build/alignsem-raw-first/chain/input.c"
        int
# 1 "build/alignsem-raw-first/chain/input.c"
            Up
# 1 "build/alignsem-raw-first/chain/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/chain/input.c"
                            (
# 1 "build/alignsem-raw-first/chain/input.c"
                             (
# 1 "build/alignsem-raw-first/chain/input.c"
                              aligned
# 1 "build/alignsem-raw-first/chain/input.c"
                                     (
# 1 "build/alignsem-raw-first/chain/input.c"
                                      16
# 1 "build/alignsem-raw-first/chain/input.c"
                                        )
# 1 "build/alignsem-raw-first/chain/input.c"
                                         )
# 1 "build/alignsem-raw-first/chain/input.c"
                                          )
# 1 "build/alignsem-raw-first/chain/input.c"
                                           ;
# 2 "build/alignsem-raw-first/chain/input.c"
typedef
# 2 "build/alignsem-raw-first/chain/input.c"
        int
# 2 "build/alignsem-raw-first/chain/input.c"
            Down
# 2 "build/alignsem-raw-first/chain/input.c"
                 __attribute__
# 2 "build/alignsem-raw-first/chain/input.c"
                              (
# 2 "build/alignsem-raw-first/chain/input.c"
                               (
# 2 "build/alignsem-raw-first/chain/input.c"
                                aligned
# 2 "build/alignsem-raw-first/chain/input.c"
                                       (
# 2 "build/alignsem-raw-first/chain/input.c"
                                        1
# 2 "build/alignsem-raw-first/chain/input.c"
                                         )
# 2 "build/alignsem-raw-first/chain/input.c"
                                          )
# 2 "build/alignsem-raw-first/chain/input.c"
                                           )
# 2 "build/alignsem-raw-first/chain/input.c"
                                            ;
# 3 "build/alignsem-raw-first/chain/input.c"
typedef
# 3 "build/alignsem-raw-first/chain/input.c"
        Up
# 3 "build/alignsem-raw-first/chain/input.c"
           Again
# 3 "build/alignsem-raw-first/chain/input.c"
                ;
# 4 "build/alignsem-raw-first/chain/input.c"
typedef
# 4 "build/alignsem-raw-first/chain/input.c"
        Again
# 4 "build/alignsem-raw-first/chain/input.c"
              Third
# 4 "build/alignsem-raw-first/chain/input.c"
                   ;
# 4 "build/alignsem-raw-first/chain/input.c"
                     typedef
# 4 "build/alignsem-raw-first/chain/input.c"
                             Third
# 4 "build/alignsem-raw-first/chain/input.c"
                                   Fourth
# 4 "build/alignsem-raw-first/chain/input.c"
                                         ;
# 5 "build/alignsem-raw-first/chain/input.c"
int
# 5 "build/alignsem-raw-first/chain/input.c"
    main
# 5 "build/alignsem-raw-first/chain/input.c"
        (
# 5 "build/alignsem-raw-first/chain/input.c"
         void
# 5 "build/alignsem-raw-first/chain/input.c"
             )
# 5 "build/alignsem-raw-first/chain/input.c"
              {
# 5 "build/alignsem-raw-first/chain/input.c"
               return
# 5 "build/alignsem-raw-first/chain/input.c"
                      (
# 5 "build/alignsem-raw-first/chain/input.c"
                       _Alignof
# 5 "build/alignsem-raw-first/chain/input.c"
                               (
# 5 "build/alignsem-raw-first/chain/input.c"
                                Fourth
# 5 "build/alignsem-raw-first/chain/input.c"
                                      )
# 5 "build/alignsem-raw-first/chain/input.c"
                                       !=
# 5 "build/alignsem-raw-first/chain/input.c"
                                         16
# 5 "build/alignsem-raw-first/chain/input.c"
                                            ||
# 5 "build/alignsem-raw-first/chain/input.c"
                                               sizeof
# 5 "build/alignsem-raw-first/chain/input.c"
                                                     (
# 5 "build/alignsem-raw-first/chain/input.c"
                                                      Fourth
# 5 "build/alignsem-raw-first/chain/input.c"
                                                            )
# 5 "build/alignsem-raw-first/chain/input.c"
                                                             !=
# 5 "build/alignsem-raw-first/chain/input.c"
                                                               4
# 5 "build/alignsem-raw-first/chain/input.c"
                                                                )
# 5 "build/alignsem-raw-first/chain/input.c"
                                                                 ;
# 5 "build/alignsem-raw-first/chain/input.c"
                                                                  }

