# 1 "build/alignsem-raw-first/expression-address/input.c"
typedef
# 1 "build/alignsem-raw-first/expression-address/input.c"
        int
# 1 "build/alignsem-raw-first/expression-address/input.c"
            Up
# 1 "build/alignsem-raw-first/expression-address/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/expression-address/input.c"
                            (
# 1 "build/alignsem-raw-first/expression-address/input.c"
                             (
# 1 "build/alignsem-raw-first/expression-address/input.c"
                              aligned
# 1 "build/alignsem-raw-first/expression-address/input.c"
                                     (
# 1 "build/alignsem-raw-first/expression-address/input.c"
                                      16
# 1 "build/alignsem-raw-first/expression-address/input.c"
                                        )
# 1 "build/alignsem-raw-first/expression-address/input.c"
                                         )
# 1 "build/alignsem-raw-first/expression-address/input.c"
                                          )
# 1 "build/alignsem-raw-first/expression-address/input.c"
                                           ;
# 2 "build/alignsem-raw-first/expression-address/input.c"
typedef
# 2 "build/alignsem-raw-first/expression-address/input.c"
        int
# 2 "build/alignsem-raw-first/expression-address/input.c"
            Down
# 2 "build/alignsem-raw-first/expression-address/input.c"
                 __attribute__
# 2 "build/alignsem-raw-first/expression-address/input.c"
                              (
# 2 "build/alignsem-raw-first/expression-address/input.c"
                               (
# 2 "build/alignsem-raw-first/expression-address/input.c"
                                aligned
# 2 "build/alignsem-raw-first/expression-address/input.c"
                                       (
# 2 "build/alignsem-raw-first/expression-address/input.c"
                                        1
# 2 "build/alignsem-raw-first/expression-address/input.c"
                                         )
# 2 "build/alignsem-raw-first/expression-address/input.c"
                                          )
# 2 "build/alignsem-raw-first/expression-address/input.c"
                                           )
# 2 "build/alignsem-raw-first/expression-address/input.c"
                                            ;
# 3 "build/alignsem-raw-first/expression-address/input.c"
typedef
# 3 "build/alignsem-raw-first/expression-address/input.c"
        Up
# 3 "build/alignsem-raw-first/expression-address/input.c"
           Again
# 3 "build/alignsem-raw-first/expression-address/input.c"
                ;
# 4 "build/alignsem-raw-first/expression-address/input.c"
Up
# 4 "build/alignsem-raw-first/expression-address/input.c"
   x
# 4 "build/alignsem-raw-first/expression-address/input.c"
    ;
# 4 "build/alignsem-raw-first/expression-address/input.c"
      typedef
# 4 "build/alignsem-raw-first/expression-address/input.c"
              int
# 4 "build/alignsem-raw-first/expression-address/input.c"
                  *
# 4 "build/alignsem-raw-first/expression-address/input.c"
                   P
# 4 "build/alignsem-raw-first/expression-address/input.c"
                     __attribute__
# 4 "build/alignsem-raw-first/expression-address/input.c"
                                  (
# 4 "build/alignsem-raw-first/expression-address/input.c"
                                   (
# 4 "build/alignsem-raw-first/expression-address/input.c"
                                    aligned
# 4 "build/alignsem-raw-first/expression-address/input.c"
                                           (
# 4 "build/alignsem-raw-first/expression-address/input.c"
                                            32
# 4 "build/alignsem-raw-first/expression-address/input.c"
                                              )
# 4 "build/alignsem-raw-first/expression-address/input.c"
                                               )
# 4 "build/alignsem-raw-first/expression-address/input.c"
                                                )
# 4 "build/alignsem-raw-first/expression-address/input.c"
                                                 ;
# 4 "build/alignsem-raw-first/expression-address/input.c"
                                                   P
# 4 "build/alignsem-raw-first/expression-address/input.c"
                                                     p
# 4 "build/alignsem-raw-first/expression-address/input.c"
                                                      ;
# 5 "build/alignsem-raw-first/expression-address/input.c"
int
# 5 "build/alignsem-raw-first/expression-address/input.c"
    main
# 5 "build/alignsem-raw-first/expression-address/input.c"
        (
# 5 "build/alignsem-raw-first/expression-address/input.c"
         void
# 5 "build/alignsem-raw-first/expression-address/input.c"
             )
# 5 "build/alignsem-raw-first/expression-address/input.c"
              {
# 5 "build/alignsem-raw-first/expression-address/input.c"
               return
# 5 "build/alignsem-raw-first/expression-address/input.c"
                      (
# 5 "build/alignsem-raw-first/expression-address/input.c"
                       __alignof__
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                  (
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                   &
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                    x
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                     )
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                      !=
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                        sizeof
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                              (
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                               void
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                   *
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                    )
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                      ||
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                         __alignof__
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                    (
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                     &
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                      p
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                       )
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                        !=
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                          sizeof
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                (
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                 void
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                     *
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                      )
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                        ||
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                           __alignof__
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                                      (
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                                       (
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                                        int
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                                           )
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                                            x
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                                             )
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                                              !=
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                                                4
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                                                  ||
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                                                     _Alignof
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                                                             (
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                                                              __typeof__
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                                                                        (
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                                                                         &
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                                                                          x
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                                                                           )
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                                                                            )
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                                                                             !=
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                                                                               sizeof
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                                                                                     (
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                                                                                      void
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                                                                                          *
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                                                                                           )
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                                                                                            )
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                                                                                             ;
# 5 "build/alignsem-raw-first/expression-address/input.c"
                                                                                                                                                              }

