# 1 "build/alignsem-raw-first/array-incomplete-extern/input.c"
extern
# 1 "build/alignsem-raw-first/array-incomplete-extern/input.c"
       int
# 1 "build/alignsem-raw-first/array-incomplete-extern/input.c"
           a
# 1 "build/alignsem-raw-first/array-incomplete-extern/input.c"
            [
# 1 "build/alignsem-raw-first/array-incomplete-extern/input.c"
             ]
# 1 "build/alignsem-raw-first/array-incomplete-extern/input.c"
              ;
# 1 "build/alignsem-raw-first/array-incomplete-extern/input.c"
                int
# 1 "build/alignsem-raw-first/array-incomplete-extern/input.c"
                    main
# 1 "build/alignsem-raw-first/array-incomplete-extern/input.c"
                        (
# 1 "build/alignsem-raw-first/array-incomplete-extern/input.c"
                         void
# 1 "build/alignsem-raw-first/array-incomplete-extern/input.c"
                             )
# 1 "build/alignsem-raw-first/array-incomplete-extern/input.c"
                              {
# 1 "build/alignsem-raw-first/array-incomplete-extern/input.c"
                               return
# 1 "build/alignsem-raw-first/array-incomplete-extern/input.c"
                                      0
# 1 "build/alignsem-raw-first/array-incomplete-extern/input.c"
                                       ;
# 1 "build/alignsem-raw-first/array-incomplete-extern/input.c"
                                        }

