# 1 "build/alignsem-raw-first/array-pointer/input.c"
typedef
# 1 "build/alignsem-raw-first/array-pointer/input.c"
        int
# 1 "build/alignsem-raw-first/array-pointer/input.c"
            Up
# 1 "build/alignsem-raw-first/array-pointer/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/array-pointer/input.c"
                            (
# 1 "build/alignsem-raw-first/array-pointer/input.c"
                             (
# 1 "build/alignsem-raw-first/array-pointer/input.c"
                              aligned
# 1 "build/alignsem-raw-first/array-pointer/input.c"
                                     (
# 1 "build/alignsem-raw-first/array-pointer/input.c"
                                      16
# 1 "build/alignsem-raw-first/array-pointer/input.c"
                                        )
# 1 "build/alignsem-raw-first/array-pointer/input.c"
                                         )
# 1 "build/alignsem-raw-first/array-pointer/input.c"
                                          )
# 1 "build/alignsem-raw-first/array-pointer/input.c"
                                           ;
# 2 "build/alignsem-raw-first/array-pointer/input.c"
typedef
# 2 "build/alignsem-raw-first/array-pointer/input.c"
        int
# 2 "build/alignsem-raw-first/array-pointer/input.c"
            Down
# 2 "build/alignsem-raw-first/array-pointer/input.c"
                 __attribute__
# 2 "build/alignsem-raw-first/array-pointer/input.c"
                              (
# 2 "build/alignsem-raw-first/array-pointer/input.c"
                               (
# 2 "build/alignsem-raw-first/array-pointer/input.c"
                                aligned
# 2 "build/alignsem-raw-first/array-pointer/input.c"
                                       (
# 2 "build/alignsem-raw-first/array-pointer/input.c"
                                        1
# 2 "build/alignsem-raw-first/array-pointer/input.c"
                                         )
# 2 "build/alignsem-raw-first/array-pointer/input.c"
                                          )
# 2 "build/alignsem-raw-first/array-pointer/input.c"
                                           )
# 2 "build/alignsem-raw-first/array-pointer/input.c"
                                            ;
# 3 "build/alignsem-raw-first/array-pointer/input.c"
typedef
# 3 "build/alignsem-raw-first/array-pointer/input.c"
        Up
# 3 "build/alignsem-raw-first/array-pointer/input.c"
           Again
# 3 "build/alignsem-raw-first/array-pointer/input.c"
                ;
# 4 "build/alignsem-raw-first/array-pointer/input.c"
typedef
# 4 "build/alignsem-raw-first/array-pointer/input.c"
        Down
# 4 "build/alignsem-raw-first/array-pointer/input.c"
             A
# 4 "build/alignsem-raw-first/array-pointer/input.c"
              [
# 4 "build/alignsem-raw-first/array-pointer/input.c"
               3
# 4 "build/alignsem-raw-first/array-pointer/input.c"
                ]
# 4 "build/alignsem-raw-first/array-pointer/input.c"
                 ;
# 4 "build/alignsem-raw-first/array-pointer/input.c"
                   typedef
# 4 "build/alignsem-raw-first/array-pointer/input.c"
                           A
# 4 "build/alignsem-raw-first/array-pointer/input.c"
                             *
# 4 "build/alignsem-raw-first/array-pointer/input.c"
                              P
# 4 "build/alignsem-raw-first/array-pointer/input.c"
                               ;
# 4 "build/alignsem-raw-first/array-pointer/input.c"
                                 typedef
# 4 "build/alignsem-raw-first/array-pointer/input.c"
                                         Up
# 4 "build/alignsem-raw-first/array-pointer/input.c"
                                            *
# 4 "build/alignsem-raw-first/array-pointer/input.c"
                                             V
# 4 "build/alignsem-raw-first/array-pointer/input.c"
                                              [
# 4 "build/alignsem-raw-first/array-pointer/input.c"
                                               2
# 4 "build/alignsem-raw-first/array-pointer/input.c"
                                                ]
# 4 "build/alignsem-raw-first/array-pointer/input.c"
                                                 ;
# 5 "build/alignsem-raw-first/array-pointer/input.c"
int
# 5 "build/alignsem-raw-first/array-pointer/input.c"
    main
# 5 "build/alignsem-raw-first/array-pointer/input.c"
        (
# 5 "build/alignsem-raw-first/array-pointer/input.c"
         void
# 5 "build/alignsem-raw-first/array-pointer/input.c"
             )
# 5 "build/alignsem-raw-first/array-pointer/input.c"
              {
# 5 "build/alignsem-raw-first/array-pointer/input.c"
               return
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                      (
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                       _Alignof
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                               (
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                P
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                 )
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                  !=
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                    sizeof
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                          (
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                           void
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                               *
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                )
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                  ||
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                     _Alignof
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                             (
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                              V
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                               )
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                !=
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                  sizeof
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                        (
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                         void
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                             *
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                              )
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                ||
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                   _Alignof
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                           (
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                            Down
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                (
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                 *
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                  )
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                   [
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                    3
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                     ]
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                      )
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                       !=
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                         sizeof
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                               (
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                                void
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                                    *
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                                     )
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                                       ||
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                                          sizeof
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                                                (
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                                                 V
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                                                  )
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                                                   !=
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                                                     2
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                                                      *
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                                                       sizeof
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                                                             (
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                                                              void
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                                                                  *
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                                                                   )
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                                                                    )
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                                                                     ;
# 5 "build/alignsem-raw-first/array-pointer/input.c"
                                                                                                                                                      }

