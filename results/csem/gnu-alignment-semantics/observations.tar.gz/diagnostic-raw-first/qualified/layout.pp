# 1 "build/alignsem-raw-first/qualified/input.c"
typedef
# 1 "build/alignsem-raw-first/qualified/input.c"
        int
# 1 "build/alignsem-raw-first/qualified/input.c"
            Up
# 1 "build/alignsem-raw-first/qualified/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/qualified/input.c"
                            (
# 1 "build/alignsem-raw-first/qualified/input.c"
                             (
# 1 "build/alignsem-raw-first/qualified/input.c"
                              aligned
# 1 "build/alignsem-raw-first/qualified/input.c"
                                     (
# 1 "build/alignsem-raw-first/qualified/input.c"
                                      16
# 1 "build/alignsem-raw-first/qualified/input.c"
                                        )
# 1 "build/alignsem-raw-first/qualified/input.c"
                                         )
# 1 "build/alignsem-raw-first/qualified/input.c"
                                          )
# 1 "build/alignsem-raw-first/qualified/input.c"
                                           ;
# 2 "build/alignsem-raw-first/qualified/input.c"
typedef
# 2 "build/alignsem-raw-first/qualified/input.c"
        int
# 2 "build/alignsem-raw-first/qualified/input.c"
            Down
# 2 "build/alignsem-raw-first/qualified/input.c"
                 __attribute__
# 2 "build/alignsem-raw-first/qualified/input.c"
                              (
# 2 "build/alignsem-raw-first/qualified/input.c"
                               (
# 2 "build/alignsem-raw-first/qualified/input.c"
                                aligned
# 2 "build/alignsem-raw-first/qualified/input.c"
                                       (
# 2 "build/alignsem-raw-first/qualified/input.c"
                                        1
# 2 "build/alignsem-raw-first/qualified/input.c"
                                         )
# 2 "build/alignsem-raw-first/qualified/input.c"
                                          )
# 2 "build/alignsem-raw-first/qualified/input.c"
                                           )
# 2 "build/alignsem-raw-first/qualified/input.c"
                                            ;
# 3 "build/alignsem-raw-first/qualified/input.c"
typedef
# 3 "build/alignsem-raw-first/qualified/input.c"
        Up
# 3 "build/alignsem-raw-first/qualified/input.c"
           Again
# 3 "build/alignsem-raw-first/qualified/input.c"
                ;
# 4 "build/alignsem-raw-first/qualified/input.c"
typedef
# 4 "build/alignsem-raw-first/qualified/input.c"
        const
# 4 "build/alignsem-raw-first/qualified/input.c"
              Up
# 4 "build/alignsem-raw-first/qualified/input.c"
                 C
# 4 "build/alignsem-raw-first/qualified/input.c"
                  ;
# 4 "build/alignsem-raw-first/qualified/input.c"
                    typedef
# 4 "build/alignsem-raw-first/qualified/input.c"
                            volatile
# 4 "build/alignsem-raw-first/qualified/input.c"
                                     Down
# 4 "build/alignsem-raw-first/qualified/input.c"
                                          V
# 4 "build/alignsem-raw-first/qualified/input.c"
                                           ;
# 5 "build/alignsem-raw-first/qualified/input.c"
int
# 5 "build/alignsem-raw-first/qualified/input.c"
    main
# 5 "build/alignsem-raw-first/qualified/input.c"
        (
# 5 "build/alignsem-raw-first/qualified/input.c"
         void
# 5 "build/alignsem-raw-first/qualified/input.c"
             )
# 5 "build/alignsem-raw-first/qualified/input.c"
              {
# 5 "build/alignsem-raw-first/qualified/input.c"
               return
# 5 "build/alignsem-raw-first/qualified/input.c"
                      (
# 5 "build/alignsem-raw-first/qualified/input.c"
                       _Alignof
# 5 "build/alignsem-raw-first/qualified/input.c"
                               (
# 5 "build/alignsem-raw-first/qualified/input.c"
                                C
# 5 "build/alignsem-raw-first/qualified/input.c"
                                 )
# 5 "build/alignsem-raw-first/qualified/input.c"
                                  !=
# 5 "build/alignsem-raw-first/qualified/input.c"
                                    16
# 5 "build/alignsem-raw-first/qualified/input.c"
                                       ||
# 5 "build/alignsem-raw-first/qualified/input.c"
                                          _Alignof
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                  (
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                   V
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                    )
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                     !=
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                       1
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                         ||
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                            _Alignof
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                                    (
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                                     const
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                                           Again
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                                                )
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                                                 !=
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                                                   16
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                                                      ||
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                                                         _Alignof
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                                                                 (
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                                                                  volatile
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                                                                           Down
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                                                                               )
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                                                                                !=
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                                                                                  1
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                                                                                    ||
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                                                                                       sizeof
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                                                                                             (
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                                                                                              C
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                                                                                               )
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                                                                                                !=
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                                                                                                  4
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                                                                                                   )
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                                                                                                    ;
# 5 "build/alignsem-raw-first/qualified/input.c"
                                                                                                                                     }

