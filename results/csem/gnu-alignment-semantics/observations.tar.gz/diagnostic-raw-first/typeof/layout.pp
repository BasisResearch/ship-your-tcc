# 1 "build/alignsem-raw-first/typeof/input.c"
typedef
# 1 "build/alignsem-raw-first/typeof/input.c"
        int
# 1 "build/alignsem-raw-first/typeof/input.c"
            Up
# 1 "build/alignsem-raw-first/typeof/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/typeof/input.c"
                            (
# 1 "build/alignsem-raw-first/typeof/input.c"
                             (
# 1 "build/alignsem-raw-first/typeof/input.c"
                              aligned
# 1 "build/alignsem-raw-first/typeof/input.c"
                                     (
# 1 "build/alignsem-raw-first/typeof/input.c"
                                      16
# 1 "build/alignsem-raw-first/typeof/input.c"
                                        )
# 1 "build/alignsem-raw-first/typeof/input.c"
                                         )
# 1 "build/alignsem-raw-first/typeof/input.c"
                                          )
# 1 "build/alignsem-raw-first/typeof/input.c"
                                           ;
# 2 "build/alignsem-raw-first/typeof/input.c"
typedef
# 2 "build/alignsem-raw-first/typeof/input.c"
        int
# 2 "build/alignsem-raw-first/typeof/input.c"
            Down
# 2 "build/alignsem-raw-first/typeof/input.c"
                 __attribute__
# 2 "build/alignsem-raw-first/typeof/input.c"
                              (
# 2 "build/alignsem-raw-first/typeof/input.c"
                               (
# 2 "build/alignsem-raw-first/typeof/input.c"
                                aligned
# 2 "build/alignsem-raw-first/typeof/input.c"
                                       (
# 2 "build/alignsem-raw-first/typeof/input.c"
                                        1
# 2 "build/alignsem-raw-first/typeof/input.c"
                                         )
# 2 "build/alignsem-raw-first/typeof/input.c"
                                          )
# 2 "build/alignsem-raw-first/typeof/input.c"
                                           )
# 2 "build/alignsem-raw-first/typeof/input.c"
                                            ;
# 3 "build/alignsem-raw-first/typeof/input.c"
typedef
# 3 "build/alignsem-raw-first/typeof/input.c"
        Up
# 3 "build/alignsem-raw-first/typeof/input.c"
           Again
# 3 "build/alignsem-raw-first/typeof/input.c"
                ;
# 4 "build/alignsem-raw-first/typeof/input.c"
typedef
# 4 "build/alignsem-raw-first/typeof/input.c"
        __typeof__
# 4 "build/alignsem-raw-first/typeof/input.c"
                  (
# 4 "build/alignsem-raw-first/typeof/input.c"
                   Up
# 4 "build/alignsem-raw-first/typeof/input.c"
                     )
# 4 "build/alignsem-raw-first/typeof/input.c"
                       TU
# 4 "build/alignsem-raw-first/typeof/input.c"
                         ;
# 4 "build/alignsem-raw-first/typeof/input.c"
                           typedef
# 4 "build/alignsem-raw-first/typeof/input.c"
                                   __typeof__
# 4 "build/alignsem-raw-first/typeof/input.c"
                                             (
# 4 "build/alignsem-raw-first/typeof/input.c"
                                              Down
# 4 "build/alignsem-raw-first/typeof/input.c"
                                                  )
# 4 "build/alignsem-raw-first/typeof/input.c"
                                                    TD
# 4 "build/alignsem-raw-first/typeof/input.c"
                                                      ;
# 4 "build/alignsem-raw-first/typeof/input.c"
                                                        typedef
# 4 "build/alignsem-raw-first/typeof/input.c"
                                                                __typeof__
# 4 "build/alignsem-raw-first/typeof/input.c"
                                                                          (
# 4 "build/alignsem-raw-first/typeof/input.c"
                                                                           Again
# 4 "build/alignsem-raw-first/typeof/input.c"
                                                                                )
# 4 "build/alignsem-raw-first/typeof/input.c"
                                                                                  TA
# 4 "build/alignsem-raw-first/typeof/input.c"
                                                                                    ;
# 5 "build/alignsem-raw-first/typeof/input.c"
int
# 5 "build/alignsem-raw-first/typeof/input.c"
    main
# 5 "build/alignsem-raw-first/typeof/input.c"
        (
# 5 "build/alignsem-raw-first/typeof/input.c"
         void
# 5 "build/alignsem-raw-first/typeof/input.c"
             )
# 5 "build/alignsem-raw-first/typeof/input.c"
              {
# 5 "build/alignsem-raw-first/typeof/input.c"
               return
# 5 "build/alignsem-raw-first/typeof/input.c"
                      (
# 5 "build/alignsem-raw-first/typeof/input.c"
                       _Alignof
# 5 "build/alignsem-raw-first/typeof/input.c"
                               (
# 5 "build/alignsem-raw-first/typeof/input.c"
                                TU
# 5 "build/alignsem-raw-first/typeof/input.c"
                                  )
# 5 "build/alignsem-raw-first/typeof/input.c"
                                   !=
# 5 "build/alignsem-raw-first/typeof/input.c"
                                     16
# 5 "build/alignsem-raw-first/typeof/input.c"
                                        ||
# 5 "build/alignsem-raw-first/typeof/input.c"
                                           _Alignof
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                   (
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                    TD
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                      )
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                       !=
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                         1
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                           ||
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                              _Alignof
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                                      (
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                                       TA
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                                         )
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                                          !=
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                                            16
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                                               ||
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                                                  _Alignof
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                                                          (
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                                                           __typeof__
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                                                                     (
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                                                                      Up
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                                                                        *
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                                                                         )
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                                                                          )
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                                                                           !=
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                                                                             sizeof
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                                                                                   (
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                                                                                    void
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                                                                                        *
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                                                                                         )
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                                                                                          )
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                                                                                           ;
# 5 "build/alignsem-raw-first/typeof/input.c"
                                                                                                                            }

