# 1 "build/alignsem-raw-first/transport-band-int/input.c"
typedef
# 1 "build/alignsem-raw-first/transport-band-int/input.c"
        int
# 1 "build/alignsem-raw-first/transport-band-int/input.c"
            Up
# 1 "build/alignsem-raw-first/transport-band-int/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/transport-band-int/input.c"
                            (
# 1 "build/alignsem-raw-first/transport-band-int/input.c"
                             (
# 1 "build/alignsem-raw-first/transport-band-int/input.c"
                              aligned
# 1 "build/alignsem-raw-first/transport-band-int/input.c"
                                     (
# 1 "build/alignsem-raw-first/transport-band-int/input.c"
                                      16
# 1 "build/alignsem-raw-first/transport-band-int/input.c"
                                        )
# 1 "build/alignsem-raw-first/transport-band-int/input.c"
                                         )
# 1 "build/alignsem-raw-first/transport-band-int/input.c"
                                          )
# 1 "build/alignsem-raw-first/transport-band-int/input.c"
                                           ;
# 1 "build/alignsem-raw-first/transport-band-int/input.c"
                                             Up
# 1 "build/alignsem-raw-first/transport-band-int/input.c"
                                                x
# 1 "build/alignsem-raw-first/transport-band-int/input.c"
                                                 ;
# 1 "build/alignsem-raw-first/transport-band-int/input.c"
                                                   Up
# 1 "build/alignsem-raw-first/transport-band-int/input.c"
                                                      f
# 1 "build/alignsem-raw-first/transport-band-int/input.c"
                                                       (
# 1 "build/alignsem-raw-first/transport-band-int/input.c"
                                                        void
# 1 "build/alignsem-raw-first/transport-band-int/input.c"
                                                            )
# 1 "build/alignsem-raw-first/transport-band-int/input.c"
                                                             {
# 1 "build/alignsem-raw-first/transport-band-int/input.c"
                                                              return
# 1 "build/alignsem-raw-first/transport-band-int/input.c"
                                                                     0
# 1 "build/alignsem-raw-first/transport-band-int/input.c"
                                                                      ;
# 1 "build/alignsem-raw-first/transport-band-int/input.c"
                                                                       }
# 2 "build/alignsem-raw-first/transport-band-int/input.c"
int
# 2 "build/alignsem-raw-first/transport-band-int/input.c"
    main
# 2 "build/alignsem-raw-first/transport-band-int/input.c"
        (
# 2 "build/alignsem-raw-first/transport-band-int/input.c"
         void
# 2 "build/alignsem-raw-first/transport-band-int/input.c"
             )
# 2 "build/alignsem-raw-first/transport-band-int/input.c"
              {
# 2 "build/alignsem-raw-first/transport-band-int/input.c"
               return
# 2 "build/alignsem-raw-first/transport-band-int/input.c"
                      _Alignof
# 2 "build/alignsem-raw-first/transport-band-int/input.c"
                              (
# 2 "build/alignsem-raw-first/transport-band-int/input.c"
                               __typeof__
# 2 "build/alignsem-raw-first/transport-band-int/input.c"
                                         (
# 2 "build/alignsem-raw-first/transport-band-int/input.c"
                                          x
# 2 "build/alignsem-raw-first/transport-band-int/input.c"
                                           &
# 2 "build/alignsem-raw-first/transport-band-int/input.c"
                                            1
# 2 "build/alignsem-raw-first/transport-band-int/input.c"
                                             )
# 2 "build/alignsem-raw-first/transport-band-int/input.c"
                                              )
# 2 "build/alignsem-raw-first/transport-band-int/input.c"
                                               !=
# 2 "build/alignsem-raw-first/transport-band-int/input.c"
                                                 4
# 2 "build/alignsem-raw-first/transport-band-int/input.c"
                                                  ;
# 2 "build/alignsem-raw-first/transport-band-int/input.c"
                                                   }

