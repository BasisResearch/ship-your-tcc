# 1 "build/alignsem-raw-first/attribute-position-2/input.c"
typedef
# 1 "build/alignsem-raw-first/attribute-position-2/input.c"
        int
# 1 "build/alignsem-raw-first/attribute-position-2/input.c"
            Up
# 1 "build/alignsem-raw-first/attribute-position-2/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/attribute-position-2/input.c"
                            (
# 1 "build/alignsem-raw-first/attribute-position-2/input.c"
                             (
# 1 "build/alignsem-raw-first/attribute-position-2/input.c"
                              aligned
# 1 "build/alignsem-raw-first/attribute-position-2/input.c"
                                     (
# 1 "build/alignsem-raw-first/attribute-position-2/input.c"
                                      16
# 1 "build/alignsem-raw-first/attribute-position-2/input.c"
                                        )
# 1 "build/alignsem-raw-first/attribute-position-2/input.c"
                                         )
# 1 "build/alignsem-raw-first/attribute-position-2/input.c"
                                          )
# 1 "build/alignsem-raw-first/attribute-position-2/input.c"
                                           ;
# 2 "build/alignsem-raw-first/attribute-position-2/input.c"
int
# 2 "build/alignsem-raw-first/attribute-position-2/input.c"
    main
# 2 "build/alignsem-raw-first/attribute-position-2/input.c"
        (
# 2 "build/alignsem-raw-first/attribute-position-2/input.c"
         void
# 2 "build/alignsem-raw-first/attribute-position-2/input.c"
             )
# 2 "build/alignsem-raw-first/attribute-position-2/input.c"
              {
# 2 "build/alignsem-raw-first/attribute-position-2/input.c"
               return
# 2 "build/alignsem-raw-first/attribute-position-2/input.c"
                      _Alignof
# 2 "build/alignsem-raw-first/attribute-position-2/input.c"
                              (
# 2 "build/alignsem-raw-first/attribute-position-2/input.c"
                               Up
# 2 "build/alignsem-raw-first/attribute-position-2/input.c"
                                 )
# 2 "build/alignsem-raw-first/attribute-position-2/input.c"
                                  !=
# 2 "build/alignsem-raw-first/attribute-position-2/input.c"
                                    16
# 2 "build/alignsem-raw-first/attribute-position-2/input.c"
                                       ||
# 2 "build/alignsem-raw-first/attribute-position-2/input.c"
                                          sizeof
# 2 "build/alignsem-raw-first/attribute-position-2/input.c"
                                                (
# 2 "build/alignsem-raw-first/attribute-position-2/input.c"
                                                 Up
# 2 "build/alignsem-raw-first/attribute-position-2/input.c"
                                                   )
# 2 "build/alignsem-raw-first/attribute-position-2/input.c"
                                                    !=
# 2 "build/alignsem-raw-first/attribute-position-2/input.c"
                                                      4
# 2 "build/alignsem-raw-first/attribute-position-2/input.c"
                                                       ;
# 2 "build/alignsem-raw-first/attribute-position-2/input.c"
                                                        }

