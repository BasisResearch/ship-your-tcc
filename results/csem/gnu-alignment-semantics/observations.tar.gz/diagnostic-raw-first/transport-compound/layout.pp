# 1 "build/alignsem-raw-first/transport-compound/input.c"
typedef
# 1 "build/alignsem-raw-first/transport-compound/input.c"
        int
# 1 "build/alignsem-raw-first/transport-compound/input.c"
            Up
# 1 "build/alignsem-raw-first/transport-compound/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/transport-compound/input.c"
                            (
# 1 "build/alignsem-raw-first/transport-compound/input.c"
                             (
# 1 "build/alignsem-raw-first/transport-compound/input.c"
                              aligned
# 1 "build/alignsem-raw-first/transport-compound/input.c"
                                     (
# 1 "build/alignsem-raw-first/transport-compound/input.c"
                                      16
# 1 "build/alignsem-raw-first/transport-compound/input.c"
                                        )
# 1 "build/alignsem-raw-first/transport-compound/input.c"
                                         )
# 1 "build/alignsem-raw-first/transport-compound/input.c"
                                          )
# 1 "build/alignsem-raw-first/transport-compound/input.c"
                                           ;
# 1 "build/alignsem-raw-first/transport-compound/input.c"
                                             Up
# 1 "build/alignsem-raw-first/transport-compound/input.c"
                                                x
# 1 "build/alignsem-raw-first/transport-compound/input.c"
                                                 ;
# 1 "build/alignsem-raw-first/transport-compound/input.c"
                                                   Up
# 1 "build/alignsem-raw-first/transport-compound/input.c"
                                                      f
# 1 "build/alignsem-raw-first/transport-compound/input.c"
                                                       (
# 1 "build/alignsem-raw-first/transport-compound/input.c"
                                                        void
# 1 "build/alignsem-raw-first/transport-compound/input.c"
                                                            )
# 1 "build/alignsem-raw-first/transport-compound/input.c"
                                                             {
# 1 "build/alignsem-raw-first/transport-compound/input.c"
                                                              return
# 1 "build/alignsem-raw-first/transport-compound/input.c"
                                                                     0
# 1 "build/alignsem-raw-first/transport-compound/input.c"
                                                                      ;
# 1 "build/alignsem-raw-first/transport-compound/input.c"
                                                                       }
# 2 "build/alignsem-raw-first/transport-compound/input.c"
int
# 2 "build/alignsem-raw-first/transport-compound/input.c"
    main
# 2 "build/alignsem-raw-first/transport-compound/input.c"
        (
# 2 "build/alignsem-raw-first/transport-compound/input.c"
         void
# 2 "build/alignsem-raw-first/transport-compound/input.c"
             )
# 2 "build/alignsem-raw-first/transport-compound/input.c"
              {
# 2 "build/alignsem-raw-first/transport-compound/input.c"
               return
# 2 "build/alignsem-raw-first/transport-compound/input.c"
                      _Alignof
# 2 "build/alignsem-raw-first/transport-compound/input.c"
                              (
# 2 "build/alignsem-raw-first/transport-compound/input.c"
                               __typeof__
# 2 "build/alignsem-raw-first/transport-compound/input.c"
                                         (
# 2 "build/alignsem-raw-first/transport-compound/input.c"
                                          x
# 2 "build/alignsem-raw-first/transport-compound/input.c"
                                           +=
# 2 "build/alignsem-raw-first/transport-compound/input.c"
                                             1
# 2 "build/alignsem-raw-first/transport-compound/input.c"
                                              )
# 2 "build/alignsem-raw-first/transport-compound/input.c"
                                               )
# 2 "build/alignsem-raw-first/transport-compound/input.c"
                                                !=
# 2 "build/alignsem-raw-first/transport-compound/input.c"
                                                  16
# 2 "build/alignsem-raw-first/transport-compound/input.c"
                                                    ;
# 2 "build/alignsem-raw-first/transport-compound/input.c"
                                                     }

