# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
typedef
# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
        int
# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
            T
# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
              __attribute__
# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
                           (
# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
                            (
# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
                             aligned
# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
                                    (
# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
                                     16
# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
                                       )
# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
                                        )
# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
                                         )
# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
                                          ;
# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
                                            T
# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
                                              a
# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
                                               [
# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
                                                1
# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
                                                 ]
# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
                                                  ;
# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
                                                    int
# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
                                                        main
# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
                                                            (
# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
                                                             void
# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
                                                                 )
# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
                                                                  {
# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
                                                                   return
# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
                                                                          0
# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
                                                                           ;
# 1 "build/alignsem-raw-first/array-overaligned-array/input.c"
                                                                            }

