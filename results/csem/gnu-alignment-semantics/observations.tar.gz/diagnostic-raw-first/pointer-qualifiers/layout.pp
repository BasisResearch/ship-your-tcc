# 1 "build/alignsem-raw-first/pointer-qualifiers/input.c"
typedef
# 1 "build/alignsem-raw-first/pointer-qualifiers/input.c"
        int
# 1 "build/alignsem-raw-first/pointer-qualifiers/input.c"
            Up
# 1 "build/alignsem-raw-first/pointer-qualifiers/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                            (
# 1 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                             (
# 1 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                              aligned
# 1 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                     (
# 1 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                      16
# 1 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                        )
# 1 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                         )
# 1 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                          )
# 1 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                           ;
# 2 "build/alignsem-raw-first/pointer-qualifiers/input.c"
typedef
# 2 "build/alignsem-raw-first/pointer-qualifiers/input.c"
        int
# 2 "build/alignsem-raw-first/pointer-qualifiers/input.c"
            Down
# 2 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                 __attribute__
# 2 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                              (
# 2 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                               (
# 2 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                aligned
# 2 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                       (
# 2 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                        1
# 2 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                         )
# 2 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                          )
# 2 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                           )
# 2 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                            ;
# 3 "build/alignsem-raw-first/pointer-qualifiers/input.c"
typedef
# 3 "build/alignsem-raw-first/pointer-qualifiers/input.c"
        Up
# 3 "build/alignsem-raw-first/pointer-qualifiers/input.c"
           Again
# 3 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                ;
# 4 "build/alignsem-raw-first/pointer-qualifiers/input.c"
typedef
# 4 "build/alignsem-raw-first/pointer-qualifiers/input.c"
        Up
# 4 "build/alignsem-raw-first/pointer-qualifiers/input.c"
           *
# 4 "build/alignsem-raw-first/pointer-qualifiers/input.c"
            const
# 4 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                  CP
# 4 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                    ;
# 4 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                      typedef
# 4 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                              Down
# 4 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                   *
# 4 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                    volatile
# 4 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                             VP
# 4 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                               ;
# 4 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                 typedef
# 4 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                         Up
# 4 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                            *
# 4 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                             restrict
# 4 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                                      RP
# 4 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                                        ;
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
int
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
    main
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
        (
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
         void
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
             )
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
              {
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
               return
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                      (
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                       _Alignof
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                               (
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                CP
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                  )
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                   !=
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                     sizeof
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                           (
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                            void
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                *
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                 )
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                   ||
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                      _Alignof
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                              (
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                               VP
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                                 )
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                                  !=
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                                    sizeof
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                                          (
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                                           void
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                                               *
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                                                )
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                                                  ||
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                                                     _Alignof
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                                                             (
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                                                              RP
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                                                                )
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                                                                 !=
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                                                                   sizeof
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                                                                         (
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                                                                          void
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                                                                              *
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                                                                               )
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                                                                                )
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                                                                                 ;
# 5 "build/alignsem-raw-first/pointer-qualifiers/input.c"
                                                                                                                  }

