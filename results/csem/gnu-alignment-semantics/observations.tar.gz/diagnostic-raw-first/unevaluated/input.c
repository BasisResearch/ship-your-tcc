int main(void){int x=0; return __alignof__(x++)!=4 || x!=0;}
