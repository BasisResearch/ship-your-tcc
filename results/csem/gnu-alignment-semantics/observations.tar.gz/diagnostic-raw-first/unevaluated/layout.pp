# 1 "build/alignsem-raw-first/unevaluated/input.c"
int
# 1 "build/alignsem-raw-first/unevaluated/input.c"
    main
# 1 "build/alignsem-raw-first/unevaluated/input.c"
        (
# 1 "build/alignsem-raw-first/unevaluated/input.c"
         void
# 1 "build/alignsem-raw-first/unevaluated/input.c"
             )
# 1 "build/alignsem-raw-first/unevaluated/input.c"
              {
# 1 "build/alignsem-raw-first/unevaluated/input.c"
               int
# 1 "build/alignsem-raw-first/unevaluated/input.c"
                   x
# 1 "build/alignsem-raw-first/unevaluated/input.c"
                    =
# 1 "build/alignsem-raw-first/unevaluated/input.c"
                     0
# 1 "build/alignsem-raw-first/unevaluated/input.c"
                      ;
# 1 "build/alignsem-raw-first/unevaluated/input.c"
                        return
# 1 "build/alignsem-raw-first/unevaluated/input.c"
                               __alignof__
# 1 "build/alignsem-raw-first/unevaluated/input.c"
                                          (
# 1 "build/alignsem-raw-first/unevaluated/input.c"
                                           x
# 1 "build/alignsem-raw-first/unevaluated/input.c"
                                            ++
# 1 "build/alignsem-raw-first/unevaluated/input.c"
                                              )
# 1 "build/alignsem-raw-first/unevaluated/input.c"
                                               !=
# 1 "build/alignsem-raw-first/unevaluated/input.c"
                                                 4
# 1 "build/alignsem-raw-first/unevaluated/input.c"
                                                   ||
# 1 "build/alignsem-raw-first/unevaluated/input.c"
                                                      x
# 1 "build/alignsem-raw-first/unevaluated/input.c"
                                                       !=
# 1 "build/alignsem-raw-first/unevaluated/input.c"
                                                         0
# 1 "build/alignsem-raw-first/unevaluated/input.c"
                                                          ;
# 1 "build/alignsem-raw-first/unevaluated/input.c"
                                                           }

