# 1 "build/alignsem-raw-first/function-typeof/input.c"
typedef
# 1 "build/alignsem-raw-first/function-typeof/input.c"
        int
# 1 "build/alignsem-raw-first/function-typeof/input.c"
            Up
# 1 "build/alignsem-raw-first/function-typeof/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/function-typeof/input.c"
                            (
# 1 "build/alignsem-raw-first/function-typeof/input.c"
                             (
# 1 "build/alignsem-raw-first/function-typeof/input.c"
                              aligned
# 1 "build/alignsem-raw-first/function-typeof/input.c"
                                     (
# 1 "build/alignsem-raw-first/function-typeof/input.c"
                                      16
# 1 "build/alignsem-raw-first/function-typeof/input.c"
                                        )
# 1 "build/alignsem-raw-first/function-typeof/input.c"
                                         )
# 1 "build/alignsem-raw-first/function-typeof/input.c"
                                          )
# 1 "build/alignsem-raw-first/function-typeof/input.c"
                                           ;
# 2 "build/alignsem-raw-first/function-typeof/input.c"
typedef
# 2 "build/alignsem-raw-first/function-typeof/input.c"
        int
# 2 "build/alignsem-raw-first/function-typeof/input.c"
            Down
# 2 "build/alignsem-raw-first/function-typeof/input.c"
                 __attribute__
# 2 "build/alignsem-raw-first/function-typeof/input.c"
                              (
# 2 "build/alignsem-raw-first/function-typeof/input.c"
                               (
# 2 "build/alignsem-raw-first/function-typeof/input.c"
                                aligned
# 2 "build/alignsem-raw-first/function-typeof/input.c"
                                       (
# 2 "build/alignsem-raw-first/function-typeof/input.c"
                                        1
# 2 "build/alignsem-raw-first/function-typeof/input.c"
                                         )
# 2 "build/alignsem-raw-first/function-typeof/input.c"
                                          )
# 2 "build/alignsem-raw-first/function-typeof/input.c"
                                           )
# 2 "build/alignsem-raw-first/function-typeof/input.c"
                                            ;
# 3 "build/alignsem-raw-first/function-typeof/input.c"
typedef
# 3 "build/alignsem-raw-first/function-typeof/input.c"
        Up
# 3 "build/alignsem-raw-first/function-typeof/input.c"
           Again
# 3 "build/alignsem-raw-first/function-typeof/input.c"
                ;
# 4 "build/alignsem-raw-first/function-typeof/input.c"
typedef
# 4 "build/alignsem-raw-first/function-typeof/input.c"
        Up
# 4 "build/alignsem-raw-first/function-typeof/input.c"
           F
# 4 "build/alignsem-raw-first/function-typeof/input.c"
            (
# 4 "build/alignsem-raw-first/function-typeof/input.c"
             void
# 4 "build/alignsem-raw-first/function-typeof/input.c"
                 )
# 4 "build/alignsem-raw-first/function-typeof/input.c"
                  ;
# 4 "build/alignsem-raw-first/function-typeof/input.c"
                    typedef
# 4 "build/alignsem-raw-first/function-typeof/input.c"
                            __typeof__
# 4 "build/alignsem-raw-first/function-typeof/input.c"
                                      (
# 4 "build/alignsem-raw-first/function-typeof/input.c"
                                       F
# 4 "build/alignsem-raw-first/function-typeof/input.c"
                                        )
# 4 "build/alignsem-raw-first/function-typeof/input.c"
                                          TF
# 4 "build/alignsem-raw-first/function-typeof/input.c"
                                            ;
# 4 "build/alignsem-raw-first/function-typeof/input.c"
                                              typedef
# 4 "build/alignsem-raw-first/function-typeof/input.c"
                                                      F
# 4 "build/alignsem-raw-first/function-typeof/input.c"
                                                        *
# 4 "build/alignsem-raw-first/function-typeof/input.c"
                                                         FP
# 4 "build/alignsem-raw-first/function-typeof/input.c"
                                                           ;
# 5 "build/alignsem-raw-first/function-typeof/input.c"
int
# 5 "build/alignsem-raw-first/function-typeof/input.c"
    main
# 5 "build/alignsem-raw-first/function-typeof/input.c"
        (
# 5 "build/alignsem-raw-first/function-typeof/input.c"
         void
# 5 "build/alignsem-raw-first/function-typeof/input.c"
             )
# 5 "build/alignsem-raw-first/function-typeof/input.c"
              {
# 5 "build/alignsem-raw-first/function-typeof/input.c"
               return
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                      (
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                       _Alignof
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                               (
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                F
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                 )
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                  !=
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                    _Alignof
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                            (
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                             int
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                (
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                 void
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                     )
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                      )
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                        ||
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                           _Alignof
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                   (
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                    TF
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                      )
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                       !=
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                         _Alignof
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                 (
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                  F
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                   )
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                     ||
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                        _Alignof
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                                (
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                                 __typeof__
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                                           (
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                                            F
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                                             )
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                                              )
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                                               !=
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                                                 _Alignof
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                                                         (
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                                                          F
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                                                           )
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                                                             ||
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                                                                _Alignof
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                                                                        (
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                                                                         FP
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                                                                           )
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                                                                            !=
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                                                                              sizeof
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                                                                                    (
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                                                                                     void
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                                                                                         *
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                                                                                          )
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                                                                                           )
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                                                                                            ;
# 5 "build/alignsem-raw-first/function-typeof/input.c"
                                                                                                                                                             }

