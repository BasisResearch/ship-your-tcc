# 1 "build/alignsem-raw-first/transport-unary-plus/input.c"
typedef
# 1 "build/alignsem-raw-first/transport-unary-plus/input.c"
        int
# 1 "build/alignsem-raw-first/transport-unary-plus/input.c"
            Up
# 1 "build/alignsem-raw-first/transport-unary-plus/input.c"
               __attribute__
# 1 "build/alignsem-raw-first/transport-unary-plus/input.c"
                            (
# 1 "build/alignsem-raw-first/transport-unary-plus/input.c"
                             (
# 1 "build/alignsem-raw-first/transport-unary-plus/input.c"
                              aligned
# 1 "build/alignsem-raw-first/transport-unary-plus/input.c"
                                     (
# 1 "build/alignsem-raw-first/transport-unary-plus/input.c"
                                      16
# 1 "build/alignsem-raw-first/transport-unary-plus/input.c"
                                        )
# 1 "build/alignsem-raw-first/transport-unary-plus/input.c"
                                         )
# 1 "build/alignsem-raw-first/transport-unary-plus/input.c"
                                          )
# 1 "build/alignsem-raw-first/transport-unary-plus/input.c"
                                           ;
# 1 "build/alignsem-raw-first/transport-unary-plus/input.c"
                                             Up
# 1 "build/alignsem-raw-first/transport-unary-plus/input.c"
                                                x
# 1 "build/alignsem-raw-first/transport-unary-plus/input.c"
                                                 ;
# 1 "build/alignsem-raw-first/transport-unary-plus/input.c"
                                                   Up
# 1 "build/alignsem-raw-first/transport-unary-plus/input.c"
                                                      f
# 1 "build/alignsem-raw-first/transport-unary-plus/input.c"
                                                       (
# 1 "build/alignsem-raw-first/transport-unary-plus/input.c"
                                                        void
# 1 "build/alignsem-raw-first/transport-unary-plus/input.c"
                                                            )
# 1 "build/alignsem-raw-first/transport-unary-plus/input.c"
                                                             {
# 1 "build/alignsem-raw-first/transport-unary-plus/input.c"
                                                              return
# 1 "build/alignsem-raw-first/transport-unary-plus/input.c"
                                                                     0
# 1 "build/alignsem-raw-first/transport-unary-plus/input.c"
                                                                      ;
# 1 "build/alignsem-raw-first/transport-unary-plus/input.c"
                                                                       }
# 2 "build/alignsem-raw-first/transport-unary-plus/input.c"
int
# 2 "build/alignsem-raw-first/transport-unary-plus/input.c"
    main
# 2 "build/alignsem-raw-first/transport-unary-plus/input.c"
        (
# 2 "build/alignsem-raw-first/transport-unary-plus/input.c"
         void
# 2 "build/alignsem-raw-first/transport-unary-plus/input.c"
             )
# 2 "build/alignsem-raw-first/transport-unary-plus/input.c"
              {
# 2 "build/alignsem-raw-first/transport-unary-plus/input.c"
               return
# 2 "build/alignsem-raw-first/transport-unary-plus/input.c"
                      _Alignof
# 2 "build/alignsem-raw-first/transport-unary-plus/input.c"
                              (
# 2 "build/alignsem-raw-first/transport-unary-plus/input.c"
                               __typeof__
# 2 "build/alignsem-raw-first/transport-unary-plus/input.c"
                                         (
# 2 "build/alignsem-raw-first/transport-unary-plus/input.c"
                                          +
# 2 "build/alignsem-raw-first/transport-unary-plus/input.c"
                                           x
# 2 "build/alignsem-raw-first/transport-unary-plus/input.c"
                                            )
# 2 "build/alignsem-raw-first/transport-unary-plus/input.c"
                                             )
# 2 "build/alignsem-raw-first/transport-unary-plus/input.c"
                                              !=
# 2 "build/alignsem-raw-first/transport-unary-plus/input.c"
                                                16
# 2 "build/alignsem-raw-first/transport-unary-plus/input.c"
                                                  ;
# 2 "build/alignsem-raw-first/transport-unary-plus/input.c"
                                                   }

