# 1 "build/alignsem-raw-first/constraint-nested-incomplete-array/input.c"
typedef
# 1 "build/alignsem-raw-first/constraint-nested-incomplete-array/input.c"
        int
# 1 "build/alignsem-raw-first/constraint-nested-incomplete-array/input.c"
            A
# 1 "build/alignsem-raw-first/constraint-nested-incomplete-array/input.c"
             [
# 1 "build/alignsem-raw-first/constraint-nested-incomplete-array/input.c"
              ]
# 1 "build/alignsem-raw-first/constraint-nested-incomplete-array/input.c"
               [
# 1 "build/alignsem-raw-first/constraint-nested-incomplete-array/input.c"
                2
# 1 "build/alignsem-raw-first/constraint-nested-incomplete-array/input.c"
                 ]
# 1 "build/alignsem-raw-first/constraint-nested-incomplete-array/input.c"
                  ;
# 1 "build/alignsem-raw-first/constraint-nested-incomplete-array/input.c"
                    typedef
# 1 "build/alignsem-raw-first/constraint-nested-incomplete-array/input.c"
                            A
# 1 "build/alignsem-raw-first/constraint-nested-incomplete-array/input.c"
                              B
# 1 "build/alignsem-raw-first/constraint-nested-incomplete-array/input.c"
                               [
# 1 "build/alignsem-raw-first/constraint-nested-incomplete-array/input.c"
                                2
# 1 "build/alignsem-raw-first/constraint-nested-incomplete-array/input.c"
                                 ]
# 1 "build/alignsem-raw-first/constraint-nested-incomplete-array/input.c"
                                  ;
# 1 "build/alignsem-raw-first/constraint-nested-incomplete-array/input.c"
                                    int
# 1 "build/alignsem-raw-first/constraint-nested-incomplete-array/input.c"
                                        main
# 1 "build/alignsem-raw-first/constraint-nested-incomplete-array/input.c"
                                            (
# 1 "build/alignsem-raw-first/constraint-nested-incomplete-array/input.c"
                                             void
# 1 "build/alignsem-raw-first/constraint-nested-incomplete-array/input.c"
                                                 )
# 1 "build/alignsem-raw-first/constraint-nested-incomplete-array/input.c"
                                                  {
# 1 "build/alignsem-raw-first/constraint-nested-incomplete-array/input.c"
                                                   return
# 1 "build/alignsem-raw-first/constraint-nested-incomplete-array/input.c"
                                                          0
# 1 "build/alignsem-raw-first/constraint-nested-incomplete-array/input.c"
                                                           ;
# 1 "build/alignsem-raw-first/constraint-nested-incomplete-array/input.c"
                                                            }

