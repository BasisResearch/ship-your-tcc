typedef int A[][2]; typedef A B[2]; int main(void){return 0;}
