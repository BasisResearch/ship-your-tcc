# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
typedef
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
        int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
            Up
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
               __attribute__
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                            (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                             (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                              aligned
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                                     (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                                      16
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                                        )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                                         )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                                          )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                                           ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                                             Up
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                                                x
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                                                 ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                                                   Up
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                                                      f
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                                                       (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                                                        void
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                                                            )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                                                             {
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                                                              return
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                                                                     0
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                                                                      ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                                                                       }
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
    main
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
        (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
         void
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
             )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
              {
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
               return
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                      _Alignof
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                              (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                               __typeof__
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                                         (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                                          -
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                                           x
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                                            )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                                             )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                                              !=
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                                                16
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                                                  ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/transport-unary-minus/input.c"
                                                   }

