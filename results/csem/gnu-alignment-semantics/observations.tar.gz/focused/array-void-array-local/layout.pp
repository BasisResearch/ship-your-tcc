# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/array-void-array-local/input.c"
int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/array-void-array-local/input.c"
    main
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/array-void-array-local/input.c"
        (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/array-void-array-local/input.c"
         void
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/array-void-array-local/input.c"
             )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/array-void-array-local/input.c"
              {
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/array-void-array-local/input.c"
               void
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/array-void-array-local/input.c"
                    a
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/array-void-array-local/input.c"
                     [
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/array-void-array-local/input.c"
                      1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/array-void-array-local/input.c"
                       ]
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/array-void-array-local/input.c"
                        ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/array-void-array-local/input.c"
                         return
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/array-void-array-local/input.c"
                                0
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/array-void-array-local/input.c"
                                 ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-csem-repin/build/alignsem-focused-5/array-void-array-local/input.c"
                                  }

