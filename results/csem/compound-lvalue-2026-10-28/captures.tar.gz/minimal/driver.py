from pathlib import Path
import hashlib,json,subprocess,os
r=Path(__file__).resolve().parents[1];out=r/'build/compound-lvalue-minimal';out.mkdir(exist_ok=False)
oracle=r/'build/csem-704c4e69-e6d8db56/cerberus-lean/_build/default/backend/driver/main.exe';runtime=oracle.parents[3]/'install/default';raw=r/'.lake/build/bin/csem_raw';tcc=r/'.claude/worktrees/sol-c11-line/build/test-c11/host/tcc'
cases={'counter': 'int x,n; int *f(void){++n;return &x;} int main(void){*f()+=1;return n;}'}

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
pins={str(p):sha(p) for p in [oracle,raw,tcc,Path(__file__)]};rows=[]
for name,src in cases.items():
 d=out/name;d.mkdir();p=d/'prog.c';p.write_text(src+'\n');pins[str(p)]=sha(p);row=dict(case=name,engines={})
 commands={'raw':[raw,'--checked','--semantic',p],'pristine':[oracle,'--runtime='+str(runtime),'--nolibc','--exec','--batch','--mode=exhaustive',p],'gcc':['gcc','-std=c11','-pedantic-errors','-O0',p,'-o',d/'gcc.exe'],'tcc':[tcc,'-std=c11','-B'+str(tcc.parent),p,'-o',d/'tcc.exe']}
 for engine,cmd in commands.items():
  cmd=list(map(str,cmd));q=subprocess.run(cmd,cwd=r,capture_output=True,timeout=120,env={**os.environ,'LEAN_ABORT_ON_PANIC':'1'})
  (d/(engine+'.command.json')).write_text(json.dumps(cmd)+'\n')
  (d/(engine+'.stdout')).write_bytes(q.stdout);(d/(engine+'.stderr')).write_bytes(q.stderr)
  result=dict(exit=q.returncode)
  if engine=='raw' and q.returncode==0:result['semantics']=json.loads(q.stdout)['semantics']
  if engine=='pristine':result['verdicts']=q.stdout.decode(errors='replace')[-1000:]
  if engine in ['gcc','tcc'] and q.returncode==0:
   a=subprocess.run([d/(engine+'.exe')],capture_output=True);result['run_exit']=a.returncode;(d/(engine+'-run.stdout')).write_bytes(a.stdout);(d/(engine+'-run.stderr')).write_bytes(a.stderr)
  row['engines'][engine]=result
 rows.append(row);print(name,row['engines'],flush=True)
assert all(sha(Path(p))==h for p,h in pins.items())
(out/'report.json').write_text(json.dumps(dict(pins=pins,rows=rows),indent=2)+'\n')
