from pathlib import Path
import hashlib,json,subprocess,os
r=Path(__file__).resolve().parents[1];out=r/'build/compound-lvalue-review';out.mkdir(exist_ok=False)
oracle=r/'build/csem-704c4e69-e6d8db56/cerberus-lean/_build/default/backend/driver/main.exe';runtime=oracle.parents[3]/'install/default';raw=r/'.lake/build/bin/csem_raw';tcc=r/'.claude/worktrees/sol-c11-line/build/test-c11/host/tcc'
cases={
'index-add':'int main(void){int a[2]={1,2};int i=0;a[i++] +=3;return i!=1 || a[0]!=4 || a[1]!=2;}',
'index-multiply':'int main(void){int a[2]={2,3};int i=0;a[i++] *=4;return i!=1 || a[0]!=8 || a[1]!=3;}',
'index-assign-control':'int main(void){int a[2]={1,2};int i=0;a[i++] =4;return i!=1 || a[0]!=4 || a[1]!=2;}',
'pointer-postincrement':'int main(void){int a[2]={1,2};int *p=a;*p++ +=3;return p!=a+1 || a[0]!=4 || a[1]!=2;}',
'call-member':'struct S{int x;};struct S s={1};int n;struct S *get(void){n++;return &s;}int main(void){get()->x +=3;return n!=1 || s.x!=4;}',
'call-address':'int a=1;int n;int *get(void){n++;return &a;}int main(void){*get() +=3;return n!=1 || a!=4;}',
}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
pins={str(p):sha(p) for p in [oracle,raw,tcc,Path(__file__)]};rows=[]
for name,src in cases.items():
 d=out/name;d.mkdir();p=d/'prog.c';p.write_text(src+'\n');pins[str(p)]=sha(p);row=dict(case=name,engines={})
 commands={'raw':[raw,'--checked','--semantic',p],'pristine':[oracle,'--runtime='+str(runtime),'--nolibc','--exec','--batch','--mode=exhaustive',p],'gcc':['gcc','-std=c11','-pedantic-errors','-O0',p,'-o',d/'gcc.exe'],'tcc':[tcc,'-std=c11','-B'+str(tcc.parent),p,'-o',d/'tcc.exe']}
 for engine,cmd in commands.items():
  cmd=list(map(str,cmd));q=subprocess.run(cmd,cwd=r,capture_output=True,timeout=120,env={**os.environ,'LEAN_ABORT_ON_PANIC':'1'})
  (d/(engine+'.command.json')).write_text(json.dumps(cmd)+'\n')
  (d/(engine+'.stdout')).write_bytes(q.stdout);(d/(engine+'.stderr')).write_bytes(q.stderr)
  result=dict(exit=q.returncode)
  if engine=='raw' and q.returncode==0:result['semantics']=json.loads(q.stdout)['semantics']
  if engine=='pristine':result['verdicts']=q.stdout.decode(errors='replace')[-1000:]
  if engine in ['gcc','tcc'] and q.returncode==0:
   a=subprocess.run([d/(engine+'.exe')],capture_output=True);result['run_exit']=a.returncode;(d/(engine+'-run.stdout')).write_bytes(a.stdout);(d/(engine+'-run.stderr')).write_bytes(a.stderr)
  row['engines'][engine]=result
 rows.append(row);print(name,row['engines'],flush=True)
assert all(sha(Path(p))==h for p,h in pins.items())
(out/'report.json').write_text(json.dumps(dict(pins=pins,rows=rows),indent=2)+'\n')
