# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
static
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
       int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
           mine
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
               (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                    x
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                     )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                      {
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                       return
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                              x
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                               +
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                10
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                  ;
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                   }
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
static
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
       int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
           mine
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
               (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                   )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                    ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
static
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
       int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
           mine
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
               (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                   )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                    ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
    main
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
        (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
         void
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
             )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
              {
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
               int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                   (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                    *
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                     p
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                      )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                       (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                        int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                           )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                            =
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                             mine
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                 ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                   int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                       (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                        *
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                         q
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                          )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                           (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                            int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                               )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                =
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                 &
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                  mine
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                      ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                        return
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                               mine
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                   (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                    7
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                     )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                      !=
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                        17
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                           ||
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                              p
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                               (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                                7
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                                 )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                                  !=
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                                    17
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                                       ||
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                                          (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                                           *
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                                            q
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                                             )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                                              (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                                               7
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                                                )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                                                 !=
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                                                   17
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                                                      ||
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                                                         p
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                                                          !=
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                                                            q
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                                                              ||
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                                                                 p
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                                                                  ==
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                                                                    0
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                                                                     ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-dprm.c"
                                                                                                                      }

