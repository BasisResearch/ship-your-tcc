# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
    mine
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
        (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
         int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
            )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
             ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
    main
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
        (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
         void
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
             )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
              {
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
               int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                   (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                    *
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                     p
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                      )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                       (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                        int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                           )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                            =
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                             mine
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                 ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                   int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                       (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                        *
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                         q
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                          )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                           (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                            int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                               )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                =
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                 &
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                  mine
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                      ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                        return
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                               mine
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                   (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                    7
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                     )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                      !=
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                        17
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                           ||
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                              p
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                               (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                                7
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                                 )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                                  !=
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                                    17
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                                       ||
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                                          (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                                           *
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                                            q
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                                             )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                                              (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                                               7
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                                                )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                                                 !=
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                                                   17
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                                                      ||
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                                                         p
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                                                          !=
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                                                            q
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                                                              ||
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                                                                 p
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                                                                  ==
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                                                                    0
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                                                                     ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                                                                                                                      }
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
    mine
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
        (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
         int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
             x
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
              )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
               {
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                return
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                       x
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                        +
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                         10
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                           ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
                            }
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
    mine
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
        (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
         int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
            )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-pmdr.c"
             ;

