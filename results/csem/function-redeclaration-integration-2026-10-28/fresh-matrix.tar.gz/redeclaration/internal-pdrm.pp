# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
static
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
       int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
           mine
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
               (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                   )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                    ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
static
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
       int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
           mine
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
               (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                    x
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                     )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                      {
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                       return
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                              x
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                               +
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                10
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                  ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                   }
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
static
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
       int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
           mine
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
               (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                   )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                    ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
    main
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
        (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
         void
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
             )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
              {
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
               int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                   (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                    *
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                     p
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                      )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                       (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                        int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                           )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                            =
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                             mine
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                 ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                   int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                       (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                        *
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                         q
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                          )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                           (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                            int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                               )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                =
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                 &
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                  mine
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                      ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                        return
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                               mine
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                   (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                    7
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                     )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                      !=
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                        17
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                           ||
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                              p
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                               (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                                7
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                                 )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                                  !=
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                                    17
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                                       ||
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                                          (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                                           *
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                                            q
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                                             )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                                              (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                                               7
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                                                )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                                                 !=
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                                                   17
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                                                      ||
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                                                         p
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                                                          !=
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                                                            q
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                                                              ||
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                                                                 p
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                                                                  ==
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                                                                    0
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                                                                     ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/internal-pdrm.c"
                                                                                                                      }

