# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
static
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
       int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
           mine
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
               (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                   )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                    ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
static
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
       int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
           mine
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
               (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                    x
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                     )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                      {
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                       return
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                              x
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                               +
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                10
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                  ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                   }
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
static
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
       int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
           mine
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
               (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                   )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                    ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
    main
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
        (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
         void
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
             )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
              {
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
               int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                   (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                    *
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                     p
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                      )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                       (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                        int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                           )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                            =
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                             mine
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                 ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                  int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                      (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                       *
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                        q
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                         )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                          (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                           int
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                              )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                               =
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                0
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                 ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                  unsigned
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                           char
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                *
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                 a
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                  =
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                   (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                    unsigned
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                             char
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                  *
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                   )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                    &
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                     p
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                      ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                       unsigned
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                char
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                     *
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                      b
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                       =
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                        (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                         unsigned
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                  char
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                       *
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                        )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                         &
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                          q
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                           ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                            for
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                               (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                unsigned
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                         long
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                              i
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                               =
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                0
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                 ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                  i
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                   <
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                    sizeof
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                           p
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                            ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                             i
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                              ++
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                                )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                                 b
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                                  [
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                                   i
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                                    ]
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                                     =
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                                      a
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                                       [
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                                        i
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                                         ]
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                                          ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                                           return
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                                                  q
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                                                   !=
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                                                     mine
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                                                          ||
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                                                             q
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                                                              (
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                                                               8
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                                                                )
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                                                                 !=
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                                                                   18
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                                                                     ;
# 4 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/bytes.c"
                                                                                                                                                                                                      }

