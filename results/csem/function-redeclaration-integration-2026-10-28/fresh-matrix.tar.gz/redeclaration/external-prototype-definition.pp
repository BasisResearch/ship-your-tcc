# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
    mine
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
        (
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
         int
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
            )
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
             ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
    mine
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
        (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
         int
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
             x
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
              )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
               {
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                return
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                       x
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                        +
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                         10
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                           ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                            }
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
    main
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
        (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
         void
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
             )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
              {
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
               int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                   (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                    *
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                     p
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                      )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                       (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                        int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                           )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                            =
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                             mine
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                 ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                   int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                       (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                        *
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                         q
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                          )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                           (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                            int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                               )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                =
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                 &
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                  mine
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                      ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                        return
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                               mine
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                   (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                    7
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                     )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                      !=
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                        17
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                           ||
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                              p
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                               (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                                7
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                                 )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                                  !=
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                                    17
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                                       ||
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                                          (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                                           *
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                                            q
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                                             )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                                              (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                                               7
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                                                )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                                                 !=
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                                                   17
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                                                      ||
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                                                         p
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                                                          !=
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                                                            q
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                                                              ||
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                                                                 p
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                                                                  ==
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                                                                    0
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                                                                     ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/function-redeclaration-gate.XyDBEp/run/sources/external-prototype-definition.c"
                                                                                                                      }

