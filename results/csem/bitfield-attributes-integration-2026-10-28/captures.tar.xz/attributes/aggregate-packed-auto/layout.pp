# 184 "/lib/tcc/include/tccdefs.h"
struct
# 184 "/lib/tcc/include/tccdefs.h"
       __uint128__
# 184 "/lib/tcc/include/tccdefs.h"
                   {
# 184 "/lib/tcc/include/tccdefs.h"
                     char
# 184 "/lib/tcc/include/tccdefs.h"
                          x
# 184 "/lib/tcc/include/tccdefs.h"
                           [
# 184 "/lib/tcc/include/tccdefs.h"
                            16
# 184 "/lib/tcc/include/tccdefs.h"
                              ]
# 184 "/lib/tcc/include/tccdefs.h"
                               ;
# 184 "/lib/tcc/include/tccdefs.h"
                                 }
# 184 "/lib/tcc/include/tccdefs.h"
                                   __attribute
# 184 "/lib/tcc/include/tccdefs.h"
                                              (
# 184 "/lib/tcc/include/tccdefs.h"
                                               (
# 184 "/lib/tcc/include/tccdefs.h"
                                                __aligned__
# 184 "/lib/tcc/include/tccdefs.h"
                                                           (
# 184 "/lib/tcc/include/tccdefs.h"
                                                            16
# 184 "/lib/tcc/include/tccdefs.h"
                                                              )
# 184 "/lib/tcc/include/tccdefs.h"
                                                               )
# 184 "/lib/tcc/include/tccdefs.h"
                                                                )
# 184 "/lib/tcc/include/tccdefs.h"
                                                                 ;
# 240 "/lib/tcc/include/tccdefs.h"
typedef
# 240 "/lib/tcc/include/tccdefs.h"
        char
# 240 "/lib/tcc/include/tccdefs.h"
             *
# 240 "/lib/tcc/include/tccdefs.h"
              __builtin_va_list
# 240 "/lib/tcc/include/tccdefs.h"
                               ;
# 279 "/lib/tcc/include/tccdefs.h"
       void
# 279 "/lib/tcc/include/tccdefs.h"
           *
# 279 "/lib/tcc/include/tccdefs.h"
__builtin_memcpy
# 279 "/lib/tcc/include/tccdefs.h"
                      (
# 279 "/lib/tcc/include/tccdefs.h"
                       void
# 279 "/lib/tcc/include/tccdefs.h"
                            *
# 279 "/lib/tcc/include/tccdefs.h"
                             ,
# 279 "/lib/tcc/include/tccdefs.h"
                               const
# 279 "/lib/tcc/include/tccdefs.h"
                                     void
# 279 "/lib/tcc/include/tccdefs.h"
                                         *
# 279 "/lib/tcc/include/tccdefs.h"
                                          ,
# 279 "/lib/tcc/include/tccdefs.h"
                                            unsigned
# 279 "/lib/tcc/include/tccdefs.h"
                                            long
# 279 "/lib/tcc/include/tccdefs.h"
                                                         )
# 279 "/lib/tcc/include/tccdefs.h"
__asm__
# 279 "/lib/tcc/include/tccdefs.h"
(
# 279 "/lib/tcc/include/tccdefs.h"
"memcpy"
# 279 "/lib/tcc/include/tccdefs.h"
)
# 279 "/lib/tcc/include/tccdefs.h"
;
# 280 "/lib/tcc/include/tccdefs.h"
       void
# 280 "/lib/tcc/include/tccdefs.h"
           *
# 280 "/lib/tcc/include/tccdefs.h"
__builtin_memmove
# 280 "/lib/tcc/include/tccdefs.h"
                       (
# 280 "/lib/tcc/include/tccdefs.h"
                        void
# 280 "/lib/tcc/include/tccdefs.h"
                             *
# 280 "/lib/tcc/include/tccdefs.h"
                              ,
# 280 "/lib/tcc/include/tccdefs.h"
                                const
# 280 "/lib/tcc/include/tccdefs.h"
                                      void
# 280 "/lib/tcc/include/tccdefs.h"
                                          *
# 280 "/lib/tcc/include/tccdefs.h"
                                           ,
# 280 "/lib/tcc/include/tccdefs.h"
                                             unsigned
# 280 "/lib/tcc/include/tccdefs.h"
                                             long
# 280 "/lib/tcc/include/tccdefs.h"
                                                          )
# 280 "/lib/tcc/include/tccdefs.h"
__asm__
# 280 "/lib/tcc/include/tccdefs.h"
(
# 280 "/lib/tcc/include/tccdefs.h"
"memmove"
# 280 "/lib/tcc/include/tccdefs.h"
)
# 280 "/lib/tcc/include/tccdefs.h"
;
# 281 "/lib/tcc/include/tccdefs.h"
       void
# 281 "/lib/tcc/include/tccdefs.h"
           *
# 281 "/lib/tcc/include/tccdefs.h"
__builtin_memset
# 281 "/lib/tcc/include/tccdefs.h"
                      (
# 281 "/lib/tcc/include/tccdefs.h"
                       void
# 281 "/lib/tcc/include/tccdefs.h"
                            *
# 281 "/lib/tcc/include/tccdefs.h"
                             ,
# 281 "/lib/tcc/include/tccdefs.h"
                               int
# 281 "/lib/tcc/include/tccdefs.h"
                                  ,
# 281 "/lib/tcc/include/tccdefs.h"
                                    unsigned
# 281 "/lib/tcc/include/tccdefs.h"
                                    long
# 281 "/lib/tcc/include/tccdefs.h"
                                                 )
# 281 "/lib/tcc/include/tccdefs.h"
__asm__
# 281 "/lib/tcc/include/tccdefs.h"
(
# 281 "/lib/tcc/include/tccdefs.h"
"memset"
# 281 "/lib/tcc/include/tccdefs.h"
)
# 281 "/lib/tcc/include/tccdefs.h"
;
# 282 "/lib/tcc/include/tccdefs.h"
       int
# 282 "/lib/tcc/include/tccdefs.h"
__builtin_memcmp
# 282 "/lib/tcc/include/tccdefs.h"
                    (
# 282 "/lib/tcc/include/tccdefs.h"
                     const
# 282 "/lib/tcc/include/tccdefs.h"
                           void
# 282 "/lib/tcc/include/tccdefs.h"
                                *
# 282 "/lib/tcc/include/tccdefs.h"
                                 ,
# 282 "/lib/tcc/include/tccdefs.h"
                                   const
# 282 "/lib/tcc/include/tccdefs.h"
                                         void
# 282 "/lib/tcc/include/tccdefs.h"
                                             *
# 282 "/lib/tcc/include/tccdefs.h"
                                              ,
# 282 "/lib/tcc/include/tccdefs.h"
                                                unsigned
# 282 "/lib/tcc/include/tccdefs.h"
                                                long
# 282 "/lib/tcc/include/tccdefs.h"
                                                             )
# 282 "/lib/tcc/include/tccdefs.h"
__asm__
# 282 "/lib/tcc/include/tccdefs.h"
(
# 282 "/lib/tcc/include/tccdefs.h"
"memcmp"
# 282 "/lib/tcc/include/tccdefs.h"
)
# 282 "/lib/tcc/include/tccdefs.h"
;
# 283 "/lib/tcc/include/tccdefs.h"
       unsigned
# 283 "/lib/tcc/include/tccdefs.h"
       long
# 283 "/lib/tcc/include/tccdefs.h"
__builtin_strlen
# 283 "/lib/tcc/include/tccdefs.h"
                              (
# 283 "/lib/tcc/include/tccdefs.h"
                               const
# 283 "/lib/tcc/include/tccdefs.h"
                                     char
# 283 "/lib/tcc/include/tccdefs.h"
                                          *
# 283 "/lib/tcc/include/tccdefs.h"
                                           )
# 283 "/lib/tcc/include/tccdefs.h"
__asm__
# 283 "/lib/tcc/include/tccdefs.h"
(
# 283 "/lib/tcc/include/tccdefs.h"
"strlen"
# 283 "/lib/tcc/include/tccdefs.h"
)
# 283 "/lib/tcc/include/tccdefs.h"
;
# 284 "/lib/tcc/include/tccdefs.h"
       char
# 284 "/lib/tcc/include/tccdefs.h"
           *
# 284 "/lib/tcc/include/tccdefs.h"
__builtin_strcpy
# 284 "/lib/tcc/include/tccdefs.h"
                      (
# 284 "/lib/tcc/include/tccdefs.h"
                       char
# 284 "/lib/tcc/include/tccdefs.h"
                            *
# 284 "/lib/tcc/include/tccdefs.h"
                             ,
# 284 "/lib/tcc/include/tccdefs.h"
                               const
# 284 "/lib/tcc/include/tccdefs.h"
                                     char
# 284 "/lib/tcc/include/tccdefs.h"
                                          *
# 284 "/lib/tcc/include/tccdefs.h"
                                           )
# 284 "/lib/tcc/include/tccdefs.h"
__asm__
# 284 "/lib/tcc/include/tccdefs.h"
(
# 284 "/lib/tcc/include/tccdefs.h"
"strcpy"
# 284 "/lib/tcc/include/tccdefs.h"
)
# 284 "/lib/tcc/include/tccdefs.h"
;
# 285 "/lib/tcc/include/tccdefs.h"
       char
# 285 "/lib/tcc/include/tccdefs.h"
           *
# 285 "/lib/tcc/include/tccdefs.h"
__builtin_strncpy
# 285 "/lib/tcc/include/tccdefs.h"
                       (
# 285 "/lib/tcc/include/tccdefs.h"
                        char
# 285 "/lib/tcc/include/tccdefs.h"
                             *
# 285 "/lib/tcc/include/tccdefs.h"
                              ,
# 285 "/lib/tcc/include/tccdefs.h"
                                const
# 285 "/lib/tcc/include/tccdefs.h"
                                      char
# 285 "/lib/tcc/include/tccdefs.h"
                                          *
# 285 "/lib/tcc/include/tccdefs.h"
                                           ,
# 285 "/lib/tcc/include/tccdefs.h"
                                             unsigned
# 285 "/lib/tcc/include/tccdefs.h"
                                             long
# 285 "/lib/tcc/include/tccdefs.h"
                                                          )
# 285 "/lib/tcc/include/tccdefs.h"
__asm__
# 285 "/lib/tcc/include/tccdefs.h"
(
# 285 "/lib/tcc/include/tccdefs.h"
"strncpy"
# 285 "/lib/tcc/include/tccdefs.h"
)
# 285 "/lib/tcc/include/tccdefs.h"
;
# 286 "/lib/tcc/include/tccdefs.h"
       int
# 286 "/lib/tcc/include/tccdefs.h"
__builtin_strcmp
# 286 "/lib/tcc/include/tccdefs.h"
                    (
# 286 "/lib/tcc/include/tccdefs.h"
                     const
# 286 "/lib/tcc/include/tccdefs.h"
                           char
# 286 "/lib/tcc/include/tccdefs.h"
                               *
# 286 "/lib/tcc/include/tccdefs.h"
                                ,
# 286 "/lib/tcc/include/tccdefs.h"
                                  const
# 286 "/lib/tcc/include/tccdefs.h"
                                        char
# 286 "/lib/tcc/include/tccdefs.h"
                                            *
# 286 "/lib/tcc/include/tccdefs.h"
                                             )
# 286 "/lib/tcc/include/tccdefs.h"
__asm__
# 286 "/lib/tcc/include/tccdefs.h"
(
# 286 "/lib/tcc/include/tccdefs.h"
"strcmp"
# 286 "/lib/tcc/include/tccdefs.h"
)
# 286 "/lib/tcc/include/tccdefs.h"
;
# 287 "/lib/tcc/include/tccdefs.h"
       int
# 287 "/lib/tcc/include/tccdefs.h"
__builtin_strncmp
# 287 "/lib/tcc/include/tccdefs.h"
                     (
# 287 "/lib/tcc/include/tccdefs.h"
                      const
# 287 "/lib/tcc/include/tccdefs.h"
                            char
# 287 "/lib/tcc/include/tccdefs.h"
                                *
# 287 "/lib/tcc/include/tccdefs.h"
                                 ,
# 287 "/lib/tcc/include/tccdefs.h"
                                   const
# 287 "/lib/tcc/include/tccdefs.h"
                                         char
# 287 "/lib/tcc/include/tccdefs.h"
                                             *
# 287 "/lib/tcc/include/tccdefs.h"
                                              ,
# 287 "/lib/tcc/include/tccdefs.h"
                                                unsigned
# 287 "/lib/tcc/include/tccdefs.h"
                                                long
# 287 "/lib/tcc/include/tccdefs.h"
                                                             )
# 287 "/lib/tcc/include/tccdefs.h"
__asm__
# 287 "/lib/tcc/include/tccdefs.h"
(
# 287 "/lib/tcc/include/tccdefs.h"
"strncmp"
# 287 "/lib/tcc/include/tccdefs.h"
)
# 287 "/lib/tcc/include/tccdefs.h"
;
# 288 "/lib/tcc/include/tccdefs.h"
       char
# 288 "/lib/tcc/include/tccdefs.h"
           *
# 288 "/lib/tcc/include/tccdefs.h"
__builtin_strcat
# 288 "/lib/tcc/include/tccdefs.h"
                      (
# 288 "/lib/tcc/include/tccdefs.h"
                       char
# 288 "/lib/tcc/include/tccdefs.h"
                           *
# 288 "/lib/tcc/include/tccdefs.h"
                            ,
# 288 "/lib/tcc/include/tccdefs.h"
                              const
# 288 "/lib/tcc/include/tccdefs.h"
                                    char
# 288 "/lib/tcc/include/tccdefs.h"
                                        *
# 288 "/lib/tcc/include/tccdefs.h"
                                         )
# 288 "/lib/tcc/include/tccdefs.h"
__asm__
# 288 "/lib/tcc/include/tccdefs.h"
(
# 288 "/lib/tcc/include/tccdefs.h"
"strcat"
# 288 "/lib/tcc/include/tccdefs.h"
)
# 288 "/lib/tcc/include/tccdefs.h"
;
# 289 "/lib/tcc/include/tccdefs.h"
       char
# 289 "/lib/tcc/include/tccdefs.h"
           *
# 289 "/lib/tcc/include/tccdefs.h"
__builtin_strncat
# 289 "/lib/tcc/include/tccdefs.h"
                       (
# 289 "/lib/tcc/include/tccdefs.h"
                        char
# 289 "/lib/tcc/include/tccdefs.h"
                            *
# 289 "/lib/tcc/include/tccdefs.h"
                             ,
# 289 "/lib/tcc/include/tccdefs.h"
                               const
# 289 "/lib/tcc/include/tccdefs.h"
                                     char
# 289 "/lib/tcc/include/tccdefs.h"
                                         *
# 289 "/lib/tcc/include/tccdefs.h"
                                          ,
# 289 "/lib/tcc/include/tccdefs.h"
                                            unsigned
# 289 "/lib/tcc/include/tccdefs.h"
                                            long
# 289 "/lib/tcc/include/tccdefs.h"
                                                         )
# 289 "/lib/tcc/include/tccdefs.h"
__asm__
# 289 "/lib/tcc/include/tccdefs.h"
(
# 289 "/lib/tcc/include/tccdefs.h"
"strncat"
# 289 "/lib/tcc/include/tccdefs.h"
)
# 289 "/lib/tcc/include/tccdefs.h"
;
# 290 "/lib/tcc/include/tccdefs.h"
       char
# 290 "/lib/tcc/include/tccdefs.h"
           *
# 290 "/lib/tcc/include/tccdefs.h"
__builtin_strchr
# 290 "/lib/tcc/include/tccdefs.h"
                      (
# 290 "/lib/tcc/include/tccdefs.h"
                       const
# 290 "/lib/tcc/include/tccdefs.h"
                             char
# 290 "/lib/tcc/include/tccdefs.h"
                                 *
# 290 "/lib/tcc/include/tccdefs.h"
                                  ,
# 290 "/lib/tcc/include/tccdefs.h"
                                    int
# 290 "/lib/tcc/include/tccdefs.h"
                                       )
# 290 "/lib/tcc/include/tccdefs.h"
__asm__
# 290 "/lib/tcc/include/tccdefs.h"
(
# 290 "/lib/tcc/include/tccdefs.h"
"strchr"
# 290 "/lib/tcc/include/tccdefs.h"
)
# 290 "/lib/tcc/include/tccdefs.h"
;
# 291 "/lib/tcc/include/tccdefs.h"
       char
# 291 "/lib/tcc/include/tccdefs.h"
           *
# 291 "/lib/tcc/include/tccdefs.h"
__builtin_strrchr
# 291 "/lib/tcc/include/tccdefs.h"
                       (
# 291 "/lib/tcc/include/tccdefs.h"
                        const
# 291 "/lib/tcc/include/tccdefs.h"
                              char
# 291 "/lib/tcc/include/tccdefs.h"
                                  *
# 291 "/lib/tcc/include/tccdefs.h"
                                   ,
# 291 "/lib/tcc/include/tccdefs.h"
                                     int
# 291 "/lib/tcc/include/tccdefs.h"
                                        )
# 291 "/lib/tcc/include/tccdefs.h"
__asm__
# 291 "/lib/tcc/include/tccdefs.h"
(
# 291 "/lib/tcc/include/tccdefs.h"
"strrchr"
# 291 "/lib/tcc/include/tccdefs.h"
)
# 291 "/lib/tcc/include/tccdefs.h"
;
# 292 "/lib/tcc/include/tccdefs.h"
       char
# 292 "/lib/tcc/include/tccdefs.h"
           *
# 292 "/lib/tcc/include/tccdefs.h"
__builtin_strdup
# 292 "/lib/tcc/include/tccdefs.h"
                      (
# 292 "/lib/tcc/include/tccdefs.h"
                       const
# 292 "/lib/tcc/include/tccdefs.h"
                             char
# 292 "/lib/tcc/include/tccdefs.h"
                                 *
# 292 "/lib/tcc/include/tccdefs.h"
                                  )
# 292 "/lib/tcc/include/tccdefs.h"
__asm__
# 292 "/lib/tcc/include/tccdefs.h"
(
# 292 "/lib/tcc/include/tccdefs.h"
"strdup"
# 292 "/lib/tcc/include/tccdefs.h"
)
# 292 "/lib/tcc/include/tccdefs.h"
;
# 306 "/lib/tcc/include/tccdefs.h"
              void
# 306 "/lib/tcc/include/tccdefs.h"
                  *
# 306 "/lib/tcc/include/tccdefs.h"
__builtin_malloc
# 306 "/lib/tcc/include/tccdefs.h"
                             (
# 306 "/lib/tcc/include/tccdefs.h"
                              unsigned
# 306 "/lib/tcc/include/tccdefs.h"
                              long
# 306 "/lib/tcc/include/tccdefs.h"
                                           )
# 306 "/lib/tcc/include/tccdefs.h"
__asm__
# 306 "/lib/tcc/include/tccdefs.h"
(
# 306 "/lib/tcc/include/tccdefs.h"
"malloc"
# 306 "/lib/tcc/include/tccdefs.h"
)
# 306 "/lib/tcc/include/tccdefs.h"
;
# 307 "/lib/tcc/include/tccdefs.h"
              void
# 307 "/lib/tcc/include/tccdefs.h"
                  *
# 307 "/lib/tcc/include/tccdefs.h"
__builtin_realloc
# 307 "/lib/tcc/include/tccdefs.h"
                              (
# 307 "/lib/tcc/include/tccdefs.h"
                               void
# 307 "/lib/tcc/include/tccdefs.h"
                                    *
# 307 "/lib/tcc/include/tccdefs.h"
                                     ,
# 307 "/lib/tcc/include/tccdefs.h"
                                       unsigned
# 307 "/lib/tcc/include/tccdefs.h"
                                       long
# 307 "/lib/tcc/include/tccdefs.h"
                                                    )
# 307 "/lib/tcc/include/tccdefs.h"
__asm__
# 307 "/lib/tcc/include/tccdefs.h"
(
# 307 "/lib/tcc/include/tccdefs.h"
"realloc"
# 307 "/lib/tcc/include/tccdefs.h"
)
# 307 "/lib/tcc/include/tccdefs.h"
;
# 308 "/lib/tcc/include/tccdefs.h"
              void
# 308 "/lib/tcc/include/tccdefs.h"
                  *
# 308 "/lib/tcc/include/tccdefs.h"
__builtin_calloc
# 308 "/lib/tcc/include/tccdefs.h"
                             (
# 308 "/lib/tcc/include/tccdefs.h"
                              unsigned
# 308 "/lib/tcc/include/tccdefs.h"
                              long
# 308 "/lib/tcc/include/tccdefs.h"
                                           ,
# 308 "/lib/tcc/include/tccdefs.h"
                                             unsigned
# 308 "/lib/tcc/include/tccdefs.h"
                                             long
# 308 "/lib/tcc/include/tccdefs.h"
                                                          )
# 308 "/lib/tcc/include/tccdefs.h"
__asm__
# 308 "/lib/tcc/include/tccdefs.h"
(
# 308 "/lib/tcc/include/tccdefs.h"
"calloc"
# 308 "/lib/tcc/include/tccdefs.h"
)
# 308 "/lib/tcc/include/tccdefs.h"
;
# 309 "/lib/tcc/include/tccdefs.h"
              void
# 309 "/lib/tcc/include/tccdefs.h"
                  *
# 309 "/lib/tcc/include/tccdefs.h"
__builtin_memalign
# 309 "/lib/tcc/include/tccdefs.h"
                               (
# 309 "/lib/tcc/include/tccdefs.h"
                                unsigned
# 309 "/lib/tcc/include/tccdefs.h"
                                long
# 309 "/lib/tcc/include/tccdefs.h"
                                             ,
# 309 "/lib/tcc/include/tccdefs.h"
                                               unsigned
# 309 "/lib/tcc/include/tccdefs.h"
                                               long
# 309 "/lib/tcc/include/tccdefs.h"
                                                            )
# 309 "/lib/tcc/include/tccdefs.h"
__asm__
# 309 "/lib/tcc/include/tccdefs.h"
(
# 309 "/lib/tcc/include/tccdefs.h"
"memalign"
# 309 "/lib/tcc/include/tccdefs.h"
)
# 309 "/lib/tcc/include/tccdefs.h"
;
# 310 "/lib/tcc/include/tccdefs.h"
              void
# 310 "/lib/tcc/include/tccdefs.h"
__builtin_free
# 310 "/lib/tcc/include/tccdefs.h"
                          (
# 310 "/lib/tcc/include/tccdefs.h"
                           void
# 310 "/lib/tcc/include/tccdefs.h"
                               *
# 310 "/lib/tcc/include/tccdefs.h"
                                )
# 310 "/lib/tcc/include/tccdefs.h"
__asm__
# 310 "/lib/tcc/include/tccdefs.h"
(
# 310 "/lib/tcc/include/tccdefs.h"
"free"
# 310 "/lib/tcc/include/tccdefs.h"
)
# 310 "/lib/tcc/include/tccdefs.h"
;
# 311 "/lib/tcc/include/tccdefs.h"
       void
# 311 "/lib/tcc/include/tccdefs.h"
           *
# 311 "/lib/tcc/include/tccdefs.h"
__builtin_alloca
# 311 "/lib/tcc/include/tccdefs.h"
                      (
# 311 "/lib/tcc/include/tccdefs.h"
                       unsigned
# 311 "/lib/tcc/include/tccdefs.h"
                       long
# 311 "/lib/tcc/include/tccdefs.h"
                                    )
# 311 "/lib/tcc/include/tccdefs.h"
__asm__
# 311 "/lib/tcc/include/tccdefs.h"
(
# 311 "/lib/tcc/include/tccdefs.h"
"alloca"
# 311 "/lib/tcc/include/tccdefs.h"
)
# 311 "/lib/tcc/include/tccdefs.h"
;
# 312 "/lib/tcc/include/tccdefs.h"
void
# 312 "/lib/tcc/include/tccdefs.h"
     *
# 312 "/lib/tcc/include/tccdefs.h"
      alloca
# 312 "/lib/tcc/include/tccdefs.h"
            (
# 312 "/lib/tcc/include/tccdefs.h"
             unsigned
# 312 "/lib/tcc/include/tccdefs.h"
             long
# 312 "/lib/tcc/include/tccdefs.h"
                          )
# 312 "/lib/tcc/include/tccdefs.h"
                           ;
# 313 "/lib/tcc/include/tccdefs.h"
          void
# 313 "/lib/tcc/include/tccdefs.h"
__builtin_abort
# 313 "/lib/tcc/include/tccdefs.h"
                       (
# 313 "/lib/tcc/include/tccdefs.h"
                        void
# 313 "/lib/tcc/include/tccdefs.h"
                            )
# 313 "/lib/tcc/include/tccdefs.h"
__asm__
# 313 "/lib/tcc/include/tccdefs.h"
(
# 313 "/lib/tcc/include/tccdefs.h"
"abort"
# 313 "/lib/tcc/include/tccdefs.h"
)
# 313 "/lib/tcc/include/tccdefs.h"
;
# 330 "/lib/tcc/include/tccdefs.h"
int
# 330 "/lib/tcc/include/tccdefs.h"
__builtin_ffs
# 330 "/lib/tcc/include/tccdefs.h"
(
# 330 "/lib/tcc/include/tccdefs.h"
int
# 330 "/lib/tcc/include/tccdefs.h"
)
# 330 "/lib/tcc/include/tccdefs.h"
;
# 330 "/lib/tcc/include/tccdefs.h"
int
# 330 "/lib/tcc/include/tccdefs.h"
__builtin_ffsl
# 330 "/lib/tcc/include/tccdefs.h"
(
# 330 "/lib/tcc/include/tccdefs.h"
long
# 330 "/lib/tcc/include/tccdefs.h"
)
# 330 "/lib/tcc/include/tccdefs.h"
;
# 330 "/lib/tcc/include/tccdefs.h"
int
# 330 "/lib/tcc/include/tccdefs.h"
__builtin_ffsll
# 330 "/lib/tcc/include/tccdefs.h"
(
# 330 "/lib/tcc/include/tccdefs.h"
long
# 330 "/lib/tcc/include/tccdefs.h"
long
# 330 "/lib/tcc/include/tccdefs.h"
)
# 330 "/lib/tcc/include/tccdefs.h"
;
# 331 "/lib/tcc/include/tccdefs.h"
int
# 331 "/lib/tcc/include/tccdefs.h"
__builtin_clz
# 331 "/lib/tcc/include/tccdefs.h"
(
# 331 "/lib/tcc/include/tccdefs.h"
                      unsigned
# 331 "/lib/tcc/include/tccdefs.h"
int
# 331 "/lib/tcc/include/tccdefs.h"
)
# 331 "/lib/tcc/include/tccdefs.h"
;
# 331 "/lib/tcc/include/tccdefs.h"
int
# 331 "/lib/tcc/include/tccdefs.h"
__builtin_clzl
# 331 "/lib/tcc/include/tccdefs.h"
(
# 331 "/lib/tcc/include/tccdefs.h"
                      unsigned
# 331 "/lib/tcc/include/tccdefs.h"
long
# 331 "/lib/tcc/include/tccdefs.h"
)
# 331 "/lib/tcc/include/tccdefs.h"
;
# 331 "/lib/tcc/include/tccdefs.h"
int
# 331 "/lib/tcc/include/tccdefs.h"
__builtin_clzll
# 331 "/lib/tcc/include/tccdefs.h"
(
# 331 "/lib/tcc/include/tccdefs.h"
                      unsigned
# 331 "/lib/tcc/include/tccdefs.h"
long
# 331 "/lib/tcc/include/tccdefs.h"
long
# 331 "/lib/tcc/include/tccdefs.h"
)
# 331 "/lib/tcc/include/tccdefs.h"
;
# 332 "/lib/tcc/include/tccdefs.h"
int
# 332 "/lib/tcc/include/tccdefs.h"
__builtin_ctz
# 332 "/lib/tcc/include/tccdefs.h"
(
# 332 "/lib/tcc/include/tccdefs.h"
                      unsigned
# 332 "/lib/tcc/include/tccdefs.h"
int
# 332 "/lib/tcc/include/tccdefs.h"
)
# 332 "/lib/tcc/include/tccdefs.h"
;
# 332 "/lib/tcc/include/tccdefs.h"
int
# 332 "/lib/tcc/include/tccdefs.h"
__builtin_ctzl
# 332 "/lib/tcc/include/tccdefs.h"
(
# 332 "/lib/tcc/include/tccdefs.h"
                      unsigned
# 332 "/lib/tcc/include/tccdefs.h"
long
# 332 "/lib/tcc/include/tccdefs.h"
)
# 332 "/lib/tcc/include/tccdefs.h"
;
# 332 "/lib/tcc/include/tccdefs.h"
int
# 332 "/lib/tcc/include/tccdefs.h"
__builtin_ctzll
# 332 "/lib/tcc/include/tccdefs.h"
(
# 332 "/lib/tcc/include/tccdefs.h"
                      unsigned
# 332 "/lib/tcc/include/tccdefs.h"
long
# 332 "/lib/tcc/include/tccdefs.h"
long
# 332 "/lib/tcc/include/tccdefs.h"
)
# 332 "/lib/tcc/include/tccdefs.h"
;
# 333 "/lib/tcc/include/tccdefs.h"
int
# 333 "/lib/tcc/include/tccdefs.h"
__builtin_clrsb
# 333 "/lib/tcc/include/tccdefs.h"
(
# 333 "/lib/tcc/include/tccdefs.h"
int
# 333 "/lib/tcc/include/tccdefs.h"
)
# 333 "/lib/tcc/include/tccdefs.h"
;
# 333 "/lib/tcc/include/tccdefs.h"
int
# 333 "/lib/tcc/include/tccdefs.h"
__builtin_clrsbl
# 333 "/lib/tcc/include/tccdefs.h"
(
# 333 "/lib/tcc/include/tccdefs.h"
long
# 333 "/lib/tcc/include/tccdefs.h"
)
# 333 "/lib/tcc/include/tccdefs.h"
;
# 333 "/lib/tcc/include/tccdefs.h"
int
# 333 "/lib/tcc/include/tccdefs.h"
__builtin_clrsbll
# 333 "/lib/tcc/include/tccdefs.h"
(
# 333 "/lib/tcc/include/tccdefs.h"
long
# 333 "/lib/tcc/include/tccdefs.h"
long
# 333 "/lib/tcc/include/tccdefs.h"
)
# 333 "/lib/tcc/include/tccdefs.h"
;
# 334 "/lib/tcc/include/tccdefs.h"
int
# 334 "/lib/tcc/include/tccdefs.h"
__builtin_popcount
# 334 "/lib/tcc/include/tccdefs.h"
(
# 334 "/lib/tcc/include/tccdefs.h"
                           unsigned
# 334 "/lib/tcc/include/tccdefs.h"
int
# 334 "/lib/tcc/include/tccdefs.h"
)
# 334 "/lib/tcc/include/tccdefs.h"
;
# 334 "/lib/tcc/include/tccdefs.h"
int
# 334 "/lib/tcc/include/tccdefs.h"
__builtin_popcountl
# 334 "/lib/tcc/include/tccdefs.h"
(
# 334 "/lib/tcc/include/tccdefs.h"
                           unsigned
# 334 "/lib/tcc/include/tccdefs.h"
long
# 334 "/lib/tcc/include/tccdefs.h"
)
# 334 "/lib/tcc/include/tccdefs.h"
;
# 334 "/lib/tcc/include/tccdefs.h"
int
# 334 "/lib/tcc/include/tccdefs.h"
__builtin_popcountll
# 334 "/lib/tcc/include/tccdefs.h"
(
# 334 "/lib/tcc/include/tccdefs.h"
                           unsigned
# 334 "/lib/tcc/include/tccdefs.h"
long
# 334 "/lib/tcc/include/tccdefs.h"
long
# 334 "/lib/tcc/include/tccdefs.h"
)
# 334 "/lib/tcc/include/tccdefs.h"
;
# 335 "/lib/tcc/include/tccdefs.h"
int
# 335 "/lib/tcc/include/tccdefs.h"
__builtin_parity
# 335 "/lib/tcc/include/tccdefs.h"
(
# 335 "/lib/tcc/include/tccdefs.h"
                         unsigned
# 335 "/lib/tcc/include/tccdefs.h"
int
# 335 "/lib/tcc/include/tccdefs.h"
)
# 335 "/lib/tcc/include/tccdefs.h"
;
# 335 "/lib/tcc/include/tccdefs.h"
int
# 335 "/lib/tcc/include/tccdefs.h"
__builtin_parityl
# 335 "/lib/tcc/include/tccdefs.h"
(
# 335 "/lib/tcc/include/tccdefs.h"
                         unsigned
# 335 "/lib/tcc/include/tccdefs.h"
long
# 335 "/lib/tcc/include/tccdefs.h"
)
# 335 "/lib/tcc/include/tccdefs.h"
;
# 335 "/lib/tcc/include/tccdefs.h"
int
# 335 "/lib/tcc/include/tccdefs.h"
__builtin_parityll
# 335 "/lib/tcc/include/tccdefs.h"
(
# 335 "/lib/tcc/include/tccdefs.h"
                         unsigned
# 335 "/lib/tcc/include/tccdefs.h"
long
# 335 "/lib/tcc/include/tccdefs.h"
long
# 335 "/lib/tcc/include/tccdefs.h"
)
# 335 "/lib/tcc/include/tccdefs.h"
;
# 4 "/lib/tcc/include/stddef.h"
typedef
# 4 "/lib/tcc/include/stddef.h"
        unsigned
# 4 "/lib/tcc/include/stddef.h"
        long
# 4 "/lib/tcc/include/stddef.h"
                      size_t
# 4 "/lib/tcc/include/stddef.h"
                            ;
# 5 "/lib/tcc/include/stddef.h"
typedef
# 5 "/lib/tcc/include/stddef.h"
        long
# 5 "/lib/tcc/include/stddef.h"
                         ssize_t
# 5 "/lib/tcc/include/stddef.h"
                                ;
# 6 "/lib/tcc/include/stddef.h"
typedef
# 6 "/lib/tcc/include/stddef.h"
        int
# 6 "/lib/tcc/include/stddef.h"
                       wchar_t
# 6 "/lib/tcc/include/stddef.h"
                              ;
# 7 "/lib/tcc/include/stddef.h"
typedef
# 7 "/lib/tcc/include/stddef.h"
        long
# 7 "/lib/tcc/include/stddef.h"
                         ptrdiff_t
# 7 "/lib/tcc/include/stddef.h"
                                  ;
# 8 "/lib/tcc/include/stddef.h"
typedef
# 8 "/lib/tcc/include/stddef.h"
        long
# 8 "/lib/tcc/include/stddef.h"
                         intptr_t
# 8 "/lib/tcc/include/stddef.h"
                                 ;
# 9 "/lib/tcc/include/stddef.h"
typedef
# 9 "/lib/tcc/include/stddef.h"
        unsigned
# 9 "/lib/tcc/include/stddef.h"
        long
# 9 "/lib/tcc/include/stddef.h"
                      uintptr_t
# 9 "/lib/tcc/include/stddef.h"
                               ;
# 12 "/lib/tcc/include/stddef.h"
typedef
# 12 "/lib/tcc/include/stddef.h"
        union
# 12 "/lib/tcc/include/stddef.h"
              {
# 12 "/lib/tcc/include/stddef.h"
                long
# 12 "/lib/tcc/include/stddef.h"
                     long
# 12 "/lib/tcc/include/stddef.h"
                          __ll
# 12 "/lib/tcc/include/stddef.h"
                              ;
# 12 "/lib/tcc/include/stddef.h"
                                long
# 12 "/lib/tcc/include/stddef.h"
                                     double
# 12 "/lib/tcc/include/stddef.h"
                                            __ld
# 12 "/lib/tcc/include/stddef.h"
                                                ;
# 12 "/lib/tcc/include/stddef.h"
                                                  }
# 12 "/lib/tcc/include/stddef.h"
                                                    max_align_t
# 12 "/lib/tcc/include/stddef.h"
                                                               ;
# 22 "/lib/tcc/include/stddef.h"
void
# 22 "/lib/tcc/include/stddef.h"
     *
# 22 "/lib/tcc/include/stddef.h"
      alloca
# 22 "/lib/tcc/include/stddef.h"
            (
# 22 "/lib/tcc/include/stddef.h"
             size_t
# 22 "/lib/tcc/include/stddef.h"
                    size
# 22 "/lib/tcc/include/stddef.h"
                        )
# 22 "/lib/tcc/include/stddef.h"
                         ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
struct
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
       __attribute__
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                    (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                     (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                      packed
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                            )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                             )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                               S
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                 {
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                   unsigned
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                            a
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                             :
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                              3
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                               ,
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                 b
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                  :
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                   5
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                     __attribute__
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                  (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                   (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                    aligned
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                           (
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                            8
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                             )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                              )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                               )
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                ,
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                  c
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                   :
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                    2
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                     ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                       unsigned
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                char
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                     tail
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                         ;
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                           }
# 2 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                            ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
int
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
    main
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
        (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
         void
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
             )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
               {
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                 struct
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                        S
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                          s
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                           ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                             unsigned
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                      char
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                           *
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                            p
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                             =
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                              (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                               unsigned
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                        char
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                             *
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                              )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                               &
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                s
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                 ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                   unsigned
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                            i
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                             ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                               for
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                  (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                   i
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                    =
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                     0
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                      ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                       i
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                        <
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                         sizeof
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                s
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                 ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                  ++
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                    i
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                     )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                       p
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                        [
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                         i
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                          ]
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                           =
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                            0
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                             ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                               s
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                .
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                 a
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                  =
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                   5
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                    ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                      s
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                       .
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                        b
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                         =
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                          19
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                            ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                              s
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                               .
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                c
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                 =
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                  2
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                   ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                    s
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                     .
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                      tail
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                          =
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                           71
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                             ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                               return
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                      s
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                       .
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                        a
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                         !=
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                           (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                            5
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                             )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                               ||
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                                  s
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                                   .
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                                    b
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                                     !=
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                                       (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                                        19
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                                          )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                                            ||
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                                               s
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                                                .
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                                                 c
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                                                  !=
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                                                    (
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                                                     2
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                                                      )
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                                                        ||
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                                                           s
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                                                            .
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                                                             tail
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                                                                 !=
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                                                                   71
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                                                                     ;
# 3 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/c/tests/bitfield-attributes/aggregate-packed-auto.c"
                                                                                                                                                                                                       }

