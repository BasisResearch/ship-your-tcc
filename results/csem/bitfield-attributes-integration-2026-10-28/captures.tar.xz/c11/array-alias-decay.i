# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/array-decay/array-alias-decay.c"
# 1 "<command line>" 1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/array-decay/array-alias-decay.c" 2
typedef int A[2] __attribute__((aligned(32))); A a; int main(void){return _Alignof(__typeof__(a))!=32 || _Alignof(__typeof__(a+0))!=8 || __alignof__(a)!=32;}
