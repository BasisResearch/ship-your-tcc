# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_union_same_auto.c"
# 1 "<command line>" 1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_union_same_auto.c" 2
union U {struct {int a[3]; int b;} s; int n;};
int main(void){union U v={.s.a[0]=1,2,.s.a[2]=3,4}; return !(v.s.a[0]==1 && v.s.a[1]==2 && v.s.a[2]==3 && v.s.b==4);}
