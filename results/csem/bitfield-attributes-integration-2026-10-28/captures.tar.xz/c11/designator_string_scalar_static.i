# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_string_scalar_static.c"
# 1 "<command line>" 1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_string_scalar_static.c" 2
struct S {char a[4]; int z;};
static struct S v={.a[1]='x','y',0,3};
int main(void){return !(v.a[0]==0 && v.a[1]=='x' && v.a[2]=='y' && v.a[3]==0 && v.z==3);}
