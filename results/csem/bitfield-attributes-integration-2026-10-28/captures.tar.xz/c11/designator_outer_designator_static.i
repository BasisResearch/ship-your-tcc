# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_outer_designator_static.c"
# 1 "<command line>" 1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_outer_designator_static.c" 2
struct S {int a[3]; int z;};
static struct S v={.a=1,.z=4};
int main(void){return !(v.a[0]==1 && v.a[1]==0 && v.a[2]==0 && v.z==4);}
