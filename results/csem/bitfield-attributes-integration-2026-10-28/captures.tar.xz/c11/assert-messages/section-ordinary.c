int x __attribute__((section("x")));
int main(void){return 0;}
