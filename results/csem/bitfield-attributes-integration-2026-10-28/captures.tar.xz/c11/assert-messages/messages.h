#define MSG L"included" " message"
struct Header {_Static_assert(1,MSG); int n;};
