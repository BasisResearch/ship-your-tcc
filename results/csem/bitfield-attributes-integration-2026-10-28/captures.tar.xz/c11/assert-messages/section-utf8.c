int x __attribute__((section(u8"x")));
int main(void){return 0;}
