int x; extern int y __attribute__((alias(u8"x")));
int main(void){return 0;}
