int x __asm__("x");
int main(void){return 0;}
