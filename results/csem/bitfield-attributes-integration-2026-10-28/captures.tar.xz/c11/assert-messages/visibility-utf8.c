int x __attribute__((visibility(u8"default")));
int main(void){return 0;}
