int x __asm__(u8"x");
int main(void){return 0;}
