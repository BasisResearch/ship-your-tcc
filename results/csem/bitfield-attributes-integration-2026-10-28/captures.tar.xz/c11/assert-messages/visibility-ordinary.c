int x __attribute__((visibility("default")));
int main(void){return 0;}
