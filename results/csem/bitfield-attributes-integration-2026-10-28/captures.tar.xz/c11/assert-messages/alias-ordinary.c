int x; extern int y __attribute__((alias("x")));
int main(void){return 0;}
