#include "libtcc.h"
int main(int argc, char **argv){
TCCState *s=tcc_new(); tcc_set_lib_path(s,argv[1]);
tcc_set_options(s,"-std=c11"); tcc_set_output_type(s,TCC_OUTPUT_OBJ);
if(tcc_compile_string(s,"\?\?=define N 4\?\?/\n2\nint api(void)\?\?<return N;\?\?>\n")) return 1;
if(tcc_output_file(s,argv[2])) return 2; tcc_delete(s); return 0;}
