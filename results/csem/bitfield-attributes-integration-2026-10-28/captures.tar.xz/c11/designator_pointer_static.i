# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_pointer_static.c"
# 1 "<command line>" 1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_pointer_static.c" 2
int x=7; struct S {int *a[2]; int z;};
static struct S v={.a[0]=&x,&x,3};
int main(void){return !(*v.a[0]==7 && *v.a[1]==7 && v.z==3);}
