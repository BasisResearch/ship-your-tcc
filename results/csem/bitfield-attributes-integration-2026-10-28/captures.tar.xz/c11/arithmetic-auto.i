# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/array-decay/arithmetic-auto.c"
# 1 "<command line>" 1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/array-decay/arithmetic-auto.c" 2
typedef int A[2] __attribute__((aligned(32))); typedef A B;
int main(void){B a={3,7};return _Alignof(__typeof__(a+0))!=8 || _Alignof(__typeof__(0+a))!=8 || _Alignof(__typeof__(a-0))!=8 || (a+1)-a!=1;}
