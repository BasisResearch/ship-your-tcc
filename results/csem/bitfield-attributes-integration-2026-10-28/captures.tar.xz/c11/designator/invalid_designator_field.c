struct S {int a[2];}; struct S v={.b[0]=1};
int main(void){return 0;}
