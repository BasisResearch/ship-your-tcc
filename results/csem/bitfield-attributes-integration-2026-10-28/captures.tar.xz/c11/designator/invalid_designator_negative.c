int v[2][2]={[0][-1]=1};
int main(void){return 0;}
