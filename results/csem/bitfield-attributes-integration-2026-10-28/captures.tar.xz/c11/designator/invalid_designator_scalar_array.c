struct S {int x;}; struct S v={.x[0]=1};
int main(void){return 0;}
