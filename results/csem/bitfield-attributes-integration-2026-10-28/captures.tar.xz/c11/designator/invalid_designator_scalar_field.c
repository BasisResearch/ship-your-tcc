struct S {int x;}; struct S v={.x.y=1};
int main(void){return 0;}
