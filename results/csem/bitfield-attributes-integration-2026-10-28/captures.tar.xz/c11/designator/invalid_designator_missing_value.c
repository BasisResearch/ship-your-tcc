struct S {int a[2];}; struct S v={.a[0]=,};
int main(void){return 0;}
