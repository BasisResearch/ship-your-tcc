union U {int a[2];int z;}; union U v={.a[0]=1,2,3};
int main(void){return 0;}
