struct S {int a[2];int z;}; struct S v={.a[0]=1,2,3,4};
int main(void){return 0;}
