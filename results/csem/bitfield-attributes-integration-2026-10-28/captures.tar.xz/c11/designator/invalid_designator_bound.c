int v[2][2]={[0][2]=1};
int main(void){return 0;}
