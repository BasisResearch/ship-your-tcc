# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_deep_static.c"
# 1 "<command line>" 1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_deep_static.c" 2
struct A {int a[2];int z;}; struct B {struct A a[2];int z;}; struct C {struct B a[2];int z;};
static struct C v[2]={[0].a[0].a[0].a[0]=1,2,3,4,5,6,7,8,9,10};
int main(void){return !(v[0].a[0].a[0].a[0]==1 && v[0].a[0].a[0].a[1]==2 && v[0].a[0].a[0].z==3 && v[0].a[0].a[1].a[0]==4 && v[0].a[0].a[1].z==6 && v[0].a[0].z==7 && v[0].a[1].a[0].a[0]==8 && v[0].a[1].a[0].z==10);}
