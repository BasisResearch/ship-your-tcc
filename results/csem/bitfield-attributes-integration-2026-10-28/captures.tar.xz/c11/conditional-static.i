# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/array-decay/conditional-static.c"
# 1 "<command line>" 1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/array-decay/conditional-static.c" 2
typedef int A[2] __attribute__((aligned(32))); typedef A B;
int main(void){static B a={3,7};return _Alignof(__typeof__(1?a:a))!=8 || _Alignof(__typeof__(0?a:0))!=8 || _Alignof(__typeof__(1?0:a))!=8 || _Alignof(__typeof__(1?a:(int*)0))!=8;}
