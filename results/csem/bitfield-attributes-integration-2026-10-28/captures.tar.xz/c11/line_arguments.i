# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/line/line_arguments.c"
# 1 "<command line>" 1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/line/line_arguments.c" 2
# 500 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/line/line_arguments.c"
static int a=501;
# 510 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/line/line_arguments.c"
static int b=((510)+(510));
# 520 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/line/line_arguments.c"
static int c=(520+(521));
# 530 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/line/line_arguments.c"
static int d=(530+(530));

int main(void){return a!=501||b!=1020||c!=1041||d!=1060;}
