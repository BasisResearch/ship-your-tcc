# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_braced_union_auto.c"
# 1 "<command line>" 1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_braced_union_auto.c" 2
union U {int n; int a[2];}; struct S {union U u; int z;};
int main(void){struct S v={.u.a={1,2},3}; return !(v.u.a[0]==1 && v.u.a[1]==2 && v.z==3);}
