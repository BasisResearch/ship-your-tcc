#define F(x) (__LINE__+(x))
#define I(x) x
#line 700
static int a=__LINE__\
/*
 comment */;
#line 710
static int b=F/*\
 comment
*/(0);
#line 720
static int c=I(/*
*/__LINE__\
);
#line 730
static int d=__LINE__\
// continued??/
comment
;
int main(void){return a!=700||b!=710||c!=721||d!=730;}
