#line 1200 "virtual/header.h"
static int header_line=__LINE__\
;
#define HEADER_L __LINE__
