#define I(x) x
#define D(x) ((x)+(x))
#define L __LINE__
#line 300
static int a=__LINE__\
;
#line 400
static int b=L??/
\
;
#line 500
static int c=I(
__LINE__\
);
#line 600
static int d=D(__COUNTER__+__LINE__\
);
int main(void){return a!=300||b!=400||c!=501||d!=1200||__COUNTER__!=1;}
