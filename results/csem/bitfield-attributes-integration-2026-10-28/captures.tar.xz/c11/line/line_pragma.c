#define L _Pragma("pack(push,1)") static int a=__LINE__;
#line 900
L\

_Pragma("pack(pop)")
int main(void){return a!=900;}
