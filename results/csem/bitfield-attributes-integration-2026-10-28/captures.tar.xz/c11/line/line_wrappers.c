#define L __LINE__
#define W L
#define F(x) (__LINE__+(x))
#line 400
static int a=W\
;
#line 410
static int b=F\
(0);
#line 420
static int c=F(
0
);
int main(void){return a!=400||b!=410||c!=420;}
