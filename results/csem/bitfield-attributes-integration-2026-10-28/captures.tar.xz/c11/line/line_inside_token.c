#line 300
static int a=__LI\
NE__\
;
int main(void){return a!=300;}
