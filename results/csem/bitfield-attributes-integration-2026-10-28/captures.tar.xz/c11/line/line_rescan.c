#define I(x) x
#define F(x) (__LINE__+(x))
#define E(x,y) x y
#define C(x,y) x##y
#line 880
static int a=E(,F)(
__LINE__);
#line 890
static int b=I(C)(__LI,NE__)\
;
int main(void){return a!=1761||b!=890;}
