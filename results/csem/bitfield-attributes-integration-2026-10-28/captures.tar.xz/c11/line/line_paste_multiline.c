#define C(a,b) a##b + __LINE__
#line 850
static int a=C(
__LI,
NE__);
#line 860
static int b=C(,
__LINE__);
#line 870
static int c=C(__LINE__,
);
int main(void){return a!=1700||b!=1720||c!=1740;}
