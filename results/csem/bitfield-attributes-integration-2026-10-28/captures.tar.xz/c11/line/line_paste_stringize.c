#define CAT(a,b) a##b
#define S(x) #x
#define I(x) x
#line 800
static int a=CAT(__LI,NE__)\
;
#line 810
static int b=CAT(, __LINE__)\
;
#line 820
static char s[]=S(__LINE__\
+ __COUNTER__);
static int c=__COUNTER__;
int main(void){return a!=800||b!=810||c!=0||sizeof(s)!=22||s[0]!=95;}
