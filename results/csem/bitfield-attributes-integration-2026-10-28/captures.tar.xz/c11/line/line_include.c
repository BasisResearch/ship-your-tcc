#line 1000 "virtual/parent.c"
static int before=__LINE__\
;
#include "line_fixture.h"
static int after=HEADER_L\
;
#line 1100 "another.c"
static int remap=__LINE__??/
;
int main(void){return before!=1000||header_line!=1200||after!=1003||remap!=1100;}
