#line 300
static int a=__LINE__??/
;
int main(void){return a!=300;}
