#define D(x) ((x)+(x))
#define I(x) x
#line 600
static int a=D(__COUNTER__+__LINE__\
);
static int b=__COUNTER__;
#line 610
static int c=I(__LINE__\
)+__LINE__;
int main(void){return a!=1200||b!=1||c!=1221;}
