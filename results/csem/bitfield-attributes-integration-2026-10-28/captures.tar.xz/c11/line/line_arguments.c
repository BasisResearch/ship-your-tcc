#define I(x) x
#define D(x) ((x)+(x))
#define F(x) (__LINE__+(x))
#line 500
static int a=I(
__LINE__\
);
#line 510
static int b=D(__LINE__\
);
#line 520
static int c=I(F)(
__LINE__);
#line 530
static int d=F(I(__LINE__\
));
int main(void){return a!=501||b!=1020||c!=1041||d!=1060;}
