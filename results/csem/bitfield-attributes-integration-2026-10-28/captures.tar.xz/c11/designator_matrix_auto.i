# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_matrix_auto.c"
# 1 "<command line>" 1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_matrix_auto.c" 2

int main(void){int v[2][3]={[0][1]=1,2,3,4,5}; return !(v[0][0]==0 && v[0][1]==1 && v[0][2]==2 && v[1][0]==3 && v[1][1]==4 && v[1][2]==5);}
