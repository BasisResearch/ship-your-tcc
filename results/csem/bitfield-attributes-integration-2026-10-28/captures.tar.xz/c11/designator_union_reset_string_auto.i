# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_union_reset_string_auto.c"
# 1 "<command line>" 1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_union_reset_string_auto.c" 2
union U {char a[4];int n;}; struct S {union U u;int z;};
int main(void){struct S v={.u.a="abc",.u.n=7,.u.a="xy",3}; return !(v.u.a[0]=='x' && v.u.a[1]=='y' && v.u.a[2]==0 && v.z==3);}
