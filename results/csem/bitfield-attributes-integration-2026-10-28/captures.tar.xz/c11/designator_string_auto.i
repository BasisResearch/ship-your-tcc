# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_string_auto.c"
# 1 "<command line>" 1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_string_auto.c" 2
struct S {char a[2][4]; int z;};
int main(void){struct S v={.a[0]="ab","cd",3}; return !(v.a[0][0]=='a' && v.a[0][2]==0 && v.a[1][0]=='c' && v.a[1][2]==0 && v.z==3);}
