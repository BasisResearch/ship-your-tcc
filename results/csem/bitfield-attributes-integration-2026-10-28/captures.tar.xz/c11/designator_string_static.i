# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_string_static.c"
# 1 "<command line>" 1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_string_static.c" 2
struct S {char a[2][4]; int z;};
static struct S v={.a[0]="ab","cd",3};
int main(void){return !(v.a[0][0]=='a' && v.a[0][2]==0 && v.a[1][0]=='c' && v.a[1][2]==0 && v.z==3);}
