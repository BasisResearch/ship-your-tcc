# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_array_designator_auto.c"
# 1 "<command line>" 1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_array_designator_auto.c" 2

int main(void){int v[2][2]={1,[1][0]=2,3}; return !(v[0][0]==1 && v[0][1]==0 && v[1][0]==2 && v[1][1]==3);}
