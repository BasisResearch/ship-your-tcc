# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_reverse_auto.c"
# 1 "<command line>" 1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_reverse_auto.c" 2
struct S {int a[2];int z;};
int main(void){struct S v={.z=9,.a[0]=1,2,3}; return !(v.a[0]==1 && v.a[1]==2 && v.z==3);}
