# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_union_siblings_static.c"
# 1 "<command line>" 1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_union_siblings_static.c" 2
union U {int n;int a[2];}; struct S {union U a[2];int z;};
static struct S v={.a[0].a[0]=1,2,3,4};
int main(void){return !(v.a[0].a[0]==1 && v.a[0].a[1]==2 && v.a[1].n==3 && v.z==4);}
