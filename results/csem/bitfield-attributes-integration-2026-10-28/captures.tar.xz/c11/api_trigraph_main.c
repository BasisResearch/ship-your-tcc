int api(void); int main(void){return api()!=42;}
