# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_array_designator_static.c"
# 1 "<command line>" 1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_array_designator_static.c" 2

static int v[2][2]={1,[1][0]=2,3};
int main(void){return !(v[0][0]==1 && v[0][1]==0 && v[1][0]==2 && v[1][1]==3);}
