# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/line/line_boundary_0_6.c"
# 1 "<command line>" 1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/line/line_boundary_0_6.c" 2
# 1300 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/line/line_boundary_0_6.c"
static int a=                                                                                                                                                                                                                                                                                                                                                                                                               1300;

int main(void){return a!=1300;}
