# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/array-decay/initialize-auto.c"
# 1 "<command line>" 1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/array-decay/initialize-auto.c" 2
typedef int A[2] __attribute__((aligned(32))); typedef A B;
int main(void){B a={3,7}; int *p=a;return _Alignof(__typeof__(p))!=8 || p!=a || p[1]!=7 || _Alignof(__typeof__(a))!=32;}
