# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_union_switch_static.c"
# 1 "<command line>" 1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_union_switch_static.c" 2
union U {struct {int a[2]; int b;} s; int n;}; struct S {union U u; int z;};
static struct S v={.u.s.a[0]=9,8,.u.n=7,.u.s.a[0]=1,2,3,4};
int main(void){return !(v.u.s.a[0]==1 && v.u.s.a[1]==2 && v.u.s.b==3 && v.z==4);}
