# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_union_array_static.c"
# 1 "<command line>" 1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_union_array_static.c" 2
union U {struct {int a[2]; int b;} s; int n;};
static union U v[2]={[0].s.a[1]=1,2,3,4,5};
int main(void){return !(v[0].s.a[0]==0 && v[0].s.a[1]==1 && v[0].s.b==2 && v[1].s.a[0]==3 && v[1].s.a[1]==4 && v[1].s.b==5);}
