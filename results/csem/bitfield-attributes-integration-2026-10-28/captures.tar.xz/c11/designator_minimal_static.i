# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_minimal_static.c"
# 1 "<command line>" 1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_minimal_static.c" 2
struct S {int a[2]; int z;};
static struct S s={.a[0]=1,2,3};
int main(void){return !(s.a[0]==1 && s.a[1]==2 && s.z==3);}
