# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_elided_static.c"
# 1 "<command line>" 1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_elided_static.c" 2
struct S {int a[3]; int z;};
static struct S v={.a=1,2,3,4};
int main(void){return !(v.a[0]==1 && v.a[1]==2 && v.a[2]==3 && v.z==4);}
