# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/array-decay/element-referent.c"
# 1 "<command line>" 1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/array-decay/element-referent.c" 2
typedef struct {long x[4];} E __attribute__((aligned(32))); E a[2]; int main(void){return _Alignof(__typeof__(a+0))!=8 || _Alignof(__typeof__(*(a+0)))!=32 || sizeof(*(a+0))!=32 || _Alignof(__typeof__(*(&a)))!=32;}
