# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_trailing_padding_static.c"
# 1 "<command line>" 1
# 1 "/data/home/kirancodes/Documents/code/ship-your-tcc/.claude/worktrees/sol-c11-line/build/test-c11/designator/designator_trailing_padding_static.c" 2
struct A {int x;unsigned :3;}; struct S {struct A a;int y;};
static struct S v={.a.x=1,2};
int main(void){return !(v.a.x==1 && v.y==2);}
