from pathlib import Path
import hashlib,json,subprocess,os
root=Path(__file__).resolve().parents[1];w=root/'.claude/worktrees/sol-c11-line';out=root/'build/array-constraint-review-final';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
oracle=root/'build/csem-704c4e69-e6d8db56/cerberus-lean/_build/default/backend/driver/main.exe';runtime=root/'build/csem-704c4e69-e6d8db56/cerberus-lean/_build/install/default';raw=w/'.lake/build/bin/csem_raw';tcc=root/'build/array-constraint-tcc'
assert all(p.is_file() for p in [oracle,raw,tcc])
cases={'function-array':'int f[1](void); int main(void){return 0;}','void-array':'void a[1]; int main(void){return 0;}','function-array-local':'int main(void){int f[1](void);return 0;}','void-array-local':'int main(void){void a[1];return 0;}','function-pointer-array':'int (*f[1])(void); int main(void){return 0;}','int-array':'int a[1]; int main(void){return 0;}','incomplete-extern':'extern int a[]; int main(void){return 0;}','overaligned-array':'typedef int T __attribute__((aligned(16))); T a[1]; int main(void){return 0;}'}
cases.update({'function-array-typedef':'typedef int F(void); typedef F Bad[1]; int main(void){return 0;}','void-array-typedef':'typedef void V; typedef V Bad[1]; int main(void){return 0;}'})
pins={str(p):sha(p) for p in [oracle,raw,tcc,Path(__file__),root/'vendor/CSEM_REV']};rows=[]
for name,src in cases.items():
 p=out/(name+'.c');p.write_text(src+'\n');pins[str(p)]=sha(p);row={'case':name,'source':str(p.relative_to(root)),'engines':{}}
 commands={'raw':[raw,*(['--gnu'] if name=='overaligned-array' else []),'--checked','--semantic',p],'pristine-ocaml':[oracle,'--runtime='+str(runtime),'--nolibc','--exec','--batch','--mode=exhaustive',p],'gcc':['gcc','-std=c11','-pedantic-errors','-fsyntax-only',p],'tcc':[tcc,'-std=c11','-c',p,'-o',out/(name+'.o')]}
 for engine,cmd in commands.items():
  cmd=list(map(str,cmd));q=subprocess.run(cmd,cwd=root,capture_output=True,timeout=120,env={**os.environ,'LEAN_ABORT_ON_PANIC':'1'})
  for suffix,data in [('stdout',q.stdout),('stderr',q.stderr)]: (out/(name+'.'+engine+'.'+suffix)).write_bytes(data)
  r={'command':cmd,'exit':q.returncode,'stdout_sha256':hashlib.sha256(q.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(q.stderr).hexdigest()}
  if engine=='raw' and q.returncode==0:r['semantics']=json.loads(q.stdout).get('semantics')
  if engine=='pristine-ocaml':r['verdicts']=[l for l in q.stdout.decode(errors='replace').splitlines() if l.startswith(('Defined','Undefined','Error'))]
  row['engines'][engine]=r
 rows.append(row);print(name,{n:(r.get('semantics') if n=='raw' else r.get('verdicts',r['exit'])) for n,r in row['engines'].items()},flush=True)
assert all(sha(p)==h for p,h in pins.items())
(out/'report.json').write_text(json.dumps({'pins':pins,'rows':rows},indent=2)+'\n')
