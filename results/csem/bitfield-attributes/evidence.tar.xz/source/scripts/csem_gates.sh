#!/usr/bin/env bash
# csem_gates.sh — the fork's own gates, on the root project's 4.34 build
# (scripts/check.sh --csem runs this).
#
#   scripts/csem_gates.sh [--no-build] [--no-lane]
#
# After csem/scripts/test_unit.sh (the fork's row-1 gate), with paths for the
# root Lake project:
#   1. copy-set sync and Lean lem-sync stamp (csem/tools)
#   2. build: LemLib, LemLibTests, CerberusLean, CerberusLeanTest, csem_run,
#      the fork's unit executables, TccCSem (scripts/csem_build.sh: 12 GB cap,
#      shared Lake lock)
#   3. the unit executables, with test_unit.sh's arguments, from
#      csem/lean_frontend
#   4. exec purity (+ selftest plants), exec totality (+ plants), the axiom
#      census (csem/scripts/check_theorem_axioms.sh), the sorry-token census
#   5. generator drift (scripts/csem_regen.sh --check; SKIP without lem)
#   6. the exec lane against the OCaml oracle on csem/tests/minimal
#      (scripts/csem_lane.py; SKIP without the oracle)
# Fails on the first failing stage.
set -uo pipefail
source "$(dirname "$0")/csem_env.sh"
cd "$_repo"
build=1; lane=1
for a in "$@"; do
  case "$a" in --no-build) build=0;; --no-lane) lane=0;; *) echo "usage: $0 [--no-build] [--no-lane]"; exit 2;; esac
done
fail() { echo "csem_gates: FAIL: $*"; exit 1; }
export LC_ALL=C CERB_MEM_MAX=12G CSEM_LEMLEAN

UNIT=(core-parser-test effects-proof-test totality-proof-test fresh-int-test pp-test
      fuel-exemplar-test monadic-failstop-test allocator-soundness-test allocation-oracle-test float-literal-test
      are-compatible-test many-restatement-test opaque-failure-test enum-data-test
      run-digest-test cabs-import-test match-pattern-arity-test memory-access-test
      reconstruct-legacy-test pnvi-arms-test stop-test core-quote-test ieee-test ieee-integration-test)

echo "== csem (1) copy-set sync, lem-sync stamp"
csem/tools/check_handwritten_sync.sh || fail "hand-written copies drifted (scripts/csem_regen.sh)"
csem/tools/check_lem_sync.sh --check-lean || fail "lem-sync stamp"

if [ $build = 1 ]; then
  echo "== csem (2) build"
  # The raw bitfield checks below run before check.sh's later raw audit stage.
  # Rebuild their executables here; a preceding focused build is not a dependency.
  scripts/csem_build.sh LemLib LemLibTests CerberusLean CerberusLeanTest csem_run csem_raw csem_cparse TccCSem "${UNIT[@]}" \
    || fail "CSem build"
fi

echo "== csem (3) unit executables"
for t in "${UNIT[@]}"; do
  args=()
  case "$t" in
    ieee-test) args=(native 1000 17);;
    monadic-failstop-test) args=(2 17);;
    core-quote-test) args=(--local-controls);;
    match-pattern-arity-test|pnvi-arms-test) args=(17);;
    memory-access-test) args=(17 0 on);;
  esac
  if (cd csem/lean_frontend && LEAN_ABORT_ON_PANIC=1 "$_repo/.lake/build/bin/$t" "${args[@]}" >/dev/null 2>&1); then
    echo "  ok   $t"
  else
    fail "unit executable $t (run: cd csem/lean_frontend && $_repo/.lake/build/bin/$t ${args[*]})"
  fi
done

# Current upstream outcome envelopes: codec/frame plants and real fail-stop captures.
python3 csem/scripts/test_stops.py --lean-bin "$_repo/.lake/build/bin/stop-test" \
  || fail "structured stop codec/capture plants"

# Require the OCaml engine built from these exact shared source bytes, rather
# than treating current pristine upstream's item-U refusal as a comparison.
fork=$(scripts/csem_fork_oracle.sh --path) || fail "matching shared-source OCaml engine required"
export CSEM_ORACLE="$fork/_build/default/backend/driver/main.exe"
export CSEM_RUNTIME="$fork/_build/install/default"

echo "== csem (3a) allocation policies, default equivalence and independent choices"
python3 scripts/allocation_oracle_check.py --out build/allocation-gate || fail "allocation replay evidence"
python3 scripts/allocation_default_check.py --out build/allocation-gate || fail "default allocation equivalence"

echo "== csem (3b) C11 union initializer specified outcomes"
python3 scripts/gen_union_c11_observation.py --check || fail "C11 union observation fixture drift"
python3 scripts/gen_union_suite.py --check || fail "union suite batch fixture drift"
python3 csem/scripts/check_union_initializers.py --selftest || fail "C11 union initialization"

echo "== csem (3c) C11 anonymous members"
python3 scripts/gen_anonymous_fixtures.py --check || fail "anonymous fixture drift"
python3 scripts/test_anonymous_csem.py --report build/anonymous-gate.json || fail "anonymous member semantics"

echo "== csem (3d) C11 and GNU bitfield semantics; placement diagnostics separate"
python3 scripts/gen_bitfield_fixtures.py --check || fail "bitfield fixture drift"
bitfield_out=$(mktemp -d "$_repo/build/bitfields-gate.XXXXXX")
python3 scripts/test_bitfields.py --strict-gnu --out "$bitfield_out" || fail "C11/GNU bitfield semantics/constraints"
python3 scripts/gen_bitfield_attribute_fixtures.py --check || fail "bitfield attribute fixture drift"
bitattr_out=$(mktemp -d "$_repo/build/bitattr-gate.XXXXXX")
rmdir "$bitattr_out"
python3 scripts/check_bitfield_attributes.py --out "$bitattr_out" || fail "per-member GNU bitfield ownership/layout (artifacts: $bitattr_out)"

echo "== csem (4) purity, totality, axiom census, sorry token"
csem/scripts/check_exec_purity.sh --selftest | tail -1 || fail "exec purity selftest"
csem/scripts/check_exec_purity.sh || fail "exec purity"
csem/scripts/check_exec_totality.sh || fail "exec totality"
python3 csem/scripts/test_exec_totality.py | tail -1 || fail "exec totality plants"
csem/scripts/check_theorem_axioms.sh | grep '^check_theorem_axioms' || fail "axiom census"
[ "${PIPESTATUS[0]}" = 0 ] || fail "axiom census"
csem/scripts/check_sorry_token.sh || fail "sorry token"

echo "== csem (4b) semantic native-seam census"
free -g
[ "$(free -g | awk '/^Mem:/ {print $7}')" -ge 25 ] || fail "need >=25 GB before census"
lock=${SYT_LAKE_LOCK:-$_main/build/lake.lock}
flock "$lock" systemd-run --user --scope -p MemoryMax=12G lake env lean scripts/csem_cone.lean > build/csem-cone.log 2>&1 || fail "native-seam census (build/csem-cone.log)"
grep -E '^counts |^native floating ' build/csem-cone.log

echo "== csem (5) generator drift"
csem_have_toolchain || fail "matching pinned generator required for the repin gate (scripts/csem_toolchain.sh)"
scripts/csem_regen.sh --check || fail "generated Lean drifted"

if [ $lane = 1 ]; then
  echo "== csem (6) exec lane vs the OCaml oracle (csem/tests/minimal)"
  if [ -x "$CSEM_ORACLE" ]; then
    python3 scripts/csem_lane.py | tail -1
    [ "${PIPESTATUS[0]}" = 0 ] || fail "exec lane differs from the fork's baseline"
  else
    echo "  SKIP (no oracle at $CSEM_ORACLE; scripts/csem_toolchain.sh)"
  fi
fi
echo "csem_gates: OK"
