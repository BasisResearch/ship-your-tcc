#include <stdio.h>
#include <stddef.h>
struct S { char head; struct { unsigned a:3, b:5 __attribute__((aligned(8))), c:2; } inner; unsigned char tail; };
int main(void) { static struct S s; unsigned char *p=(unsigned char *)&s; unsigned i; for(i=0;i<sizeof s;++i) p[i]=0; s.inner.a=5; s.inner.b=19; s.inner.c=2;s.tail=71; printf("nested-static %lu %lu %lu", (unsigned long)sizeof s, (unsigned long)_Alignof(struct S), (unsigned long)offsetof(struct S,tail)); for(i=0;i<sizeof s;++i) printf(" %02x",(unsigned)p[i]); printf("\n"); return s.inner.a!=(5) || s.inner.b!=(19) || s.inner.c!=(2) || s.tail!=71; }
