/-
  Cabs JSON deserializer: converts JSON (from cerberus --cabs-json) to Cabs types.

  **Strict parser**: every unrecognised tag, missing field, or structural mismatch
  is a hard error with context.  Nothing is silently skipped or dropped.

  Schema (matching backend/lean_export/cabs_json.ml):
  - Nullary constructors: JSON string "Name"
  - Non-nullary constructors: {"tag": "Name", "field1": val, ...}
  - Options: null or value
  - Lists: JSON arrays
  - Tuples: JSON arrays
  - Strings: JSON strings
  - Integers: JSON strings (arbitrary precision)
  - Bools: JSON bools
  - Positions: {"file": S, "line": N, "col": N, "lexing_file": S, "lexing_line": N}
    (1-indexed; "file"/"line" = the SOURCE file and line after cpp's `#line`
    mapping, "col" the column; "lexing_file"/"lexing_line" = the position in the
    preprocessed file the lexer read — `Cerb_position.to_file_lexing`'s
    `pos_fname`/`pos_lnum`; all five REQUIRED, see `jsonToPos`)
  - Locations: tagged (Loc_unknown/Loc_other/Loc_point/Loc_region/Loc_regions)
  - Cursors: tagged (NoCursor/PointCursor/RegionCursor)
  - CN declarations: filtered out by OCaml serializer (never appear in JSON)

  Bridge notes (zero-discrepancy Z2-J-01/J-02, audit §2.15; the bridge is
  fork-side OCaml, backend/lean_export/cabs_json.ml — a fork-drift-manifest
  surface, not touched by the Lean slice):
  - Z2-J-01: `json_of_external_declaration` (cabs_json.ml:669-681) maps the
    CN declaration constructors to `None` and `filter_map`s them away — a
    fail-OPEN shape on the OCaml side. UNREACHABLE in matched mode: plain
    cerberus's C parser emits `EDecl_magic` for `/*@ … @*/` blocks, never
    the `EDecl_*CN` constructors (only the CN frontend produces them). The
    fail-closed remedy (a `failwith` there) is an oracle-surface change for
    Z4/the tray.
  - Z2-J-02 (CORRECTED and FIXED 2026-09-11, semantics-audit repairs D2 —
    finding 3 of `docs/2026-09-11_whole-project-semantics-audit.md`): a C
    string literal (or character constant) with a raw source byte ≥ 0x80 was
    written raw by `json_of_string`, so the JSON was not UTF-8 and
    `IO.FS.readFile` failed ("containing non UTF-8 data"). The earlier note
    called this "a both-fail (EXC(a))" because the oracle's decoder
    (decode.ml:199-200) fails on such bytes — FALSE for every shape that never
    DECODES the bytes: `sizeof("é")` is `Specified(3)` on the oracle (the
    length is the fragment count + 1), so Lean failed where the oracle
    succeeds — a class-(b) bug (VALIDATION.md §1). Fix: the exporter's
    `json_of_bytes` (cabs_json.ml) maps each byte b ≥ 0x80 to the scalar
    U+00b, so the JSON is always valid UTF-8 and every fragment /
    character-constant body arrives here as ONE `Char` per source byte with
    `c.toNat` = the byte — the byte-carrier convention
    (`docs/2026-09-09_batch-diagnostic-bytes-record.md`). `getByteStr`
    REJECTS (fail-closed) any such `Char` with `toNat ≥ 256`, a violation of
    the convention. Identifiers and file names stay Unicode TEXT (`getStr`).
    Decoding is unchanged: a raw byte ≥ 0x80 in a DECODED position still
    takes CerbDecode's `panic!` mirror of decode.ml:199-200 — the oracle's
    crash class (pinned in tests/immaculate/nolibc/f3-*).
-/

import Lean.Data.Json
import Cabs
import CerbLocation
import Std.Data.HashSet

open Lean (Json ToJson FromJson)

set_option autoImplicit true

namespace CabsImport

/-! ## JSON helpers -/

def err (ctx : String) (msg : String) : Except String α :=
  .error s!"{ctx}: {msg}"

def getField (j : Json) (field : String) : Except String Json :=
  match j with
  | .obj m =>
    let rec findKey : List (String × Json) → Option Json
      | [] => none
      | (k, v) :: rest => if k == field then some v else findKey rest
    match findKey m.toList with
    | some v => .ok v
    | none => err "getField" s!"missing field '{field}' in {j}"
  | _ => err "getField" s!"expected object for field '{field}', got {j}"

def getTag (j : Json) : Except String String :=
  match j with
  | .str s => .ok s  -- nullary constructor
  | .obj _ => do
    let tag ← getField j "tag"
    match tag with
    | .str s => .ok s
    | _ => err "getTag" "tag field is not a string"
  | _ => err "getTag" s!"expected string or object, got {j}"

def expectTag (ctx : String) (j : Json) (expected : String) : Except String Unit := do
  let actual ← getTag j
  if actual == expected then .ok ()
  else err ctx s!"expected tag '{expected}', got '{actual}' in {j}"

def getStr (j : Json) : Except String String :=
  match j with
  | .str s => .ok s
  | _ => err "getStr" s!"expected string, got {j}"

/-- A BYTE-CARRIER string: one `Char` per C source byte, `c.toNat` = the byte
    (cabs_json.ml `json_of_bytes`; header note Z2-J-02). Used for string-literal
    fragments (incl. asm parts) and character-constant bodies — never for
    identifiers or file names, which are Unicode text (`getStr`). A code point
    ≥ 256 cannot come from the encoder; it is REJECTED, never absorbed. -/
def getByteStr (j : Json) : Except String String := do
  let s ← getStr j
  match s.toList.find? (fun c => c.toNat ≥ 256) with
  | none => .ok s
  | some c =>
    err "getByteStr" s!"byte-carrier violation: code point U+{String.ofList (Nat.toDigits 16 c.toNat)} (≥ 256) in a string-literal fragment or character constant; cabs_json.ml json_of_bytes emits one code point ≤ 0xFF per source byte"

def getNat (j : Json) : Except String Nat :=
  match j with
  | .num n =>
    if n.mantissa < 0 then err "getNat" s!"negative number: {j}"
    else if n.exponent != 0 then err "getNat" s!"non-integer number: {j}"
    else .ok n.mantissa.toNat
  | .str s => match s.toNat? with
    | some n => .ok n
    | none => err "getNat" s!"invalid nat string: {s}"
  | _ => err "getNat" s!"expected nat, got {j}"

def getBool (j : Json) : Except String Bool :=
  match j with
  | .bool b => .ok b
  | _ => err "getBool" s!"expected bool, got {j}"

def getArr (j : Json) : Except String (Array Json) :=
  match j with
  | .arr a => .ok a
  | _ => err "getArr" s!"expected array, got {j}"

def getOption (f : Json → Except String α) (j : Json) : Except String (Option α) :=
  match j with
  | .null => .ok none
  | _ => do let v ← f j; .ok (some v)

def getList (f : Json → Except String α) (j : Json) : Except String (List α) :=
  do let arr ← getArr j; arr.toList.mapM f

/-! ## Location deserialization (lossless)

   Matches the lossless format from cabs_json.ml, which preserves filenames,
   cursor info, Loc_other strings, and region lists.

   Positions: {"file": S, "line": N, "col": N, "lexing_file": S, "lexing_line": N}  (1-indexed)
   Cursors:   "NoCursor" | {"tag": "PointCursor", ...} | {"tag": "RegionCursor", ...}
   Locations: "Loc_unknown" | {"tag": "Loc_other/Loc_point/Loc_region/Loc_regions", ...}
-/

/-- A position object (cabs_json.ml `json_of_pos`): the source triple and, since
    2026-10-16, the lexing (preprocessed-file) position beside it. All five
    fields are REQUIRED, fail-closed like the first three: the exporter and this
    importer move under one pin, so a document without `lexing_file`/
    `lexing_line` is a stale bridge artefact (exported by an older oracle) and is
    refused — never defaulted from the source values. -/
def jsonToPos (j : Json) : Except String CerbLocation.Pos := do
  if (j.getObjVal? "source_identity").isOk then
    throw "identity-bearing positions require the raw frontend; historical JSON cannot supply image membership"
  let file ← getStr (← getField j "file")
  let line ← getNat (← getField j "line")
  let col ← getNat (← getField j "col")
  let lexingFile ← getStr (← getField j "lexing_file")
  let lexingLine ← getNat (← getField j "lexing_line")
  .ok { file, line, col, lexingFile, lexingLine }

def jsonToCursor (j : Json) : Except String CerbLocation.Cursor := do
  match ← getTag j with
  | "NoCursor" => .ok .noCursor
  | "PointCursor" => .ok (.pointCursor (← jsonToPos (← getField j "pos")))
  | "RegionCursor" => .ok (.regionCursor
      (← jsonToPos (← getField j "begin"))
      (← jsonToPos (← getField j "end")))
  | t => err "jsonToCursor" s!"unknown tag '{t}' in {j}"

def jsonToLoc (j : Json) : Except String CerbLocation.Loc := do
  match ← getTag j with
  | "Loc_unknown" => .ok .unknown
  | "Loc_other" => .ok (.other (← getStr (← getField j "str")))
  | "Loc_point" => .ok (.point (← jsonToPos (← getField j "pos")))
  | "Loc_region" => .ok (.region
      (← jsonToPos (← getField j "begin"))
      (← jsonToPos (← getField j "end"))
      (← jsonToCursor (← getField j "cursor")))
  | "Loc_regions" =>
    let rs ← getList (fun rj => do
        let arr ← getArr rj
        if h : arr.size = 2 then
          .ok ((← jsonToPos arr[0]), (← jsonToPos arr[1]))
        else err "Loc_regions" "expected 2-element region pair"
      ) (← getField j "regions")
    -- `Cerb_location.regions [] _` is a failwith on the oracle (cerb_location.ml:
    -- 33-36), so no emitted JSON carries an empty list; refuse it here rather
    -- than build a value the OCaml constructor refuses (zero-discrepancy Z2-L-02)
    if rs.isEmpty then err "Loc_regions" "empty region list (Cerb_location.regions refuses [], cerb_location.ml:33-36)"
    else .ok (.regions rs (← jsonToCursor (← getField j "cursor")))
  | t => err "jsonToLoc" s!"unknown tag '{t}' in {j}"

/-! ## Identifier -/

def jsonToIdentifier (j : Json) : Except String identifier := do
  let loc ← jsonToLoc (← getField j "loc")
  let name ← getStr (← getField j "name")
  .ok (Identifier loc name)

/-! ## Simple enums -/

def jsonToIntegerSuffix (j : Json) : Except String cabs_integer_suffix := do
  match ← getTag j with
  | "CabsSuffix_U" => .ok .CabsSuffix_U
  | "CabsSuffix_UL" => .ok .CabsSuffix_UL
  | "CabsSuffix_ULL" => .ok .CabsSuffix_ULL
  | "CabsSuffix_L" => .ok .CabsSuffix_L
  | "CabsSuffix_LL" => .ok .CabsSuffix_LL
  | t => err "jsonToIntegerSuffix" s!"unknown tag '{t}' in {j}"

def jsonToFloatingSuffix (j : Json) : Except String cabs_floating_suffix := do
  match ← getTag j with
  | "CabsFloatingSuffix_F" => .ok .CabsFloatingSuffix_F
  | "CabsFloatingSuffix_L" => .ok .CabsFloatingSuffix_L
  | t => err "jsonToFloatingSuffix" s!"unknown tag '{t}' in {j}"

def jsonToCharacterPrefix (j : Json) : Except String cabs_character_prefix := do
  match ← getTag j with
  | "CabsPrefix_L" => .ok .CabsPrefix_L
  | "CabsPrefix_u" => .ok .CabsPrefix_u
  | "CabsPrefix_U" => .ok .CabsPrefix_U
  | t => err "jsonToCharacterPrefix" s!"unknown tag '{t}' in {j}"

def jsonToEncodingPrefix (j : Json) : Except String cabs_encoding_prefix := do
  match ← getTag j with
  | "CabsEncPrefix_u8" => .ok .CabsEncPrefix_u8
  | "CabsEncPrefix_u" => .ok .CabsEncPrefix_u
  | "CabsEncPrefix_U" => .ok .CabsEncPrefix_U
  | "CabsEncPrefix_L" => .ok .CabsEncPrefix_L
  | t => err "jsonToEncodingPrefix" s!"unknown tag '{t}' in {j}"

/-! ## Constants -/

def jsonToIntegerConstant (j : Json) : Except String cabs_integer_constant := do
  let arr ← getArr j
  if h : arr.size = 2 then
    let s ← getStr arr[0]
    let suffix ← getOption jsonToIntegerSuffix arr[1]
    .ok (s, suffix)
  else err "jsonToIntegerConstant" "expected 2-element array"

def jsonToFloatingConstant (j : Json) : Except String cabs_floating_constant := do
  let arr ← getArr j
  if h : arr.size = 2 then
    let s ← getStr arr[0]
    let suffix ← getOption jsonToFloatingSuffix arr[1]
    .ok (s, suffix)
  else err "jsonToFloatingConstant" "expected 2-element array"

def jsonToCharacterConstant (j : Json) : Except String cabs_character_constant := do
  let arr ← getArr j
  if h : arr.size = 2 then
    let pfx ← getOption jsonToCharacterPrefix arr[0]
    let s ← getByteStr arr[1]  -- BYTES (c-char sequence), not text
    .ok (pfx, s)
  else err "jsonToCharacterConstant" "expected 2-element array"

def jsonToConstant (j : Json) : Except String cabs_constant := do
  match ← getTag j with
  | "CabsInteger_const" => .ok (.CabsInteger_const (← jsonToIntegerConstant (← getField j "val")))
  | "CabsFloating_const" => .ok (.CabsFloating_const (← jsonToFloatingConstant (← getField j "val")))
  | "CabsCharacter_const" => .ok (.CabsCharacter_const (← jsonToCharacterConstant (← getField j "val")))
  | t => err "jsonToConstant" s!"unknown tag '{t}' in {j}"

def jsonToStringLiteral (j : Json) : Except String cabs_string_literal := do
  let arr ← getArr j
  if h : arr.size = 2 then
    let enc ← getOption jsonToEncodingPrefix arr[0]
    let parts ← getList (fun partJ => do
      let partArr ← getArr partJ
      if h2 : partArr.size = 2 then
        let loc ← jsonToLoc partArr[0]
        let strs ← getList getByteStr partArr[1]  -- BYTES (s-char fragments), not text
        .ok (loc, strs)
      else err "jsonToStringLiteral" "expected 2-element part"
    ) arr[1]
    .ok (enc, parts)
  else err "jsonToStringLiteral" "expected 2-element array"

/-! ## Operators -/

def jsonToUnaryOp (j : Json) : Except String cabs_unary_operator := do
  match ← getTag j with
  | "CabsAddress" => .ok .CabsAddress
  | "CabsIndirection" => .ok .CabsIndirection
  | "CabsPlus" => .ok .CabsPlus
  | "CabsMinus" => .ok .CabsMinus
  | "CabsBnot" => .ok .CabsBnot
  | "CabsNot" => .ok .CabsNot
  | t => err "jsonToUnaryOp" s!"unknown tag '{t}' in {j}"

def jsonToBinaryOp (j : Json) : Except String cabs_binary_operator := do
  match ← getTag j with
  | "CabsMul" => .ok .CabsMul | "CabsDiv" => .ok .CabsDiv | "CabsMod" => .ok .CabsMod
  | "CabsAdd" => .ok .CabsAdd | "CabsSub" => .ok .CabsSub
  | "CabsShl" => .ok .CabsShl | "CabsShr" => .ok .CabsShr
  | "CabsLt" => .ok .CabsLt | "CabsGt" => .ok .CabsGt
  | "CabsLe" => .ok .CabsLe | "CabsGe" => .ok .CabsGe
  | "CabsEq" => .ok .CabsEq | "CabsNe" => .ok .CabsNe
  | "CabsBand" => .ok .CabsBand | "CabsBxor" => .ok .CabsBxor | "CabsBor" => .ok .CabsBor
  | "CabsAnd" => .ok .CabsAnd | "CabsOr" => .ok .CabsOr
  | t => err "jsonToBinaryOp" s!"unknown tag '{t}' in {j}"

def jsonToAssignmentOp (j : Json) : Except String cabs_assignment_operator := do
  match ← getTag j with
  | "Assign" => .ok .Assign
  | "Assign_Mul" => .ok .Assign_Mul | "Assign_Div" => .ok .Assign_Div
  | "Assign_Mod" => .ok .Assign_Mod | "Assign_Add" => .ok .Assign_Add
  | "Assign_Sub" => .ok .Assign_Sub | "Assign_Shl" => .ok .Assign_Shl
  | "Assign_Shr" => .ok .Assign_Shr | "Assign_Band" => .ok .Assign_Band
  | "Assign_Bxor" => .ok .Assign_Bxor | "Assign_Bor" => .ok .Assign_Bor
  | t => err "jsonToAssignmentOp" s!"unknown tag '{t}' in {j}"

/-! ## All Cabs types (mutually recursive) -/

mutual
partial def jsonToExpression (j : Json) : Except String cabs_expression := do
  expectTag "CabsExpression" j "CabsExpression"
  let loc ← jsonToLoc (← getField j "loc")
  let expr ← jsonToExpression_ (← getField j "expr")
  .ok (CabsExpression loc expr)

partial def jsonToExpression_ (j : Json) : Except String cabs_expression_ := do
  match ← getTag j with
  | "CabsEident" => .ok (.CabsEident (← jsonToIdentifier (← getField j "id")))
  | "CabsEconst" => .ok (.CabsEconst (← jsonToConstant (← getField j "val")))
  | "CabsEstring" => .ok (.CabsEstring (← jsonToStringLiteral (← getField j "val")))
  | "CabsEgeneric" => .ok (.CabsEgeneric
      (← jsonToExpression (← getField j "expr"))
      (← getList jsonToGenericAssoc (← getField j "assocs")))
  | "CabsEsubscript" => .ok (.CabsEsubscript
      (← jsonToExpression (← getField j "arr"))
      (← jsonToExpression (← getField j "idx")))
  | "CabsEcall" => .ok (.CabsEcall
      (← jsonToExpression (← getField j "fun"))
      (← getList jsonToExpression (← getField j "args"))
      (← getOption jsonToAttributes (← getField j "attrs")))
  | "CabsEmemberof" => .ok (.CabsEmemberof
      (← jsonToExpression (← getField j "expr"))
      (← jsonToIdentifier (← getField j "member")))
  | "CabsEmemberofptr" => .ok (.CabsEmemberofptr
      (← jsonToExpression (← getField j "expr"))
      (← jsonToIdentifier (← getField j "member")))
  | "CabsEpostincr" => .ok (.CabsEpostincr (← jsonToExpression (← getField j "expr")))
  | "CabsEpostdecr" => .ok (.CabsEpostdecr (← jsonToExpression (← getField j "expr")))
  | "CabsEcompound" => .ok (.CabsEcompound
      (← jsonToTypeName (← getField j "type"))
      (← getList (fun initJ => do
        let arr ← getArr initJ
        if h : arr.size = 2 then
          let desigs ← getOption (getList jsonToDesignator) arr[0]
          let init ← jsonToInitializer arr[1]
          .ok (desigs, init)
        else err "compound" "expected 2-element init pair"
      ) (← getField j "inits")))
  | "CabsEpreincr" => .ok (.CabsEpreincr (← jsonToExpression (← getField j "expr")))
  | "CabsEpredecr" => .ok (.CabsEpredecr (← jsonToExpression (← getField j "expr")))
  | "CabsEunary" => .ok (.CabsEunary
      (← jsonToUnaryOp (← getField j "op"))
      (← jsonToExpression (← getField j "expr")))
  | "CabsEsizeof_expr" => .ok (.CabsEsizeof_expr (← jsonToExpression (← getField j "expr")))
  | "CabsEsizeof_type" => .ok (.CabsEsizeof_type (← jsonToTypeName (← getField j "type")))
  | "CabsEalignof_expr" => .ok (.CabsEalignof_expr (← jsonToExpression (← getField j "expr")))
  | "CabsEalignof" => .ok (.CabsEalignof (← jsonToTypeName (← getField j "type")))
  | "CabsEcast" => .ok (.CabsEcast
      (← jsonToTypeName (← getField j "type"))
      (← jsonToExpression (← getField j "expr")))
  | "CabsEbinary" => .ok (.CabsEbinary
      (← jsonToBinaryOp (← getField j "op"))
      (← jsonToExpression (← getField j "lhs"))
      (← jsonToExpression (← getField j "rhs")))
  | "CabsEcond" => .ok (.CabsEcond
      (← jsonToExpression (← getField j "cond"))
      (← jsonToExpression (← getField j "then_"))
      (← jsonToExpression (← getField j "else_")))
  | "CabsEassign" => .ok (.CabsEassign
      (← jsonToAssignmentOp (← getField j "op"))
      (← jsonToExpression (← getField j "lhs"))
      (← jsonToExpression (← getField j "rhs")))
  | "CabsEcomma" => .ok (.CabsEcomma
      (← jsonToExpression (← getField j "lhs"))
      (← jsonToExpression (← getField j "rhs")))
  | "CabsEassert" => .ok (.CabsEassert (← jsonToExpression (← getField j "expr")))
  | "CabsEoffsetof" => .ok (.CabsEoffsetof
      (← jsonToTypeName (← getField j "type"))
      (← jsonToIdentifier (← getField j "member")))
  | "CabsEva_start" => .ok (.CabsEva_start
      (← jsonToExpression (← getField j "expr"))
      (← jsonToIdentifier (← getField j "param")))
  | "CabsEva_copy" => .ok (.CabsEva_copy
      (← jsonToExpression (← getField j "dst"))
      (← jsonToExpression (← getField j "src")))
  | "CabsEva_arg" => .ok (.CabsEva_arg
      (← jsonToExpression (← getField j "expr"))
      (← jsonToTypeName (← getField j "type")))
  | "CabsEva_end" => .ok (.CabsEva_end (← jsonToExpression (← getField j "expr")))
  | "CabsEprint_type" => .ok (.CabsEprint_type (← jsonToExpression (← getField j "expr")))
  | "CabsEbmc_assume" => .ok (.CabsEbmc_assume (← jsonToExpression (← getField j "expr")))
  | "CabsEgcc_statement" => .ok (.CabsEgcc_statement
      (← getList jsonToStatement (← getField j "stmts")))
  | "CabsEcondGNU" => .ok (.CabsEcondGNU
      (← jsonToExpression (← getField j "cond"))
      (← jsonToExpression (← getField j "else_")))
  | "CabsEbuiltinGNU" => .ok (.CabsEbuiltinGNU (← jsonToGnuBuiltin (← getField j "builtin")))
  | t => err "jsonToExpression_" s!"unknown tag '{t}' in {j}"

partial def jsonToGenericAssoc (j : Json) : Except String cabs_generic_association := do
  match ← getTag j with
  | "GA_type" => .ok (.GA_type
      (← jsonToTypeName (← getField j "type"))
      (← jsonToExpression (← getField j "expr")))
  | "GA_default" => .ok (.GA_default (← jsonToExpression (← getField j "expr")))
  | t => err "jsonToGenericAssoc" s!"unknown tag '{t}' in {j}"

-- Storage class specifiers
partial def jsonToStorageClass (j : Json) : Except String storage_class_specifier := do
  match ← getTag j with
  | "SC_typedef" => .ok .SC_typedef | "SC_extern" => .ok .SC_extern
  | "SC_static" => .ok .SC_static | "SC_Thread_local" => .ok .SC_Thread_local
  | "SC_auto" => .ok .SC_auto | "SC_register" => .ok .SC_register
  | t => err "jsonToStorageClass" s!"unknown tag '{t}' in {j}"

-- Type qualifiers
partial def jsonToTypeQualifier (j : Json) : Except String cabs_type_qualifier := do
  match ← getTag j with
  | "Q_const" => .ok .Q_const | "Q_restrict" => .ok .Q_restrict
  | "Q_volatile" => .ok .Q_volatile | "Q_Atomic" => .ok .Q_Atomic
  | t => err "jsonToTypeQualifier" s!"unknown tag '{t}' in {j}"

-- Function specifiers
partial def jsonToFunctionSpecifier (j : Json) : Except String function_specifier := do
  match ← getTag j with
  | "FS_inline" => .ok .FS_inline | "FS_Noreturn" => .ok .FS_Noreturn
  | t => err "jsonToFunctionSpecifier" s!"unknown tag '{t}' in {j}"

-- Alignment specifiers
partial def jsonToAlignmentSpecifier (j : Json) : Except String alignment_specifier := do
  match ← getTag j with
  | "AS_type" => .ok (.AS_type (← jsonToTypeName (← getField j "type")))
  | "AS_expr" => .ok (.AS_expr (← jsonToExpression (← getField j "expr")))
  | t => err "jsonToAlignmentSpecifier" s!"unknown tag '{t}' in {j}"

-- Type specifier (inner)
partial def jsonToTypeSpecifier_ (j : Json) : Except String cabs_type_specifier_ := do
  match ← getTag j with
  | "TSpec_void" => .ok .TSpec_void | "TSpec_char" => .ok .TSpec_char
  | "TSpec_short" => .ok .TSpec_short | "TSpec_int" => .ok .TSpec_int
  | "TSpec_long" => .ok .TSpec_long | "TSpec_float" => .ok .TSpec_float
  | "TSpec_double" => .ok .TSpec_double | "TSpec_signed" => .ok .TSpec_signed
  | "TSpec_unsigned" => .ok .TSpec_unsigned | "TSpec_Bool" => .ok .TSpec_Bool
  | "TSpec_Complex" => .ok .TSpec_Complex
  | "TSpec_Atomic" => .ok (.TSpec_Atomic (← jsonToTypeName (← getField j "type")))
  | "TSpec_struct" => .ok (.TSpec_struct
      (← jsonToAttributes (← getField j "attrs"))
      (← getOption jsonToIdentifier (← getField j "id"))
      (← getOption (getList jsonToStructDecl) (← getField j "members")))
  | "TSpec_union" => .ok (.TSpec_union
      (← jsonToAttributes (← getField j "attrs"))
      (← getOption jsonToIdentifier (← getField j "id"))
      (← getOption (getList jsonToStructDecl) (← getField j "members")))
  | "TSpec_enum" => .ok (.TSpec_enum
      (← getOption jsonToIdentifier (← getField j "id"))
      (← getOption (getList jsonToEnumerator) (← getField j "enumerators")))
  | "TSpec_name" => .ok (.TSpec_name (← jsonToIdentifier (← getField j "id")))
  | "TSpec_typeof_expr" => .ok (.TSpec_typeof_expr (← jsonToExpression (← getField j "expr")))
  | "TSpec_typeof_type" => .ok (.TSpec_typeof_type (← jsonToTypeName (← getField j "type")))
  | t => err "jsonToTypeSpecifier_" s!"unknown tag '{t}' in {j}"

-- Type specifier (with location)
partial def jsonToTypeSpecifier (j : Json) : Except String cabs_type_specifier := do
  expectTag "TSpec" j "TSpec"
  let loc ← jsonToLoc (← getField j "loc")
  let spec ← jsonToTypeSpecifier_ (← getField j "spec")
  .ok (TSpec loc spec)

-- Struct declaration
partial def jsonToStructDecl (j : Json) : Except String struct_declaration := do
  match ← getTag j with
  | "Struct_declaration" => .ok (.Struct_declaration
      (← jsonToAttributes (← getField j "attrs"))
      (← getList jsonToTypeSpecifier (← getField j "type_specifiers"))
      (← getList jsonToTypeQualifier (← getField j "type_qualifiers"))
      (← getList jsonToAlignmentSpecifier (← getField j "alignment_specifiers"))
      (← getList jsonToStructDeclarator (← getField j "declarators")))
  | "Struct_assert" => .ok (.Struct_assert (← jsonToStaticAssert (← getField j "assert")))
  | t => err "jsonToStructDecl" s!"unknown tag '{t}' in {j}"

-- Struct declarator
partial def jsonToStructDeclarator (j : Json) : Except String struct_declarator := do
  match ← getTag j with
  | "SDecl_simple" => .ok (.SDecl_simple (← jsonToDeclarator (← getField j "declarator")))
  | "SDecl_bitfield" => .ok (.SDecl_bitfield
      (← match j.getObjVal? "attrs" with | .ok a => jsonToAttributes a | .error _ => pure (Attrs []))
      (← getOption jsonToDeclarator (← getField j "declarator"))
      (← jsonToExpression (← getField j "width")))
  | t => err "jsonToStructDeclarator" s!"unknown tag '{t}' in {j}"

-- Enumerator
partial def jsonToEnumerator (j : Json) : Except String (identifier × Option cabs_expression) := do
  let arr ← getArr j
  if h : arr.size = 2 then
    let id ← jsonToIdentifier arr[0]
    let expr ← getOption jsonToExpression arr[1]
    .ok (id, expr)
  else err "jsonToEnumerator" "expected 2-element array"

-- Pointer declarator
partial def jsonToPointerDecl (j : Json) : Except String pointer_declarator := do
  expectTag "PDecl" j "PDecl"
  let loc ← jsonToLoc (← getField j "loc")
  let quals ← getList jsonToTypeQualifier (← getField j "type_qualifiers")
  let inner ← getOption jsonToPointerDecl (← getField j "pointer")
  .ok (PDecl loc quals inner)

-- Array declarator size
partial def jsonToArrayDeclSize (j : Json) : Except String array_declarator_size := do
  match ← getTag j with
  | "ADeclSize_expression" => .ok (.ADeclSize_expression (← jsonToExpression (← getField j "expr")))
  | "ADeclSize_asterisk" => .ok .ADeclSize_asterisk
  | t => err "jsonToArrayDeclSize" s!"unknown tag '{t}' in {j}"

-- Array declarator
partial def jsonToArrayDecl (j : Json) : Except String array_declarator := do
  expectTag "ADecl" j "ADecl"
  let loc ← jsonToLoc (← getField j "loc")
  let quals ← getList jsonToTypeQualifier (← getField j "type_qualifiers")
  let isStatic ← getBool (← getField j "is_static")
  let size ← getOption jsonToArrayDeclSize (← getField j "size")
  .ok (ADecl loc quals isStatic size)

-- Parameter type list
partial def jsonToParamTypeList (j : Json) : Except String parameter_type_list := do
  expectTag "Params" j "Params"
  let params ← getList jsonToParamDecl (← getField j "params")
  let variadic ← getBool (← getField j "is_variadic")
  .ok (Params params variadic)

-- Parameter declaration
partial def jsonToParamDecl (j : Json) : Except String parameter_declaration := do
  match ← getTag j with
  | "PDeclaration_decl" => .ok (.PDeclaration_decl
      (← jsonToSpecifiers (← getField j "specifiers"))
      (← jsonToDeclarator (← getField j "declarator")))
  | "PDeclaration_abs_decl" => .ok (.PDeclaration_abs_decl
      (← jsonToSpecifiers (← getField j "specifiers"))
      (← getOption jsonToAbstractDeclarator (← getField j "abstract_declarator")))
  | t => err "jsonToParamDecl" s!"unknown tag '{t}' in {j}"

-- Direct declarator
partial def jsonToDirectDecl (j : Json) : Except String direct_declarator := do
  match ← getTag j with
  | "DDecl_identifier" => .ok (.DDecl_identifier
      (← jsonToAttributes (← getField j "attrs"))
      (← jsonToIdentifier (← getField j "id")))
  | "DDecl_declarator" => .ok (.DDecl_declarator (← jsonToDeclarator (← getField j "declarator")))
  | "DDecl_array" => .ok (.DDecl_array
      (← jsonToDirectDecl (← getField j "direct"))
      (← jsonToArrayDecl (← getField j "array")))
  | "DDecl_function" => .ok (.DDecl_function
      (← jsonToDirectDecl (← getField j "direct"))
      (← jsonToParamTypeList (← getField j "params")))
  | t => err "jsonToDirectDecl" s!"unknown tag '{t}' in {j}"

-- Declarator
partial def jsonToDeclarator (j : Json) : Except String declarator := do
  expectTag "Declarator" j "Declarator"
  let ptr ← getOption jsonToPointerDecl (← getField j "pointer")
  let direct ← jsonToDirectDecl (← getField j "direct")
  .ok (Declarator ptr direct)

-- Abstract declarator
partial def jsonToAbstractDeclarator (j : Json) : Except String abstract_declarator := do
  match ← getTag j with
  | "AbsDecl_pointer" => .ok (.AbsDecl_pointer (← jsonToPointerDecl (← getField j "pointer")))
  | "AbsDecl_direct" => .ok (.AbsDecl_direct
      (← getOption jsonToPointerDecl (← getField j "pointer"))
      (← jsonToDirectAbstractDecl (← getField j "direct")))
  | t => err "jsonToAbstractDeclarator" s!"unknown tag '{t}' in {j}"

-- Direct abstract declarator
partial def jsonToDirectAbstractDecl (j : Json) : Except String direct_abstract_declarator := do
  match ← getTag j with
  | "DAbs_abs_declarator" => .ok (.DAbs_abs_declarator
      (← jsonToAbstractDeclarator (← getField j "abstract_declarator")))
  | "DAbs_array" => .ok (.DAbs_array
      (← getOption jsonToDirectAbstractDecl (← getField j "direct"))
      (← jsonToArrayDecl (← getField j "array")))
  | "DAbs_function" => .ok (.DAbs_function
      (← getOption jsonToDirectAbstractDecl (← getField j "direct"))
      (← jsonToParamTypeList (← getField j "params")))
  | t => err "jsonToDirectAbstractDecl" s!"unknown tag '{t}' in {j}"

-- Type name
partial def jsonToTypeName (j : Json) : Except String type_name := do
  expectTag "Type_name" j "Type_name"
  let specs ← getList jsonToTypeSpecifier (← getField j "type_specifiers")
  let quals ← getList jsonToTypeQualifier (← getField j "type_qualifiers")
  let aligns ← getList jsonToAlignmentSpecifier (← getField j "alignment_specifiers")
  let absDecl ← getOption jsonToAbstractDeclarator (← getField j "abstract_declarator")
  .ok (Type_name specs quals aligns absDecl)

-- Designator
partial def jsonToDesignator (j : Json) : Except String designator := do
  match ← getTag j with
  | "Desig_array" => .ok (.Desig_array (← jsonToExpression (← getField j "expr")))
  | "Desig_member" => .ok (.Desig_member (← jsonToIdentifier (← getField j "member")))
  | t => err "jsonToDesignator" s!"unknown tag '{t}' in {j}"

-- Initializer
partial def jsonToInitializer (j : Json) : Except String initializer_ := do
  match ← getTag j with
  | "Init_expr" => .ok (.Init_expr (← jsonToExpression (← getField j "expr")))
  | "Init_list" => .ok (.Init_list
      (← jsonToLoc (← getField j "loc"))
      (← getList (fun initJ => do
        let arr ← getArr initJ
        if h : arr.size = 2 then
          let desigs ← getOption (getList jsonToDesignator) arr[0]
          let init ← jsonToInitializer arr[1]
          .ok (desigs, init)
        else err "Init_list" "expected 2-element init pair"
      ) (← getField j "inits")))
  | t => err "jsonToInitializer" s!"unknown tag '{t}' in {j}"

-- GNU builtins
partial def jsonToGnuBuiltin (j : Json) : Except String gnu_builtin_function := do
  match ← getTag j with
  | "GNUbuiltin_types_compatible_p" => .ok (.GNUbuiltin_types_compatible_p
      (← jsonToTypeName (← getField j "type1"))
      (← jsonToTypeName (← getField j "type2")))
  | "GNUbuiltin_choose_expr" => .ok (.GNUbuiltin_choose_expr
      (← jsonToExpression (← getField j "cond"))
      (← jsonToExpression (← getField j "then_"))
      (← jsonToExpression (← getField j "else_")))
  | t => err "jsonToGnuBuiltin" s!"unknown tag '{t}' in {j}"

-- Attributes
partial def jsonToAttributes (j : Json) : Except String attributes := do
  match ← getTag j with
  | "Attrs" => .ok (.Attrs (← getList jsonToAttribute (← getField j "attrs")))
  | t => err "jsonToAttributes" s!"unknown tag '{t}' in {j}"

partial def jsonToAttribute (j : Json) : Except String attribute0 := do
  .ok (attribute0.mk
    (← getOption jsonToIdentifier (← getField j "ns"))
    (← jsonToIdentifier (← getField j "id"))
    (← getList (fun argJ => do
      let arr ← getArr argJ
      if h : arr.size = 3 then
        let loc ← jsonToLoc arr[0]
        let s ← getStr arr[1]
        let tokens ← getList (fun tokJ => do
          let tokArr ← getArr tokJ
          if h2 : tokArr.size = 2 then
            let tokLoc ← jsonToLoc tokArr[0]
            let tokStr ← getStr tokArr[1]
            .ok (tokLoc, tokStr)
          else err "attr_token" "expected 2-element array"
        ) arr[2]
        .ok (loc, s, tokens)
      else err "attribute_arg" "expected 3-element array"
    ) (← getField j "args")))

-- Specifiers
partial def jsonToSpecifiers (j : Json) : Except String specifiers := do
  expectTag "Specifiers" j "Specifiers"
  .ok (specifiers.mk
    (← getList jsonToStorageClass (← getField j "storage_classes"))
    (← getList jsonToTypeSpecifier (← getField j "type_specifiers"))
    (← getList jsonToTypeQualifier (← getField j "type_qualifiers"))
    (← getList jsonToFunctionSpecifier (← getField j "function_specifiers"))
    (← getList jsonToAlignmentSpecifier (← getField j "alignment_specifiers")))

-- Static assert
partial def jsonToStaticAssert (j : Json) : Except String static_assert_declaration := do
  expectTag "Static_assert" j "Static_assert"
  .ok (.Static_assert
    (← jsonToExpression (← getField j "expr"))
    (← jsonToStringLiteral (← getField j "msg")))

-- Init declarator
partial def jsonToInitDecl (j : Json) : Except String init_declarator := do
  expectTag "InitDecl" j "InitDecl"
  let loc ← jsonToLoc (← getField j "loc")
  let decl ← jsonToDeclarator (← getField j "declarator")
  let init ← getOption jsonToInitializer (← getField j "initializer")
  .ok (InitDecl loc decl init)

-- Declaration
partial def jsonToDeclaration (j : Json) : Except String cabs_declaration := do
  match ← getTag j with
  | "Declaration_base" => .ok (.Declaration_base
      (← jsonToAttributes (← getField j "attrs"))
      (← jsonToSpecifiers (← getField j "specifiers"))
      (← getList jsonToInitDecl (← getField j "init_declarators")))
  | "Declaration_static_assert" => .ok (.Declaration_static_assert
      (← jsonToStaticAssert (← getField j "assert")))
  | t => err "jsonToDeclaration" s!"unknown tag '{t}' in {j}"

-- For clause
partial def jsonToForClause (j : Json) : Except String for_clause := do
  match ← getTag j with
  | "FC_expr" => .ok (.FC_expr (← jsonToExpression (← getField j "expr")))
  | "FC_decl" => .ok (.FC_decl
      (← jsonToLoc (← getField j "loc"))
      (← jsonToDeclaration (← getField j "decl")))
  | t => err "jsonToForClause" s!"unknown tag '{t}' in {j}"

-- Statement (inner)
partial def jsonToStatement_ (j : Json) : Except String cabs_statement_ := do
  match ← getTag j with
  | "CabsSlabel" => .ok (.CabsSlabel
      (← jsonToIdentifier (← getField j "label"))
      (← jsonToStatement (← getField j "stmt")))
  | "CabsScase" => .ok (.CabsScase
      (← jsonToExpression (← getField j "expr"))
      (← jsonToStatement (← getField j "stmt")))
  | "CabsSdefault" => .ok (.CabsSdefault (← jsonToStatement (← getField j "stmt")))
  | "CabsSblock" => .ok (.CabsSblock (← getList jsonToStatement (← getField j "stmts")))
  | "CabsSdecl" => .ok (.CabsSdecl (← jsonToDeclaration (← getField j "decl")))
  | "CabsSnull" => .ok .CabsSnull
  | "CabsSexpr" => .ok (.CabsSexpr (← jsonToExpression (← getField j "expr")))
  | "CabsSif" => .ok (.CabsSif
      (← jsonToExpression (← getField j "cond"))
      (← jsonToStatement (← getField j "then_"))
      (← getOption jsonToStatement (← getField j "else_")))
  | "CabsSswitch" => .ok (.CabsSswitch
      (← jsonToExpression (← getField j "expr"))
      (← jsonToStatement (← getField j "stmt")))
  | "CabsSwhile" => .ok (.CabsSwhile
      (← jsonToExpression (← getField j "cond"))
      (← jsonToStatement (← getField j "body")))
  | "CabsSdo" => .ok (.CabsSdo
      (← jsonToExpression (← getField j "cond"))
      (← jsonToStatement (← getField j "body")))
  | "CabsSfor" => .ok (.CabsSfor
      (← getOption jsonToForClause (← getField j "init"))
      (← getOption jsonToExpression (← getField j "cond"))
      (← getOption jsonToExpression (← getField j "step"))
      (← jsonToStatement (← getField j "body")))
  | "CabsSgoto" => .ok (.CabsSgoto (← jsonToIdentifier (← getField j "label")))
  | "CabsScontinue" => .ok .CabsScontinue
  | "CabsSbreak" => .ok .CabsSbreak
  | "CabsSreturn" => .ok (.CabsSreturn (← getOption jsonToExpression (← getField j "expr")))
  | "CabsSpar" => .ok (.CabsSpar (← getList jsonToStatement (← getField j "stmts")))
  | "CabsSasm" => .ok (.CabsSasm
      (← getBool (← getField j "is_volatile"))
      (← getBool (← getField j "is_inline"))
      (← getList (fun partJ => do
        let arr ← getArr partJ
        if h : arr.size = 2 then
          let loc ← jsonToLoc arr[0]
          let strs ← getList getByteStr arr[1]  -- BYTES (asm string-literal fragments)
          .ok (loc, strs)
        else err "asm" "expected 2-element part"
      ) (← getField j "parts")))
  | "CabsScaseGNU" => .ok (.CabsScaseGNU
      (← jsonToExpression (← getField j "lo"))
      (← jsonToExpression (← getField j "hi"))
      (← jsonToStatement (← getField j "stmt")))
  | "CabsSmarker" => .ok (.CabsSmarker (← jsonToStatement (← getField j "stmt")))
  | t => err "jsonToStatement_" s!"unknown tag '{t}' in {j}"

-- Statement (with location and attributes)
partial def jsonToStatement (j : Json) : Except String cabs_statement := do
  expectTag "CabsStatement" j "CabsStatement"
  let loc ← jsonToLoc (← getField j "loc")
  let attrs ← jsonToAttributes (← getField j "attrs")
  let stmt ← jsonToStatement_ (← getField j "stmt")
  .ok (CabsStatement loc attrs stmt)

-- Function definition
partial def jsonToFunctionDef (j : Json) : Except String function_definition := do
  expectTag "FunDef" j "FunDef"
  .ok (FunDef
    (← jsonToLoc (← getField j "loc"))
    (← jsonToAttributes (← getField j "attrs"))
    (← jsonToSpecifiers (← getField j "specifiers"))
    (← jsonToDeclarator (← getField j "declarator"))
    (← jsonToStatement (← getField j "body")))

-- External declaration (strict: errors on any unrecognised tag)
partial def jsonToExternalDeclaration (j : Json) : Except String external_declaration := do
  match ← getTag j with
  | "EDecl_func" => .ok (.EDecl_func (← jsonToFunctionDef (← getField j "def")))
  | "EDecl_decl" => .ok (.EDecl_decl (← jsonToDeclaration (← getField j "decl")))
  | "EDecl_magic" => do
    let loc ← jsonToLoc (← getField j "loc")
    let s ← getStr (← getField j "str")
    .ok (.EDecl_magic (loc, s))
  | t => err "jsonToExternalDeclaration" s!"unknown tag '{t}' in {j}"

-- Translation unit
partial def jsonToTranslationUnit (j : Json) : Except String translation_unit := do
  match ← getTag j with
  | "TUnit" =>
    let decls ← getList jsonToExternalDeclaration (← getField j "decls")
    .ok (TUnit decls)
  | t => err "jsonToTranslationUnit" s!"unknown tag '{t}' in {j}"

end

/-! ## Entry point -/

/-- Collect the `file` string of every position object
    (`{"file": S, "line": N, "col": N, "lexing_file": S, "lexing_line": N}`,
    `cabs_json.ml` `json_of_pos`; recognised by its first three keys) in a
    Cabs JSON document, cursors included. The input of
    `Main.refuseLibraryLocations` (bug-hunt BUG-3, 2026-09-29). The SOURCE file
    only, deliberately: the oracle's `is_library_location` tests
    `get_filename` = `Cerb_position.file`, the source file
    (util/cerb_location.ml:512-523); the lexing file name is never consulted. -/
partial def positionFiles (j : Json) (acc : Std.HashSet String) : Std.HashSet String :=
  match j with
  | .arr elems => elems.foldl (fun acc e => positionFiles e acc) acc
  | .obj kvs =>
    let acc := match kvs.get? "file", kvs.get? "line", kvs.get? "col" with
      | some (.str f), some _, some _ => acc.insert f
      | _, _, _ => acc
    kvs.foldl (fun acc _ v => positionFiles v acc) acc
  | _ => acc

/-- Parse a cabs-json document: the translation unit AND its `digest` —
    the oracle's `Digest.file` of the C source, in `Digest.to_hex` form
    (backend/driver/main.ml --cabs-json path, which sets it with
    `Cerb_fresh.set_digest filename` exactly as the OCaml c_frontend does,
    pipeline.ml:181). Main.lean installs it as the TU's digest before the
    frontend stages, so every symbol the Lean pipeline mints for this TU
    carries the same digest as the oracle's (zero-discrepancy Z3, census
    row Z-28: symbol digests order the linked globals, hence the
    addresses). REQUIRED, fail-closed: a document without the field is a
    stale bridge artifact (generated by an older oracle), never a TU to run. -/
def parseJsonWithFiles (input : String) : Except String (String × translation_unit × Array String) := do
  let json ← Json.parse input |>.mapError toString
  let tunit ← jsonToTranslationUnit json
  let digest ← match getField json "digest" with
    | .ok (.str d) =>
      if d.length == 32 && d.all (fun c => c.isDigit || ('a' ≤ c && c ≤ 'f')) then .ok d
      else err "parseJson" s!"'digest' is not a 32-character lowercase-hex MD5: {d}"
    | .ok j => err "parseJson" s!"'digest' is not a string: {j}"
    | .error _ => err "parseJson" "missing 'digest' field — this cabs-json predates the zero-discrepancy Z3 bridge (regenerate it with the current oracle's --cabs-json; the Lean driver installs the source digest it carries as the TU digest, Cerb_fresh.set_digest mirror)"
  .ok (digest, tunit, (positionFiles json {}).toArray.qsort (· < ·))

/-- `parseJsonWithFiles` without the file list. -/
def parseJson (input : String) : Except String (String × translation_unit) := do
  let (digest, tunit, _) ← parseJsonWithFiles input
  .ok (digest, tunit)

end CabsImport

/-- The Cabs execution pipeline selects the LAST program TU's digest, in
    frontend order, or "" for an empty list. Library and metadata TUs do
    not select this value. Other entry paths must carry their actual entry
    digest: OCaml Core text sets it; Core objects preserve the current global
    (S0 record §3 erratum). Lean's --parse-core does not execute Core text. -/
def runDigest (tunits : List (String × translation_unit)) : String :=
  match tunits.getLast? with
  | some (digest, _) => digest
  | none => ""
