int x='\q';
