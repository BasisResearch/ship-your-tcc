char *s="\x";
