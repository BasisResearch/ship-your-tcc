struct A {int x,y;}; struct S {struct A a[2]; int z;};
static struct S v={.a[0].y=1,2,3,4};
int main(void){return !(v.a[0].x==0 && v.a[0].y==1 && v.a[1].x==2 && v.a[1].y==3 && v.z==4);}
