
static int v[][2]={[1][0]=1,2,3,4};
int main(void){return !(sizeof(v)/sizeof(v[0])==3 && v[0][1]==0 && v[1][0]==1 && v[1][1]==2 && v[2][0]==3 && v[2][1]==4);}
