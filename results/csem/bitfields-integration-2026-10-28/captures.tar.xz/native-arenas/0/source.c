typedef int Number;
int called, effects;
int call(void){called++; return 2;}
_Static_assert(sizeof(int)==4,"int" " size");
struct S {_Static_assert(1,"member"); int n;};
int main(void){
 Number n=3;
 _Static_assert(_Generic(0,int:1,default:0),"generic assertion");
 { _Static_assert(sizeof(_Generic(0,int:"ab",default:"long"))==3,"nested"); }
 int a=_Generic(n++,int:7,default:++effects);
 int b=_Generic(call(),default:9,int:_Generic(n,int:5,default:6));
 int c=_Generic((double)0,default:11,int:++effects);
 char *s=_Generic(n,int:"a" "b",default:"c" "d");
 return (a!=7)||(b!=5)||(c!=11)||(n!=3)||called||effects||s[1]!=98;
}
