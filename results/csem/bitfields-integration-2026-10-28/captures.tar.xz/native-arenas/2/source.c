typedef int A[2] __attribute__((aligned(32))); A a; int main(void){return _Alignof(__typeof__(a))!=32 || _Alignof(__typeof__(a+0))!=8 || __alignof__(a)!=32;}
