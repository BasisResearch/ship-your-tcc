_Static_assert(sizeof(int)==4,"before" " middle" " after");
_Static_assert(sizeof(int)==4,"before" u8" middle" " after");
_Static_assert(sizeof(int)==4,"before" u" middle" " after");
_Static_assert(sizeof(int)==4,"before" U" middle" " after");
_Static_assert(sizeof(int)==4,"before" L" middle" " after");
struct S {
_Static_assert(sizeof(int)==4,"before" " middle" " after");
_Static_assert(sizeof(int)==4,"before" u8" middle" " after");
_Static_assert(sizeof(int)==4,"before" u" middle" " after");
_Static_assert(sizeof(int)==4,"before" U" middle" " after");
_Static_assert(sizeof(int)==4,"before" L" middle" " after");
int x;};
union U {
_Static_assert(sizeof(int)==4,"before" " middle" " after");
_Static_assert(sizeof(int)==4,"before" u8" middle" " after");
_Static_assert(sizeof(int)==4,"before" u" middle" " after");
_Static_assert(sizeof(int)==4,"before" U" middle" " after");
_Static_assert(sizeof(int)==4,"before" L" middle" " after");
int x;};
int main(void){
_Static_assert(sizeof(int)==4,"before" " middle" " after");
_Static_assert(sizeof(int)==4,"before" u8" middle" " after");
_Static_assert(sizeof(int)==4,"before" u" middle" " after");
_Static_assert(sizeof(int)==4,"before" U" middle" " after");
_Static_assert(sizeof(int)==4,"before" L" middle" " after");
struct S s={7}; union U u={9}; return s.x+u.x!=16;}
