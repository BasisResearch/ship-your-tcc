typedef int A[2] __attribute__((aligned(32))); typedef A B;
int f(void){return 1;} int *id(int *p){return p;} int get(int *p,int x,int *q){return p[x]+q[0];} int variadic(int x,...){return x;} int main(void){A a={3,7};int *p=a+f(); return p[0]!=7 || get(a,f(),id(a))!=10 || variadic(a[0],a)!=3 || _Alignof(__typeof__(a+f()))!=8 || _Alignof(__typeof__(id(a)))!=8 || _Alignof(__typeof__(a))!=32;}
