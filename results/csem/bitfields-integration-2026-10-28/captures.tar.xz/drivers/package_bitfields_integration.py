from pathlib import Path
import json,hashlib,tarfile,re,sys
r=Path(__file__).resolve().parents[1];w=r/'.claude/worktrees/sol-c11-line';out=w/'results/csem/bitfields-integration-2026-10-28';out.mkdir(exist_ok=True);H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();files={}
def tree(p,prefix):
 for f in p.rglob('*'):
  if f.is_file():files[prefix+'/'+str(f.relative_to(p))]=f
q=json.loads((w/'build/worker-build.bitfields-integrated-2.request').read_text());res=json.loads((w/'build/worker-build.result').read_text());assert res['request_id']==q['request_id'] and res['exit']==0 and res['source_hashes_verified'];assert all(H(w/p)==h for p,h in q['sha256'].items())
(w/'build/worker-build.bitfields-integrated-2.result').write_text(json.dumps(res,indent=2)+'\n')
for rid in ['bitfields-integrated-1','bitfields-integrated-2']:
 for ext in ['request','result']:files[f'gate/{rid}.{ext}.json']=w/'build'/f'worker-build.{rid}.{ext}'
 files['gate/'+rid+'.log']=w/'build'/f'worker-build-{rid}.log'
tree(w/'build/bitfields-integrated','combined')
supp=json.loads((w/'build/bitfields-integrated/supplementary-pins.json').read_text());assert all(H(w/p)==h for p,h in supp['sha256'].items())
for rid in ['bitfields-integrated-1','bitfields-integrated-2']:
 log=(w/'build'/f'worker-build-{rid}.log').read_text()
 paths=re.findall(r'build/bitfields-gate\.[A-Za-z0-9]+',log)
 if not paths:
  # csem_gates did not print its mktemp directory in either run. Select the
  # unique report matching the frozen source revision and required outcomes.
  request=json.loads((w/'build'/f'worker-build.{rid}.request').read_text())
  paths=[]
  for candidate in w.glob('build/bitfields-gate.*/report.json'):
   report=json.loads(candidate.read_text())
   if report['source_revision']==request['source_revision'] and sum(row['ok'] for row in report['rows'] if row['required'])==(10 if rid.endswith('-1') else 82):
    paths.append(str(candidate.parent.relative_to(w)))
  assert len(paths)==1,(rid,paths)
  if rid.endswith('-2'):
   assert json.loads((w/paths[0]/'report.json').read_text())['binary_sha256']==json.loads((w/'build/bitfields-integrated/postcheck-pins.json').read_text())['binaries']['csem_raw']
 for path in sorted(set(paths)):tree(w/path,'focused/'+rid)
for n in ['package_bitfields_integration.py','post_bitfields_integration2.py','measure_bitfields_integrated_native.py']:files['drivers/'+n]=r/'build'/n
for name in ['validation-final.json','evidence-sha256.json']:files['worker/'+name]=w/'results/csem/bitfields'/name
files['worker/report.md']=w/'results/csem/bitfields.md'
# Capture all native controls run by the combined gate, with their exported model/reference arenas.
# The existing freeze tool retains both arenas and the complete native manifest/files.
log=(w/res['log']).read_text();native_roots=re.findall(r'^(?:unevaluated syntax artifacts|assertion message artifacts|array decay artifacts): (.+)$',log,re.M)
assert len(native_roots)==3,native_roots
sys.path.insert(0,str(w/'scripts'))
import model_diff as md
from source_fixtures import fixture_entries
native_index=[]
for rootpath in native_roots:
 for p in (w/rootpath).rglob('arenas.json'):
  d=json.loads(p.read_text())
  if not d.get('sail_settings'):continue
  tree(p.parent,'native-gate/'+str(p.parent.relative_to(w)))
  assert d['totals']=={'n':1,'same':1}
  row=next(iter(d['results'].values()))[0];name=row['name'];source=(w/name).resolve();extra=[(v,str(h)) for v,h in fixture_entries(source)]
  key=md.sha('independent-c11-handoff-v4',source.read_bytes(),repr(extra),repr(['-w']),repr([]),d['runtime_key'],(w/'c/src/gen_embed.sh').read_bytes(),*[Path(h).read_bytes() for _,h in extra])
  key=md.sha(key,'native-sail-full-arena-v1',json.dumps(d['sail_settings'],sort_keys=True))
  ref=w/f'build/model_diff/cache/{key}.arena';model=w/f'build/model_diff/work/{md.sha(name,"c")}.arena';assert H(ref)==H(model)==row['sail']['model_arena_sha256']
  prefix='native-arenas/'+str(len(native_index));files[prefix+'/model.arena']=model;files[prefix+'/reference.arena']=ref;files[prefix+'/source.c']=source
  tree(w/f'build/model_diff/cache/{key}.sail',prefix+'/capture')
  files[prefix+'/report.json']=p
  native_index.append(dict(prefix=prefix,cache_key=key,source=name,comparison=row['sail']))
assert len(native_index)==5
(out/'native-index.json').write_text(json.dumps(native_index,indent=2)+'\n')
files['drivers/package-attempt1.log']=r/'build/package-bitfields-integration-attempt1.log'
manifest={n:H(p) for n,p in files.items()}
with tarfile.open(out/'captures.tar.xz','w:xz',preset=6) as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(out/'captures.tar.xz') as t:assert {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t if m.isfile()}==manifest
(out/'pins.json').write_text(json.dumps(dict(archive_sha256=H(out/'captures.tar.xz'),native_index_sha256=H(out/'native-index.json'),members=manifest,primary_inputs=len(q['sha256']),supplementary_inputs=len(supp['sha256']),worker_manifest_sha256=H(w/'results/csem/bitfields/evidence-sha256.json')),indent=2)+'\n');print('Packaged',len(manifest),'combined captures;',len(q['sha256']),'primary +',len(supp['sha256']),'unchanged supplementary inputs',flush=True)
