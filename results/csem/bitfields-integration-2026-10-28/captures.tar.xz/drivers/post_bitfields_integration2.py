from pathlib import Path
import hashlib,json,subprocess,time,shutil,os
r=Path(__file__).resolve().parents[1];w=r/'.claude/worktrees/sol-c11-line';out=w/'build/bitfields-integrated';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();q=json.loads((w/'build/worker-build.bitfields-integrated-2.request').read_text())
log=w/'build/worker-build-bitfields-integrated-2.log'
for _ in range(360):
 body=log.read_text()
 if '== csem (6) exec lane' in body:break
 if 'check: FAIL' in body:raise RuntimeError('Combined gate failed before semantic postchecks')
 time.sleep(10)
else:raise TimeoutError('combined semantic build not ready')
assert all(H(w/p)==h for p,h in q['sha256'].items());pins={n:H(w/'.lake/build/bin'/n) for n in ['csem_raw','csem_run','tcc_ghost','tcc_model']}
fixtures=w/'build/bitfields-continuation-fixtures';fixtures.mkdir(exist_ok=True);prior=json.loads((w/'results/csem/bitfields/continuation-final/report.json').read_text())
for row in prior['rows']:
 p=w/'results/csem/bitfields/continuation-final'/Path(row['name']).stem/'input.c';assert H(p)==row['source_sha256'];shutil.copyfile(p,fixtures/row['name'])
for name,target in [('measure-layout-raw.py','layout-raw-final'),('measure-controls.py','controls-final'),('measure-continuation.py','continuation-final')]:
 source=w/'results/csem/bitfields'/name;s=source.read_text();old="OUT=ROOT/'results/csem/bitfields/"+target+"'";assert old in s;s=s.replace(old,"OUT=ROOT/'build/bitfields-integrated/"+target+"'");driver=out/name;driver.write_text(s)
 with (out/(name+'.log')).open('w') as f:subprocess.run(['python3',str(driver)],cwd=w,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('PASS',name,flush=True)
assert all(H(w/p)==h for p,h in q['sha256'].items());assert all(H(w/'.lake/build/bin'/n)==h for n,h in pins.items());(out/'postcheck-pins.json').write_text(json.dumps(dict(source_inputs=len(q['sha256']),binaries=pins,driver_sha256=H(Path(__file__))),indent=2)+'\n')
