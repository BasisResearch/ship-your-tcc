import json,gzip,hashlib,tarfile,shutil,re,collections
from pathlib import Path
root=Path(__file__).resolve().parents[1];w=root/'.claude/worktrees/sol-c11-line';out=w/'results/csem/gnu-integration-2026-10-28';out.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
q=json.loads((w/'build/worker-build.gnu-integrated-2.request').read_text());r=json.loads((w/'build/worker-build.gnu-integrated-2.result').read_text());assert r['exit']==0 and r['source_hashes_verified'];assert all(sha(w/p)==h for p,h in q['sha256'].items())
for n in [1,2]:
 for suffix in ['request','result']:(out/f'gate{n}.{suffix}.json.gz').write_bytes(gzip.compress((w/f'build/worker-build.gnu-integrated-{n}.{suffix}').read_bytes(),mtime=0))
gatelog=w/'build/worker-build-gnu-integrated-2.log';gatepath=re.findall(r'^GNU declaration/header artifacts: (.+)$',gatelog.read_text(),re.M)[-1]
paths={'semantics':f'{gatepath}/semantics/report.json','headers':f'{gatepath}/headers/report.json','origins':'build/gnu-integrated/origins/comparison.json','fixtures':'build/gnu-integrated/fixtures/comparison.json','raw-ghost':'build/gnu-integrated/raw-ghost/comparison.json','attribute':'build/gnu-integrated-final/attribute/comparison.json','erasure':'build/gnu-integrated-final/erasure/comparison.json','arenas':'build/gnu-integrated-final/arenas.json'}
for name,p in paths.items():shutil.copyfile(w/p,out/(name+'.json'))
assert collections.Counter(x['status'] for x in json.loads((out/'semantics.json').read_text())['rows'])=={'PASS':23,'DIAGNOSTIC':8,'SEMANTIC_DIAGNOSTIC':3}
assert json.loads((out/'fixtures.json').read_text())['summary']=={'exact':45,'explicit-nonsuccess':11}
assert json.loads((out/'raw-ghost.json').read_text())['summary']=={'exact':3}
files={}
for name in ['build/gnu-integrated','build/gnu-integrated-final',gatepath,'build/ghost-byte-inputs']:
 for p in (w/name).rglob('*'):
  if p.is_file():files[str(p.relative_to(w))]=p
for p in (w/'build').iterdir():
 if p.is_file() and ((p.name.startswith('gnu-') and p.name.endswith(('.log','.exit'))) or p.name in ['worker-build-gnu-integrated-1.log','worker-build-gnu-integrated-2.log']):files[str(p.relative_to(w))]=p
files['drivers/replay_gnu_erasure.py']=root/'build/replay_gnu_erasure.py'
files['drivers/package_gnu_integration.py']=Path(__file__)
manifest={a:sha(p) for a,p in sorted(files.items())}
with tarfile.open(out/'captures.tar.gz','w:gz') as t:
 for a,p in sorted(files.items()):t.add(p,arcname=a,recursive=False)
with tarfile.open(out/'captures.tar.gz') as t:assert {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t.getmembers() if m.isfile()}==manifest
bins={str(p.relative_to(w)):sha(p) for p in (w/'.lake/build/bin').iterdir() if p.name in ['csem_raw','csem_cparse','csem_run','tcc_ghost','tcc_model','pre_spec','tcc_pre_tokens']}
# Earlier successful ghost checks used exactly the final ghost executable.
for name in ['origins','fixtures','raw-ghost']:assert json.loads((out/(name+'.json')).read_text())['binary_sha256']==bins['.lake/build/bin/tcc_ghost']
dump(out/'pins.json',{'source_revision':'1de48b7 plus gate-refresh diff','source_count':len(q['sha256']),'binary_pins':bins,'archive_members':manifest,'no_new_sail_executions':True,'artifacts':{p.name:sha(p) for p in out.iterdir() if p.is_file() and p.name!='pins.json'}})
print('GNU combined package:',len(manifest),'verified capture members;',len(q['sha256']),'unchanged source pins')
