from pathlib import Path
import subprocess,json,hashlib,shutil
r=Path.cwd();out=r/'build/pack-boundary-review';out.mkdir(exist_ok=False)
cases={
'natural':'struct S { char c; int x; };',
'pack1-before':'#pragma pack(push,1)\nstruct S { char c; int x; };\n#pragma pack(pop)',
'pack2-before':'#pragma pack(push,2)\nstruct S { char c; int x; };\n#pragma pack(pop)',
'push-inside':'struct S { char c;\n#pragma pack(push,1)\nint x; };\n#pragma pack(pop)',
'pop-inside':'#pragma pack(push,1)\nstruct S { char c;\n#pragma pack(pop)\nint x; };',
'push-after-brace':'struct S { char c; int x; }\n#pragma pack(push,1)\n;\n#pragma pack(pop)',
'pop-after-brace':'#pragma pack(push,1)\nstruct S { char c; int x; }\n#pragma pack(pop)\n;',
'pop-after-semicolon':'#pragma pack(push,1)\nstruct S { char c; int x; };\n#pragma pack(pop)',
}
host=r/'build/test-c11/host/tcc';gcc=Path(shutil.which('gcc'));H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
for name,decl in cases.items():
 d=out/name;d.mkdir();p=d/'input.c';p.write_text('#include <stdio.h>\n#include <stddef.h>\n'+decl+'\nint main(void){printf("%lu %lu %lu\\n",(unsigned long)sizeof(struct S),(unsigned long)_Alignof(struct S),(unsigned long)offsetof(struct S,x));return 0;}\n');row=dict(case=name,source_sha256=H(p),engines={})
 for engine,tool in [('tcc',host),('gcc',gcc)]:
  cmd=[str(tool),'-std=c11',*(['-B'+str(host.parent)] if engine=='tcc' else []),str(p),'-o',str(d/engine)]
  v=subprocess.run(cmd,capture_output=True,timeout=30);(d/(engine+'.build.stdout')).write_bytes(v.stdout);(d/(engine+'.build.stderr')).write_bytes(v.stderr);rec=dict(command=cmd,build_exit=v.returncode)
  if v.returncode==0:
   v=subprocess.run([str(d/engine)],capture_output=True,timeout=10);(d/(engine+'.stdout')).write_bytes(v.stdout);(d/(engine+'.stderr')).write_bytes(v.stderr);rec.update(exit=v.returncode,stdout=v.stdout.decode())
  row['engines'][engine]=rec
 rows.append(row);print(name,[(k,v.get('stdout')) for k,v in row['engines'].items()],flush=True)
(out/'report.json').write_text(json.dumps(dict(scope='Host implementation policy measurements; not Sail or semantic correctness evidence',tools={str(p):H(p) for p in [host,gcc]},rows=rows),indent=2)+'\n')
