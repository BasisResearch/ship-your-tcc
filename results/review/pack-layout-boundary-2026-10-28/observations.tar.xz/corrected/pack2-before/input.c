#include <stdio.h>
#include <stddef.h>
#pragma pack(push,2)
struct S { char c; int x; };
#pragma pack(pop)
int main(void){printf("%lu %lu %lu\n",(unsigned long)sizeof(struct S),(unsigned long)_Alignof(struct S),(unsigned long)offsetof(struct S,x));return 0;}
