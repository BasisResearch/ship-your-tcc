#include <stdio.h>
#include <stddef.h>
#pragma pack(push,1)
struct S { char c;
#pragma pack(pop)
int x; };
int main(void){printf("%lu %lu %lu\n",(unsigned long)sizeof(struct S),(unsigned long)_Alignof(struct S),(unsigned long)offsetof(struct S,x));return 0;}
