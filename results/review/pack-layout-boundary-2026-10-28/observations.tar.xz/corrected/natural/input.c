#include <stdio.h>
#include <stddef.h>
struct S { char c; int x; };
int main(void){printf("%lu %lu %lu\n",(unsigned long)sizeof(struct S),(unsigned long)_Alignof(struct S),(unsigned long)offsetof(struct S,x));return 0;}
